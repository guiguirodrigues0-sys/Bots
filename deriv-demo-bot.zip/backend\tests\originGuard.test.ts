import { test } from "node:test";
import assert from "node:assert/strict";
import { isAllowedOrigin } from "../src/http/security.js";

test("sem Origin (cliente local/Electron) é permitido", () => {
  assert.equal(isAllowedOrigin(undefined), true);
});

test("origens locais são permitidas (Vite, produção e Electron)", () => {
  assert.equal(isAllowedOrigin("http://localhost:5173"), true);
  assert.equal(isAllowedOrigin("http://127.0.0.1:3001"), true);
  assert.equal(isAllowedOrigin("http://localhost"), true);
});

test("sites externos são bloqueados", () => {
  assert.equal(isAllowedOrigin("https://evil.example.com"), false);
  assert.equal(isAllowedOrigin("http://localhost.evil.com"), false);
  assert.equal(isAllowedOrigin("null"), false);
  assert.equal(isAllowedOrigin("file://"), false);
});
