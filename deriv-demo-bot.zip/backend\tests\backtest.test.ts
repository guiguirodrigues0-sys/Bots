import { test } from "node:test";
import assert from "node:assert/strict";
import { runBacktest, roundMetrics, winRateConfidenceInterval, type BacktestMetrics } from "../src/strategies/backtest.js";
import { defaultConfig } from "../src/strategies/definitions.js";
import type { Candle } from "../src/types.js";

process.env.LOG_LEVEL = "error";

function candles(n: number, step = 0.02): Candle[] {
  const out: Candle[] = [];
  let close = 100;
  for (let i = 0; i < n; i++) {
    const open = close;
    close = open + step + (i % 5) * 0.003;
    out.push({ time: i * 60, open, high: close + 0.01, low: open - 0.01, close });
  }
  return out;
}

test("backtest gera 3 segmentos (desenvolvimento, validação, teste)", () => {
  const result = runBacktest("SCALPING", candles(400), defaultConfig("SCALPING"));
  assert.equal(result.segments.length, 3);
  assert.deepEqual(
    result.segments.map((s) => s.label),
    ["DESENVOLVIMENTO", "VALIDACAO", "TESTE"],
  );
});

test("agregado soma as operações dos segmentos", () => {
  const result = runBacktest("SCALPING", candles(400), defaultConfig("SCALPING"));
  const sumTrades = result.segments.reduce((a, s) => a + s.metrics.trades, 0);
  assert.equal(result.aggregate.trades, sumTrades);
});

test("métricas são calculadas e marcadas como estimativa", () => {
  const result = runBacktest("SCALPING", candles(400), defaultConfig("SCALPING"));
  const m = result.aggregate;
  assert.ok(m.wins + m.losses === m.trades);
  if (m.trades > 0) {
    assert.equal(result.isEstimate, true);
  }
  assert.equal(typeof m.winRate, "number");
  assert.equal(typeof m.expectancy, "number");
});

test("roundMetrics preserva contagens e arredonda decimais", () => {
  const m: BacktestMetrics = {
    trades: 10,
    wins: 6,
    losses: 4,
    winRate: 60,
    grossProfit: 12.345,
    grossLoss: 4.567,
    netPnl: 7.778,
    profitFactor: 2.7012,
    maxDrawdown: 1.111,
    maxDrawdownPct: 3.333,
    expectancy: 0.7778,
    maxConsecutiveLosses: 2,
  };
  const r = roundMetrics(m);
  assert.equal(r.trades, 10);
  assert.equal(r.wins, 6);
  assert.equal(r.maxConsecutiveLosses, 2);
  assert.equal(r.netPnl, 7.78);
});

test("backtest determinístico para a mesma entrada", () => {
  const data = candles(300);
  const a = runBacktest("CONFLUENCIA", data, defaultConfig("CONFLUENCIA"));
  const b = runBacktest("CONFLUENCIA", data, defaultConfig("CONFLUENCIA"));
  assert.deepEqual(a.aggregate, b.aggregate);
});

test("sinal no último candle (sem liquidação disponível) não é contabilizado", () => {
  // Mesmo que houvesse sinal, o último candle nunca tem candle de liquidação.
  const result = runBacktest("MACD_ADX", candles(100), defaultConfig("MACD_ADX"));
  assert.equal(Number.isFinite(result.aggregate.netPnl), true);
});

test("winRateConfidenceInterval retorna null sem operações", () => {
  assert.equal(winRateConfidenceInterval(0, 0), null);
});

test("winRateConfidenceInterval calcula intervalo de Wilson de 95%", () => {
  const ci = winRateConfidenceInterval(49, 50);
  assert.ok(ci);
  // 98% de acerto com n=50 → limite inferior bem abaixo de 98%.
  assert.ok(ci.low < 98);
  assert.ok(ci.high > 98);
  assert.ok(ci.low >= 0 && ci.high <= 100);
});
