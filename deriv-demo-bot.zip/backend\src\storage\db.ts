export class Database {
  public async open(): Promise<void> {}
  public async close(): Promise<void> {}
}
