import { test, before, after, afterEach } from "node:test";
import assert from "node:assert/strict";
import express from "express";
import type { Server } from "node:http";
import { apiRouter } from "../src/http/routes.js";
import { bot } from "../src/bot/index.js";

process.env.LOG_LEVEL = "error";

let server: Server;
let baseUrl: string;

before(async () => {
  const app = express();
  app.use(express.json());
  app.use("/api", apiRouter);
  server = app.listen(0);
  await new Promise<void>((resolve) => server.once("listening", () => resolve()));
  const addr = server.address();
  if (addr && typeof addr === "object") {
    baseUrl = `http://127.0.0.1:${addr.port}`;
  }
});

after(() => {
  server.close();
});

afterEach(() => {
  (bot as unknown as Record<string, unknown>).openTrades = [];
});

test("disconnect sem posição → permitido (HTTP 200)", async () => {
  const res = await fetch(`${baseUrl}/api/deriv/disconnect`, { method: "POST" });
  assert.equal(res.status, 200);
});

test("disconnect com posição aberta → bloqueado (HTTP 409)", async () => {
  (bot as unknown as Record<string, unknown>).openTrades = [
    {
      contractId: "123",
      proposalId: "p1",
      symbol: "R_100",
      direction: "CALL",
      stake: 50,
      entryTime: Date.now(),
      durationSeconds: 30,
      durationUnit: "s",
      askPrice: 1,
      payout: 1.9,
      entryType: "INITIAL",
      status: "OPEN",
      profit: null,
      settlementTime: null,
    },
  ];
  const res = await fetch(`${baseUrl}/api/deriv/disconnect`, { method: "POST" });
  assert.equal(res.status, 409);
  const body = (await res.json()) as { error?: string };
  assert.ok(body.error?.includes("operação DEMO em andamento"));
});
