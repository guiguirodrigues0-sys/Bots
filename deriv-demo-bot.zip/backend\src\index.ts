import express from "express";
import cors from "cors";
import { loadEnv } from "./config/env.js";
import { logger } from "./logger/index.js";
import { createHttpServer } from "./http/server.js";
import { isAllowedOrigin, localOriginGuard } from "./http/security.js";

async function main(): Promise<void> {
  const env = loadEnv();
  const app = express();
  app.use(cors({ origin: (origin, callback) => callback(null, isAllowedOrigin(origin)) }));
  app.use(localOriginGuard);
  app.use(express.json());

  createHttpServer(app);

  app.listen(env.PORT, env.HOST, () => {
    logger.info("Backend iniciado", {
      host: env.HOST,
      port: env.PORT,
      environment: env.DERIV_ENVIRONMENT,
    });
  });
}

main().catch((err) => {
  logger.error("Falha ao iniciar backend", err);
  process.exit(1);
});
