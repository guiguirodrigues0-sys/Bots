import { execSync, spawn } from "node:child_process";
import fs from "node:fs";
import path from "node:path";
import net from "node:net";
import http from "node:http";
import { fileURLToPath } from "node:url";
import { createRequire } from "node:module";

const require = createRequire(import.meta.url);
const JavaScriptObfuscator = require("javascript-obfuscator");
const asar = require("@electron/asar");

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const root = path.resolve(__dirname, "..");
const tempRoot = path.join(root, ".protected-build");
const appDir = path.join(tempRoot, "app");
const auditDir = path.join(tempRoot, "asar-audit");
const isStandard = process.argv.includes("--standard");
const outputDir = isStandard
  ? path.join(root, "release")
  : path.join(root, "release-protected");
const artifactName = isStandard
  ? "Deriv-Auto-Trader-Setup-${version}.${ext}"
  : "DerivAutoTrader-Setup-Protected-${version}.${ext}";

const OBFUSCATION_OPTIONS = {
  target: "node",
  compact: true,
  identifierNamesGenerator: "hexadecimal",
  stringArray: true,
  rotateStringArray: true,
  shuffleStringArray: true,
  stringArrayThreshold: 0.75,
  stringArrayEncoding: [],
  stringArrayWrappersCount: 1,
  stringArrayWrappersChainedCalls: true,
  stringArrayWrappersType: "variable",
  splitStrings: false,
  numbersToExpressions: false,
  simplify: true,
  controlFlowFlattening: false,
  controlFlowFlatteningThreshold: 0.5,
  deadCodeInjection: false,
  debugProtection: false,
  selfDefending: false,
  disableConsoleOutput: false,
  renameGlobals: true,
  transformObjectKeys: false,
  unicodeEscapeSequence: false,
};

function log(msg) {
  console.log(`[protected] ${msg}`);
}

function step(name) {
  console.log(`\n=== ${name} ===`);
}

function run(cmd, opts = {}) {
  execSync(cmd, { cwd: root, stdio: "inherit", ...opts });
}

function rmrf(p) {
  fs.rmSync(p, { recursive: true, force: true });
}

function walkFiles(dir) {
  const out = [];
  if (!fs.existsSync(dir)) return out;
  const stack = [dir];
  while (stack.length) {
    const d = stack.pop();
    for (const entry of fs.readdirSync(d, { withFileTypes: true })) {
      const p = path.join(d, entry.name);
      if (entry.isDirectory()) stack.push(p);
      else out.push(p);
    }
  }
  return out;
}

function readSecrets() {
  const envPath = path.join(root, ".env");
  if (!fs.existsSync(envPath)) return [];
  const content = fs.readFileSync(envPath, "utf8");
  const secrets = [];
  for (const line of content.split(/\r?\n/)) {
    const m = line.match(/^\s*([A-Za-z_][A-Za-z0-9_]*)\s*=\s*(.+?)\s*$/);
    if (!m) continue;
    if (/TOKEN|SECRET|KEY|PASS|APP_ID|PASSWORD/i.test(m[1]) && m[2].trim().length >= 4) {
      secrets.push(m[2].trim());
    }
  }
  return secrets.filter(Boolean);
}

function findForbidden(dir) {
  const rel = (p) => path.relative(dir, p).replace(/\\/g, "/");
  const result = { maps: [], ts: [], env: [] };
  for (const file of walkFiles(dir)) {
    const r = rel(file);
    const lower = r.toLowerCase();
    if (lower.endsWith(".map")) result.maps.push(r);
    if (lower.endsWith(".ts") || lower.endsWith(".tsx")) result.ts.push(r);
    if (path.basename(file).toLowerCase() === ".env" || lower.endsWith(".env")) result.env.push(r);
    if (lower.includes("/src/") || lower.includes("/tests/") || lower.includes("/.git/")) {
      result.ts.push(r + " (dir proibida)");
    }
  }
  return result;
}

function findSecretsIn(dir, secrets) {
  const hits = [];
  for (const file of walkFiles(dir)) {
    let content;
    try {
      content = fs.readFileSync(file, "utf8");
    } catch {
      continue;
    }
    for (const s of secrets) {
      if (content.includes(s)) hits.push(path.relative(dir, file).replace(/\\/g, "/"));
    }
  }
  return hits;
}

function findFreePort() {
  return new Promise((resolve) => {
    const srv = net.createServer();
    srv.listen(0, "127.0.0.1", () => {
      const port = srv.address().port;
      srv.close(() => resolve(port));
    });
  });
}

async function smokeTestBackend(backendFile, frontendDist) {
  const port = await findFreePort();
  return new Promise((resolve, reject) => {
    const child = spawn(process.execPath, [backendFile], {
      cwd: path.dirname(backendFile),
      env: {
        ...process.env,
        HOST: "127.0.0.1",
        PORT: String(port),
        DERIV_ENVIRONMENT: "demo",
        ALLOW_REAL_ACCOUNT: "false",
        LOG_LEVEL: "error",
        FRONTEND_DIST: frontendDist,
      },
      stdio: "ignore",
      windowsHide: true,
    });

    let settled = false;
    const timer = setTimeout(
      () => finish(reject, new Error("backend nao respondeu /api/health em 15s")),
      15000,
    );
    const finish = (fn, arg) => {
      if (settled) return;
      settled = true;
      clearTimeout(timer);
      try {
        child.kill();
      } catch {
        /* ignore */
      }
      fn(arg);
    };

    const probe = () => {
      if (settled) return;
      const req = http.get(
        { host: "127.0.0.1", port, path: "/api/health", timeout: 2000 },
        (res) => {
          res.resume();
          if (res.statusCode === 200) finish(resolve, null);
          else if (!settled) setTimeout(probe, 250);
        },
      );
      req.on("error", () => {
        if (!settled) setTimeout(probe, 250);
      });
      req.on("timeout", () => {
        req.destroy();
        if (!settled) setTimeout(probe, 250);
      });
    };

    child.on("exit", (code) => {
      if (!settled && code !== 0 && code !== null) {
        finish(reject, new Error(`backend saiu com codigo ${code}`));
      }
    });

    setTimeout(probe, 200);
  });
}

function findSetupExe(dir) {
  const exes = walkFiles(dir).filter((p) => /-Setup-.*\.exe$/.test(path.basename(p)));
  return exes.sort((a, b) => fs.statSync(b).mtimeMs - fs.statSync(a).mtimeMs)[0] ?? null;
}

async function main() {
  const report = {
    typecheck: "ERRO",
    tests: "ERRO",
    build: "ERRO",
    asar: "NAO",
    sourceMaps: -1,
    typescript: -1,
    env: -1,
    credentials: -1,
    obfuscation: "ERRO",
    appStarted: "NAO",
  };

  step("1/12 Limpando artefatos temporarios do build protegido");
  rmrf(tempRoot);
  rmrf(outputDir);
  fs.mkdirSync(appDir, { recursive: true });

  step("2/12 Typecheck");
  run("npm run typecheck");
  report.typecheck = "OK";

  step("3/12 Testes");
  run("npm test");
  report.tests = "OK";

  step("4/12 Build de producao");
  run("npm run build:electron");
  report.build = "OK";

  step("5/12 Copiando artefatos para area temporaria");
  fs.cpSync(path.join(root, "electron"), path.join(appDir, "electron"), {
    recursive: true,
    filter: (src) =>
      !src.endsWith("backend.mjs") &&
      !src.endsWith("main.src.cjs") &&
      !src.endsWith("update-config.cjs"),
  });
  fs.cpSync(path.join(root, "frontend", "dist"), path.join(appDir, "frontend", "dist"), {
    recursive: true,
  });
  const rootPkg = JSON.parse(fs.readFileSync(path.join(root, "package.json"), "utf8"));
  const appPkg = {
    name: rootPkg.name,
    version: rootPkg.version,
    description: rootPkg.description ?? "",
    author: rootPkg.author,
    main: rootPkg.main,
  };
  fs.writeFileSync(path.join(appDir, "package.json"), JSON.stringify(appPkg, null, 2) + "\n");
  log("area temporaria: " + appDir);

  step("6/12 Removendo source maps");
  for (const file of walkFiles(appDir)) {
    if (file.toLowerCase().endsWith(".map")) fs.rmSync(file, { force: true });
  }
  log("source maps removidos (se existentes)");

  step("7/12 Ofuscando JavaScript proprietario (electron/backend.cjs)");
  const backendFile = path.join(appDir, "electron", "backend.cjs");
  const original = fs.readFileSync(backendFile, "utf8");
  log(`backend.cjs antes: ${original.length} bytes`);
  const obfuscated = JavaScriptObfuscator.obfuscate(original, OBFUSCATION_OPTIONS).getObfuscatedCode();
  fs.writeFileSync(backendFile, obfuscated);
  log(`backend.cjs depois: ${obfuscated.length} bytes`);
  report.obfuscation = "OK";

  step("7b/12 Smoke test do backend ofuscado");
  try {
    execSync(`"${process.execPath}" --check "${backendFile}"`, { stdio: "pipe" });
    log("sintaxe validada (node --check)");
  } catch (e) {
    throw new Error("backend ofuscado falhou no node --check: " + (e.stderr?.toString() ?? e.message));
  }
  await smokeTestBackend(backendFile, path.join(appDir, "frontend", "dist"));
  report.appStarted = "SIM";
  log("backend ofuscado iniciou e respondeu /api/health");

  step("8/12 Verificando arquivos proibidos");
  const forbidden = findForbidden(appDir);
  if (forbidden.maps.length || forbidden.ts.length || forbidden.env.length) {
    console.error("ARQUIVOS PROIBIDOS ENCONTRADOS:");
    console.error(JSON.stringify(forbidden, null, 2));
    throw new Error("build abortado: arquivos proibidos presentes");
  }
  log("nenhum arquivo proibido encontrado");

  step("9/12 Verificando credenciais");
  const secrets = readSecrets();
  const secretHits = findSecretsIn(appDir, secrets);
  if (secretHits.length) {
    console.error(`CREDENCIAIS ENCONTRADAS EM ${secretHits.length} ARQUIVO(S) (valores nao exibidos)`);
    throw new Error("build abortado: credenciais presentes no pacote");
  }
  log(`nenhuma credencial encontrada (${secrets.length} valores verificados)`);

  step("10/12 Empacotando com ASAR + instalador NSIS");
  process.env.PROTECTED_APP_DIR = appDir;
  process.env.PROTECTED_OUTPUT_DIR = outputDir;
  process.env.PROTECTED_ARTIFACT_NAME = artifactName;
  run(
    `npx --no-install electron-builder --win --x64 --config ${path.join(
      __dirname,
      "electron-builder.protected.cjs",
    )}`,
  );

  step("11/12 Auditoria final do app.asar");
  const asarPath = path.join(outputDir, "win-unpacked", "resources", "app.asar");
  if (!fs.existsSync(asarPath)) {
    throw new Error("app.asar nao encontrado em " + asarPath);
  }
  report.asar = "SIM";
  rmrf(auditDir);
  fs.mkdirSync(auditDir, { recursive: true });
  asar.extractAll(asarPath, auditDir);

  const audited = findForbidden(auditDir);
  report.sourceMaps = audited.maps.length;
  report.typescript = audited.ts.length;
  report.env = audited.env.length;
  const auditSecrets = findSecretsIn(auditDir, secrets);
  report.credentials = auditSecrets.length;

  const auditedBackend = path.join(auditDir, "electron", "backend.cjs");
  const auditCode = fs.existsSync(auditedBackend) ? fs.readFileSync(auditedBackend, "utf8") : "";
  const hasMarker = auditCode.includes("_0x");
  const readableTokens = [
    "RiskManager",
    "TradeExecutor",
    "TradeMonitor",
    "WebSocketManager",
    "DerivApiClient",
    "CandleAggregator",
    "evaluateStrategy",
    "computeIndicators",
    "resolveAssets",
    "checkContractAvailability",
  ].filter((t) => auditCode.includes(t));
  if (!hasMarker || readableTokens.length) {
    report.obfuscation = "ERRO";
    console.error("Ofuscacao aparentemente ausente/incompleta no app.asar", {
      hasMarker,
      readableTokens,
    });
  }

  rmrf(auditDir);
  log("pasta temporaria de auditoria removida");

  step("12/12 Resultado");
  const protectedExe = findSetupExe(outputDir);
  const originalExe = isStandard ? null : findSetupExe(path.join(root, "release"));

  console.log("\n==========================================");
  console.log("BUILD PROTEGIDO");
  console.log("==========================================");
  console.log(`Typecheck: ${report.typecheck}`);
  console.log(`Testes: ${report.tests}`);
  console.log(`Build: ${report.build}`);
  console.log(`ASAR: ${report.asar}`);
  console.log(`Source maps encontrados: ${report.sourceMaps}`);
  console.log(`TypeScript encontrado no pacote: ${report.typescript}`);
  console.log(`.env encontrado: ${report.env}`);
  console.log(`Credenciais encontradas: ${report.credentials}`);
  console.log(`Ofuscacao: ${report.obfuscation}`);
  console.log(`Aplicativo iniciou: ${report.appStarted}`);
  console.log("------------------------------------------");
  if (isStandard) {
    console.log(`EXE (entrega, protegido): ${protectedExe ?? "nao encontrado"}`);
  } else {
    console.log(`EXE ORIGINAL: ${originalExe ?? "nao encontrado"}`);
    console.log(`EXE PROTEGIDO: ${protectedExe ?? "nao encontrado"}`);
  }
  console.log("==========================================\n");

  rmrf(tempRoot);
  log("artefatos temporarios removidos");
}

main().catch((err) => {
  console.error("\n[protected] BUILD PROTEGIDO ABORTADO");
  console.error(err?.message ?? err);
  process.exit(1);
});
