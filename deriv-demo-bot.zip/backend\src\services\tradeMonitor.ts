import type { WsMessage } from "../deriv/wsManager.js";
import { logger } from "../logger/index.js";

export interface SettledTrade {
  contractId: string;
  result: "WIN" | "LOSS" | "UNKNOWN";
  profitLoss: number;
  sellPrice: number | null;
  buyPrice: number | null;
  status: string | null;
}

function toNumber(value: number | string | null | undefined): number | null {
  if (typeof value === "number") {
    return value;
  }
  if (typeof value === "string" && value.trim() !== "") {
    const n = Number(value);
    return Number.isFinite(n) ? n : null;
  }
  return null;
}

export class TradeMonitor {
  private handlers = new Set<(settled: SettledTrade) => void>();

  onSettled(handler: (settled: SettledTrade) => void): void {
    this.handlers.add(handler);
  }

  handleMessage(msg: WsMessage): void {
    const poc = msg.proposal_open_contract as
      | {
          contract_id?: string | number;
          is_sold?: number;
          status?: string;
          profit?: number | string;
          sell_price?: number | string;
          buy_price?: number | string;
        }
      | undefined;
    if (poc?.contract_id === undefined || poc?.contract_id === null) {
      return;
    }

    const isSold =
      poc.is_sold === 1 ||
      poc.status === "sold" ||
      poc.status === "won" ||
      poc.status === "lost" ||
      poc.status === "cancelled";
    if (!isSold) {
      return;
    }

    const sellPrice = toNumber(poc.sell_price);
    const buyPrice = toNumber(poc.buy_price);
    const profit = toNumber(poc.profit);

    let result: "WIN" | "LOSS" | "UNKNOWN" = "UNKNOWN";
    if (poc.status === "won") {
      result = "WIN";
    } else if (poc.status === "lost") {
      result = "LOSS";
    } else if (poc.status === "sold") {
      // Vendido de volta antes do vencimento: o sinal do lucro define o lado.
      if (profit !== null) {
        result = profit > 0 ? "WIN" : profit < 0 ? "LOSS" : "UNKNOWN";
      } else if (sellPrice !== null && buyPrice !== null) {
        const delta = sellPrice - buyPrice;
        result = delta > 0 ? "WIN" : delta < 0 ? "LOSS" : "UNKNOWN";
      }
    } else if (poc.status === "cancelled") {
      result = "UNKNOWN";
    } else if (profit !== null) {
      result = profit > 0 ? "WIN" : profit < 0 ? "LOSS" : "UNKNOWN";
    }

    // Lucro/prejuízo efetivo: `profit` reportado pela Deriv, com fallback em
    // `sell_price - buy_price` quando `profit` não vier preenchido.
    let profitLoss: number;
    if (profit !== null) {
      profitLoss = profit;
    } else if (sellPrice !== null && buyPrice !== null) {
      profitLoss = sellPrice - buyPrice;
    } else {
      profitLoss = 0;
    }

    const settled: SettledTrade = {
      contractId: String(poc.contract_id),
      result,
      profitLoss,
      sellPrice,
      buyPrice,
      status: poc.status ?? null,
    };

    logger.info("Contrato liquidado", settled);
    for (const h of this.handlers) {
      try {
        h(settled);
      } catch (e) {
        logger.error("Erro em handler de liquidação", e);
      }
    }
  }
}
