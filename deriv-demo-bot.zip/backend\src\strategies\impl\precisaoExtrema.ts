import type { Candle } from "../../types.js";
import { BaseStrategy, makeSignal, insufficientSignal } from "../base.js";
import type {
  StrategyConfig,
  StrategyId,
  StrategySignal,
  StrategyCondition,
} from "../types.js";
import {
  emaSeries,
  rsiSeries,
  adxSeries,
  atrSeries,
  macdSeries,
  highestHigh,
  lowestLow,
  aggregateHigherTimeframe,
  last,
  num,
} from "../indicators.js";

const TOTAL_CONFIRMATIONS = 9;
const REQUIRED_CONFIRMATIONS = 9;

/**
 * Estratégia 8 — Precisão Extrema (Experimental).
 * Estratégia de múltiplas confirmações que prioriza a qualidade dos sinais.
 * A meta de 98% de assertividade é EXPERIMENTAL e NÃO garantida.
 */
export class PrecisaoExtremaStrategy extends BaseStrategy {
  readonly id: StrategyId = "PRECISAO_EXTREMA";

  evaluateSignal(candles: Candle[], config: StrategyConfig): StrategySignal {
    const closes = candles.map((c) => c.close);
    const price = closes.at(-1) ?? null;
    if (price === null || closes.length < 2) {
      return insufficientSignal(this.id, price);
    }

    const i = closes.length - 1;

    const ema9 = last(emaSeries(closes, num(config.params, "emaFastPeriod", 9)));
    const ema21 = last(emaSeries(closes, num(config.params, "emaMidPeriod", 21)));
    const ema50 = last(emaSeries(closes, num(config.params, "emaSlowPeriod", 50)));
    const ema200 = last(emaSeries(closes, num(config.params, "emaTrendPeriod", 200)));
    const rsi = last(rsiSeries(closes, num(config.params, "rsiPeriod", 14)));
    const adx = last(adxSeries(candles, num(config.params, "adxPeriod", 14)));
    const atr = last(atrSeries(candles, num(config.params, "atrPeriod", 14)));
    const macd = macdSeries(
      closes,
      num(config.params, "macdFast", 12),
      num(config.params, "macdSlow", 26),
      num(config.params, "macdSignal", 9),
    );

    if (
      ema9 === null ||
      ema21 === null ||
      ema50 === null ||
      ema200 === null ||
      rsi === null ||
      adx === null ||
      atr === null ||
      macd.macd[i] == null ||
      macd.signal[i] == null
    ) {
      return insufficientSignal(this.id, price);
    }

    const rsiBuyMin = num(config.params, "rsiBuyMin", 55);
    const rsiBuyMax = num(config.params, "rsiBuyMax", 65);
    const rsiSellMin = num(config.params, "rsiSellMin", 35);
    const rsiSellMax = num(config.params, "rsiSellMax", 45);
    const adxMin = num(config.params, "adxMin", 30);
    const volMinPct = num(config.params, "volatilityMinPct", 0.005);
    const volMaxPct = num(config.params, "volatilityMaxPct", 0.5);

    const lastCandle = candles.at(-1);
    const candleUp = lastCandle ? lastCandle.close > lastCandle.open : false;
    const candleDown = lastCandle ? lastCandle.close < lastCandle.open : false;

    const atrPct = (atr / price) * 100;
    const volOk = atrPct >= volMinPct && atrPct <= volMaxPct;

    // Confirmação em timeframe superior (agregação local).
    const htfFactor = Math.max(1, Math.round(num(config.params, "htfFactor", 4)));
    const htf = aggregateHigherTimeframe(candles, htfFactor);
    const htfCloses = htf.map((c) => c.close);
    const htfFast = last(emaSeries(htfCloses, num(config.params, "htfEmaFast", 9)));
    const htfSlow = last(emaSeries(htfCloses, num(config.params, "htfEmaSlow", 21)));
    const htfUp = htfFast !== null && htfSlow !== null && htfFast > htfSlow;
    const htfDown = htfFast !== null && htfSlow !== null && htfFast < htfSlow;

    // Suporte/resistência.
    const srLookback = Math.max(1, Math.round(num(config.params, "srLookback", 50)));
    const srBufferAtr = num(config.params, "srBufferAtr", 0.5);
    const resistance = highestHigh(candles, srLookback, i);
    const support = lowestLow(candles, srLookback, i);
    const notNearResistance =
      resistance !== null &&
      resistance > price &&
      resistance - price >= srBufferAtr * atr;
    const notNearSupport =
      support !== null && support < price && price - support >= srBufferAtr * atr;

    const macdValue = macd.macd[i] ?? 0;
    const macdSignalValue = macd.signal[i] ?? 0;

    const buyConditions: StrategyCondition[] = [
      { label: "Preço acima da EMA 200", passed: price > ema200 },
      { label: "EMA 9 > EMA 21 > EMA 50", passed: ema9 > ema21 && ema21 > ema50 },
      {
        label: `RSI entre ${rsiBuyMin} e ${rsiBuyMax}`,
        passed: rsi >= rsiBuyMin && rsi <= rsiBuyMax,
      },
      { label: `ADX acima de ${adxMin}`, passed: adx > adxMin },
      { label: "MACD acima da linha de sinal", passed: macdValue > macdSignalValue },
      { label: "Tendência de alta no timeframe superior", passed: htfUp },
      { label: "Distante de resistência relevante", passed: notNearResistance },
      { label: "Volatilidade dentro dos limites", passed: volOk },
      { label: "Candle fechado confirma alta", passed: candleUp },
    ];

    const sellConditions: StrategyCondition[] = [
      { label: "Preço abaixo da EMA 200", passed: price < ema200 },
      { label: "EMA 9 < EMA 21 < EMA 50", passed: ema9 < ema21 && ema21 < ema50 },
      {
        label: `RSI entre ${rsiSellMin} e ${rsiSellMax}`,
        passed: rsi >= rsiSellMin && rsi <= rsiSellMax,
      },
      { label: `ADX acima de ${adxMin}`, passed: adx > adxMin },
      { label: "MACD abaixo da linha de sinal", passed: macdValue < macdSignalValue },
      { label: "Tendência de baixa no timeframe superior", passed: htfDown },
      { label: "Distante de suporte relevante", passed: notNearSupport },
      { label: "Volatilidade dentro dos limites", passed: volOk },
      { label: "Candle fechado confirma baixa", passed: candleDown },
    ];

    const indicators = {
      ema9,
      ema21,
      ema50,
      ema200,
      rsi,
      adx,
      atr,
      macd: macdValue,
      macdSignal: macdSignalValue,
      htfFast,
      htfSlow,
      resistance,
      support,
      volatilityPct: atrPct,
    };

    const buyScore = buyConditions.filter((c) => c.passed).length;
    const sellScore = sellConditions.filter((c) => c.passed).length;

    if (buyScore >= REQUIRED_CONFIRMATIONS) {
      return makeSignal(
        this.id,
        "BUY",
        price,
        buyConditions,
        indicators,
        `SINAL BUY — ${buyScore}/${TOTAL_CONFIRMATIONS} confirmações (RSI ${rsi.toFixed(1)}, ADX ${adx.toFixed(1)}, ATR ${atrPct.toFixed(2)}%). Meta experimental de 98% NÃO garantida.`,
      );
    }
    if (sellScore >= REQUIRED_CONFIRMATIONS) {
      return makeSignal(
        this.id,
        "SELL",
        price,
        sellConditions,
        indicators,
        `SINAL SELL — ${sellScore}/${TOTAL_CONFIRMATIONS} confirmações (RSI ${rsi.toFixed(1)}, ADX ${adx.toFixed(1)}, ATR ${atrPct.toFixed(2)}%). Meta experimental de 98% NÃO garantida.`,
      );
    }

    const useBuy = buyScore >= sellScore;
    const shown = useBuy ? buyConditions : sellConditions;
    const shownScore = useBuy ? buyScore : sellScore;
    return makeSignal(
      this.id,
      "WAIT",
      price,
      shown,
      indicators,
      `AGUARDAR — ${shownScore}/${TOTAL_CONFIRMATIONS} confirmações (mínimo ${REQUIRED_CONFIRMATIONS}). A pontuação indica apenas condições atendidas, não probabilidade de vitória.`,
      null,
      "NO_SIGNAL",
    );
  }
}
