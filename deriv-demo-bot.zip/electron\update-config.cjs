// ============================================================
// CONFIGURAÇÃO DE ATUALIZAÇÃO AUTOMÁTICA (GitHub Releases)
// O app baixa automaticamente as novas versões publicadas como
// "Release" neste repositório GitHub.
// ============================================================
module.exports = {
  owner: "guiguirodrigues0-sys",
  repo: "Deriv",
};
