import { emaSeries, rsiSeries, lastValue } from "./indicatorService.js";

export type RapidDirection = "CALL" | "PUT" | "WAIT";

export interface RapidConfirmation {
  label: string;
  passed: boolean;
}

export interface RapidSignal {
  direction: RapidDirection;
  score: number;
  confirmations: number;
  confirmationsTotal: number;
  details: RapidConfirmation[];
  reason: string;
  momentum: number | null;
  rsi: number | null;
  fastEma: number | null;
  slowEma: number | null;
  volatilityPct: number | null;
  price: number | null;
  timestamp: number;
}

const FAST_EMA = 5;
const SLOW_EMA = 15;
const RSI_PERIOD = 7;
const MOMENTUM_TICKS = 5;
const VOL_TICKS = 20;

const RSI_CALL_MIN = 45;
const RSI_CALL_MAX = 78;
const RSI_PUT_MIN = 22;
const RSI_PUT_MAX = 55;

const VOL_MIN_PCT = 0.001;
const VOL_MAX_PCT = 1.0;

function stddev(values: number[]): number | null {
  if (values.length < 2) {
    return null;
  }
  const mean = values.reduce((a, b) => a + b, 0) / values.length;
  const variance =
    values.reduce((a, b) => a + (b - mean) * (b - mean), 0) / values.length;
  return Math.sqrt(variance);
}

function fmt(n: number): string {
  return n.toFixed(4);
}

function scoreOf(confirmed: number, total: number): number {
  if (total === 0) {
    return 0;
  }
  return Math.round((confirmed / total) * 100);
}

function insufficient(prices: number[], price: number | null): RapidSignal {
  return {
    direction: "WAIT",
    score: 0,
    confirmations: 0,
    confirmationsTotal: 5,
    details: [],
    reason: "AGUARDANDO — dados insuficientes para o sinal rápido.",
    momentum: null,
    rsi: null,
    fastEma: null,
    slowEma: null,
    volatilityPct: null,
    price,
    timestamp: Date.now(),
  };
}

export function computeRapidSignal(prices: number[]): RapidSignal {
  const price = prices.length > 0 ? (prices[prices.length - 1] ?? null) : null;
  if (prices.length < SLOW_EMA + 2) {
    return insufficient(prices, price);
  }

  const fastEma = lastValue(emaSeries(prices, FAST_EMA));
  const slowEma = lastValue(emaSeries(prices, SLOW_EMA));
  const rsi = lastValue(rsiSeries(prices, RSI_PERIOD));
  const momentumBase = prices[prices.length - 1 - MOMENTUM_TICKS] ?? null;
  const momentum =
    momentumBase !== null && momentumBase !== 0 && price !== null
      ? ((price - momentumBase) / momentumBase) * 100
      : null;

  const returns: number[] = [];
  for (let i = 1; i < prices.length; i++) {
    const cur = prices[i] ?? null;
    const prev = prices[i - 1] ?? null;
    if (cur !== null && prev !== null && prev !== 0) {
      returns.push(((cur - prev) / prev) * 100);
    }
  }
  const vol = stddev(returns.slice(-VOL_TICKS));

  if (
    fastEma === null ||
    slowEma === null ||
    rsi === null ||
    momentum === null ||
    vol === null ||
    price === null
  ) {
    return insufficient(prices, price);
  }

  const volOk = vol >= VOL_MIN_PCT && vol <= VOL_MAX_PCT;

  const callDetails: RapidConfirmation[] = [
    { label: "EMA rápida acima da EMA lenta", passed: fastEma > slowEma },
    { label: "Momentum positivo", passed: momentum > 0 },
    {
      label: `RSI entre ${RSI_CALL_MIN} e ${RSI_CALL_MAX}`,
      passed: rsi >= RSI_CALL_MIN && rsi <= RSI_CALL_MAX,
    },
    { label: "Preço acima da EMA rápida", passed: price > fastEma },
    { label: "Volatilidade adequada", passed: volOk },
  ];

  const putDetails: RapidConfirmation[] = [
    { label: "EMA rápida abaixo da EMA lenta", passed: fastEma < slowEma },
    { label: "Momentum negativo", passed: momentum < 0 },
    {
      label: `RSI entre ${RSI_PUT_MIN} e ${RSI_PUT_MAX}`,
      passed: rsi >= RSI_PUT_MIN && rsi <= RSI_PUT_MAX,
    },
    { label: "Preço abaixo da EMA rápida", passed: price < fastEma },
    { label: "Volatilidade adequada", passed: volOk },
  ];

  const callConfirmed = callDetails.filter((d) => d.passed).length;
  const putConfirmed = putDetails.filter((d) => d.passed).length;

  let direction: RapidDirection = "WAIT";
  let details = callDetails;
  let confirmed = callConfirmed;
  if (callConfirmed === 0 && putConfirmed === 0) {
    direction = "WAIT";
    details = callConfirmed >= putConfirmed ? callDetails : putDetails;
    confirmed = 0;
  } else if (callConfirmed > putConfirmed) {
    direction = "CALL";
    details = callDetails;
    confirmed = callConfirmed;
  } else if (putConfirmed > callConfirmed) {
    direction = "PUT";
    details = putDetails;
    confirmed = putConfirmed;
  } else {
    direction = "WAIT";
    details = callDetails;
    confirmed = callConfirmed;
  }

  const total = 5;
  const score = scoreOf(confirmed, total);
  const label =
    direction === "CALL" ? "ALTA" : direction === "PUT" ? "BAIXA" : "sem sinal";
  const reason =
    direction === "WAIT"
      ? `AGUARDAR — sem alinhamento suficiente (${confirmed}/${total}). Momentum ${fmt(momentum)}%, RSI ${rsi.toFixed(1)}, EMA rápida ${fmt(fastEma)}, EMA lenta ${fmt(slowEma)}.`
      : `SINAL ${label} — ${confirmed}/${total} confirmações. Momentum ${fmt(momentum)}%, RSI ${rsi.toFixed(1)}, vol ${vol.toFixed(3)}%.`;

  return {
    direction,
    score,
    confirmations: confirmed,
    confirmationsTotal: total,
    details,
    reason,
    momentum,
    rsi,
    fastEma,
    slowEma,
    volatilityPct: vol,
    price,
    timestamp: Date.now(),
  };
}
