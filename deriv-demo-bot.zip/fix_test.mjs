import fs from 'fs';

const filePath = 'backend/tests/settlement.test.ts';
let content = fs.readFileSync(filePath, 'utf8');

// Fix first test - replace r.executor with setExecutorForTesting
content = content.replace(
  `r.ws = { request: async () => ({}) };
  r.executor = {
    execute: async () => ({
      contractId: "buy1",
      proposalId: "p1",
      direction: "CALL",
      stake: 44.06,
      buyPrice: 44.06,
      askPrice: 1.2345,
      payout: 1.9,
      balanceAfter: 9955.94,
    }),
  };

  await r.placeTrade("SCALPING", signal(), "CALL", 44.06);

  assert.equal(r.openTrades.length, 1);`,
`r.setExecutorForTesting({
    execute: async () => ({
      contractId: "buy1",
      proposalId: "p1",
      direction: "CALL",
      stake: 44.06,
      buyPrice: 44.06,
      askPrice: 1.2345,
      payout: 1.9,
      balanceAfter: 9955.94,
    }),
  });

  await r.placeTrade("SCALPING", signal(), "CALL", 44.06);

  assert.equal(r.openTrades.length, 1);`);

// Fix second test
content = content.replace(
`r.ws = { request: async () => ({}) };
  r.executor = {
    execute: async () => ({
      contractId: "buy2",
      proposalId: "p2",
      direction: "CALL",
      stake: 44.06,
      buyPrice: 1, // Deriv cobrou apenas 1.00 — divergência real.
      askPrice: 1.2345,
      payout: 1.9,
      balanceAfter: 9999,
    }),
  };

  await r.placeTrade("SCALPING", signal(), "CALL", 44.06);`,
`r.setExecutorForTesting({
    execute: async () => ({
      contractId: "buy2",
      proposalId: "p2",
      direction: "CALL",
      stake: 44.06,
      buyPrice: 1, // Deriv cobrou apenas 1.00 — divergência real.
      askPrice: 1.2345,
      payout: 1.9,
      balanceAfter: 9999,
    }),
  });

  await r.placeTrade("SCALPING", signal(), "CALL", 44.06);`);

fs.writeFileSync(filePath, content);
console.log('Fixed!');