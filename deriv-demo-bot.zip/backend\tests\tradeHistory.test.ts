import { test } from "node:test";
import assert from "node:assert/strict";
import fs from "node:fs";
import os from "node:os";
import path from "node:path";
import {
  TradeHistoryStore,
  type PersistedTrade,
} from "../src/storage/tradeHistory.js";

process.env.LOG_LEVEL = "error";

function tempDbPath(): { dir: string; dbPath: string } {
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), "deriv-trades-"));
  return { dir, dbPath: path.join(dir, "bot.db") };
}

function makeTrade(id: string, stake = 19, result: PersistedTrade["result"] = "WIN"): PersistedTrade {
  return {
    id,
    timestamp: 1700000000000,
    settlementTime: 1700000001000,
    symbol: "R_100",
    direction: "CALL",
    strategy: "SCALPING",
    contractType: "callput",
    duration: 30,
    durationUnit: "s",
    granularity: 60,
    stake,
    buyPrice: stake,
    entryPrice: 1.2345,
    payout: 1.9,
    result,
    profitLoss: result === "WIN" ? 17.1 : -19,
    balanceAfter: 9000,
    entryType: null,
    reason: null,
  };
}

test("TradeHistoryStore persiste e recarrega operações", () => {
  const { dir, dbPath } = tempDbPath();
  process.env.DB_PATH = dbPath;
  try {
    const store = new TradeHistoryStore();
    store.append(makeTrade("c1", 19, "WIN"));
    store.append(makeTrade("c2", 22, "LOSS"));
    assert.equal(store.list().length, 2);

    // Uma nova instância (mesma pasta) deve recarregar do disco.
    const store2 = new TradeHistoryStore();
    const loaded = store2.list();
    assert.equal(loaded.length, 2);
    assert.equal(loaded[0]?.id, "c1");
    assert.equal(loaded[0]?.stake, 19);
    assert.equal(loaded[1]?.id, "c2");
    assert.equal(loaded[1]?.stake, 22);
    assert.equal(loaded[1]?.result, "LOSS");
  } finally {
    delete process.env.DB_PATH;
    fs.rmSync(dir, { recursive: true, force: true });
  }
});

test("TradeHistoryStore ignora JSON corrompido sem lançar", () => {
  const { dir, dbPath } = tempDbPath();
  process.env.DB_PATH = dbPath;
  try {
    // Cria um arquivo inválido no caminho derivado do DB_PATH.
    const tradesPath = dbPath.replace(/\.db$/i, "") + "-trades.json";
    fs.writeFileSync(tradesPath, "{not valid json", "utf8");

    const store = new TradeHistoryStore();
    assert.equal(store.list().length, 0); // não lança; retorna vazio

    store.append(makeTrade("c1"));
    assert.equal(store.list().length, 1); // sobrescreve e segue funcional
  } finally {
    delete process.env.DB_PATH;
    fs.rmSync(dir, { recursive: true, force: true });
  }
});

test("TradeHistoryStore filtra registros inválidos na carga", () => {
  const { dir, dbPath } = tempDbPath();
  process.env.DB_PATH = dbPath;
  try {
    const tradesPath = dbPath.replace(/\.db$/i, "") + "-trades.json";
    fs.writeFileSync(
      tradesPath,
      JSON.stringify([{ id: "ok", timestamp: 123 }, { foo: "bar" }, null]),
      "utf8",
    );

    const store = new TradeHistoryStore();
    const list = store.list();
    assert.equal(list.length, 1);
    assert.equal(list[0]?.id, "ok");
  } finally {
    delete process.env.DB_PATH;
    fs.rmSync(dir, { recursive: true, force: true });
  }
});

test("update reconcilia um contrato pendente sem duplicar", () => {
  const { dir, dbPath } = tempDbPath();
  process.env.DB_PATH = dbPath;
  try {
    const store = new TradeHistoryStore();
    store.append(makeTrade("c1", 19, "PENDING"));

    // listPending deve devolver apenas pendentes.
    assert.equal(store.listPending().length, 1);

    // Reconcilia: PENDING → WIN (update, sem duplicar).
    const updated = store.update("c1", {
      result: "WIN",
      profitLoss: 17.1,
      settlementTime: 1700000002000,
    });
    assert.equal(updated, true);

    const list = store.list();
    assert.equal(list.length, 1); // não duplicou
    assert.equal(list[0]?.result, "WIN");
    assert.equal(list[0]?.profitLoss, 17.1);
    assert.equal(store.listPending().length, 0);

    // Persistência: recarrega do disco com o estado final.
    const store2 = new TradeHistoryStore();
    assert.equal(store2.list()[0]?.result, "WIN");
  } finally {
    delete process.env.DB_PATH;
    fs.rmSync(dir, { recursive: true, force: true });
  }
});

test("update retorna false para id inexistente", () => {
  const { dir, dbPath } = tempDbPath();
  process.env.DB_PATH = dbPath;
  try {
    const store = new TradeHistoryStore();
    assert.equal(store.update("nao-existe", { result: "WIN" }), false);
  } finally {
    delete process.env.DB_PATH;
    fs.rmSync(dir, { recursive: true, force: true });
  }
});
