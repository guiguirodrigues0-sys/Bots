import type { Express } from "express";
import express from "express";
import path from "node:path";
import { apiRouter } from "./routes.js";

export function createHttpServer(app: Express): void {
  app.use("/api", apiRouter);

  const frontendDist = process.env.FRONTEND_DIST;
  if (frontendDist) {
    app.use(express.static(frontendDist));
    app.get("*", (req, res, next) => {
      if (req.path.startsWith("/api")) {
        next();
        return;
      }
      res.sendFile(path.join(frontendDist, "index.html"));
    });
  }
}
