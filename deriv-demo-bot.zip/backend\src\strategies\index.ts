import { StrategyManager } from "./manager.js";
import { StrategyStore } from "./store.js";
import { StrategyRuntime } from "./runtime.js";

export const strategyStore = new StrategyStore();
const persisted = strategyStore.load();

export const strategyManager = new StrategyManager(persisted.configs);
if (persisted.activeId) {
  const selected = strategyManager.select(persisted.activeId, "restaurado da sessão anterior");
  if (!selected.ok) {
    strategyManager.select("CONFLUENCIA", "fallback após config inválida");
  }
}

export const strategyRuntime = new StrategyRuntime(strategyManager, strategyStore);

export type { StrategyManager } from "./manager.js";
export type { StrategyRuntime } from "./runtime.js";
export type { StrategyStore } from "./store.js";
