import { useEffect, useState } from "react";
import {
  getStrategies,
  getStrategyState,
  getStrategyBacktests,
  selectStrategy,
  saveStrategyConfig,
  resetStrategyConfig,
  saveStrategyRisk,
  startStrategy,
  stopStrategy,
  pauseStrategy,
  resumeStrategy,
  runStrategyBacktest,
  getMarkets,
  testAllStrategies,
  type StrategyView,
  type StrategyId,
  type StrategyRiskConfig,
  type StrategyRuntimeSnapshot,
  type StrategyStateResponse,
  type StrategyConfig,
  type BacktestResult,
  type MarketsResponse,
  type BatchTestResult,
  ALLOWED_GRANULARITIES,
  GRANULARITY_LABELS,
  durationLabel,
} from "../../api/client";
import StrategyConfigModal from "./StrategyConfigModal";
import StrategyDiagnosticPanel from "./StrategyDiagnosticPanel";
import TradeHistoryPanel from "./TradeHistoryPanel";

const PROFILE_LABEL: Record<string, string> = {
  CONSERVADOR: "Conservador",
  MODERADO: "Moderado",
  AGRESSIVO: "Agressivo",
};

const FREQ_LABEL: Record<string, string> = {
  BAIXA: "Baixa",
  MEDIA: "Média",
  ALTA: "Alta",
};

function fmtMoney(v: number | null | undefined): string {
  if (v === null || v === undefined) return "—";
  const sign = v > 0 ? "+" : "";
  return `${sign}${v.toLocaleString("pt-BR", { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`;
}

function fmtPct(v: number | null | undefined, d = 2): string {
  if (v === null || v === undefined) return "—";
  if (!Number.isFinite(v)) return "∞";
  return `${v.toFixed(d)}%`;
}

function fmtTime(ts: number | null | undefined): string {
  if (!ts) return "—";
  return new Date(ts).toLocaleTimeString("pt-BR");
}

function fmtDir(d: string): string {
  if (d === "BUY" || d === "CALL") return "ALTA";
  if (d === "SELL" || d === "PUT") return "BAIXA";
  return "AGUARDAR";
}

function dirClass(d: string): string {
  if (d === "BUY" || d === "CALL") return "signal-call";
  if (d === "SELL" || d === "PUT") return "signal-put";
  return "signal-aguardar";
}

export default function StrategiesView() {
  const [strategies, setStrategies] = useState<StrategyView[]>([]);
  const [activeId, setActiveId] = useState<StrategyId | null>(null);
  const [runtime, setRuntime] = useState<StrategyRuntimeSnapshot | null>(null);
  const [manager, setManager] = useState<StrategyStateResponse["manager"] | null>(null);
  const [backtests, setBacktests] = useState<BacktestResult[]>([]);
  const [error, setError] = useState<string | null>(null);
  const [busy, setBusy] = useState<string | null>(null);
  const [configuring, setConfiguring] = useState<StrategyView | null>(null);
  const [riskDraft, setRiskDraft] = useState<StrategyRiskConfig | null>(null);

  const [markets, setMarkets] = useState<MarketsResponse | null>(null);
  const [marketCategory, setMarketCategory] = useState<"FOREX" | "SYNTHETIC">("SYNTHETIC");
  const [selectedSymbol, setSelectedSymbol] = useState("R_100");
  const [granularity, setGranularity] = useState("60");
  const [duration, setDuration] = useState("30");
  const [durationUnit, setDurationUnit] = useState<StrategyConfig["durationUnit"]>("s");
  const [batchResult, setBatchResult] = useState<BatchTestResult | null>(null);

  const refresh = async () => {
    try {
      const [s, st, bt] = await Promise.all([getStrategies(), getStrategyState(), getStrategyBacktests()]);
      setStrategies(s.strategies);
      setActiveId(s.activeId);
      setRuntime(st.runtime);
      setManager(st.manager);
      setBacktests(bt.results);
      setRiskDraft((prev) => prev ?? s.riskConfig);
    } catch {
      setError("Não foi possível carregar as estratégias.");
    }
  };

  useEffect(() => {
    void refresh();
    const id = setInterval(() => void refresh(), 2000);
    return () => clearInterval(id);
  }, []);

  const loadMarkets = async () => {
    try {
      const m = await getMarkets();
      setMarkets(m);
    } catch (e) {
      setError(e instanceof Error ? e.message : "Conecte-se à Deriv DEMO para listar os mercados.");
    }
  };

  useEffect(() => {
    void loadMarkets();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const run = async (label: string, fn: () => Promise<void>) => {
    setBusy(label);
    setError(null);
    try {
      await fn();
      await refresh();
    } catch (e) {
      setError(e instanceof Error ? e.message : String(e));
    } finally {
      setBusy(null);
    }
  };

  const onSelect = (id: StrategyId) => run("select", () => selectStrategy(id));
  const onStart = () => run("start", startStrategy);
  const onStop = () => run("stop", stopStrategy);
  const onPause = () => run("pause", pauseStrategy);
  const onResume = () => run("resume", resumeStrategy);

  const onSaveConfig = (id: StrategyId) => async (config: Partial<StrategyConfig>) => {
    await saveStrategyConfig(id, config);
  };
  const onResetConfig = (id: StrategyId) => async () => {
    await resetStrategyConfig(id);
  };
  const onBacktest = (id: StrategyId) => async () => {
    await runStrategyBacktest(id);
  };
  const onActivate = (id: StrategyId) => async () => {
    await selectStrategy(id);
  };

  const onSaveRisk = () => {
    if (riskDraft) {
      void run("risk", () => saveStrategyRisk(riskDraft));
    }
  };

  const applyMarketDefaults = (symbol: string, cat: "FOREX" | "SYNTHETIC") => {
    setSelectedSymbol(symbol);
    if (cat === "SYNTHETIC") {
      setGranularity("60");
      setDuration("30");
      setDurationUnit("s");
    } else {
      setGranularity("60");
      setDuration("15");
      setDurationUnit("m");
    }
  };

  const onCategoryChange = (cat: "FOREX" | "SYNTHETIC") => {
    setMarketCategory(cat);
    if (cat === "SYNTHETIC") {
      const first = markets?.synthetic.find((m) => m.available) ?? markets?.synthetic[0];
      if (first) applyMarketDefaults(first.symbol, "SYNTHETIC");
    } else {
      const first = markets?.forex.find((m) => m.available) ?? markets?.forex[0];
      if (first) applyMarketDefaults(first.symbol, "FOREX");
    }
  };

  const onTestAll = () => {
    const g = Number(granularity);
    const d = Number(duration);
    if (!selectedSymbol) {
      setError("Selecione um ativo.");
      return;
    }
    void run("test-all", async () => {
      const r = await testAllStrategies({
        symbol: selectedSymbol,
        granularity: g,
        duration: d,
        durationUnit,
      });
      setBatchResult(r);
    });
  };

  const onTestDemo = () => {
    if (!activeId) {
      setError("Selecione uma estratégia antes de testar em DEMO.");
      return;
    }
    void run("demo", async () => {
      await saveStrategyConfig(activeId, {
        symbol: selectedSymbol,
        granularity: Number(granularity),
        duration: Number(duration),
        durationUnit,
      });
      await selectStrategy(activeId);
      await startStrategy();
    });
  };

  const activeStrategy = strategies.find((s) => s.metadata.id === activeId);
  const running = runtime?.state === "RUNNING";
  const paused = runtime?.state === "PAUSED";

  const updateRisk = (patch: Partial<StrategyRiskConfig>) => {
    setRiskDraft((prev) => (prev ? { ...prev, ...patch } : prev));
  };

  return (
    <div className="strat">
      <section className="panel">
        <header className="panel-head">
          <h2>Execução da estratégia</h2>
          <span className={`bot-status ${running ? "is-running" : paused ? "is-paused" : "is-stopped"}`}>
            <span className="status-dot" />
            {running ? "Ativo" : paused ? "Pausado" : "Parado"}
          </span>
        </header>
        <div className="bot-body">
          <div className="bot-asset">
            Estratégia ativa: <strong>{activeStrategy?.metadata.name ?? "Nenhuma"}</strong>
          </div>
          <div className="bot-actions">
            <button className="btn btn-primary" disabled={busy !== null || running || !activeId} onClick={onStart}>Iniciar</button>
            {paused ? (
              <button className="btn" disabled={busy !== null} onClick={onResume}>Retomar</button>
            ) : (
              <button className="btn" disabled={busy !== null || !running} onClick={onPause}>Pausar</button>
            )}
            <button className="btn btn-danger" disabled={busy !== null || !(running || paused)} onClick={onStop}>Parar</button>
          </div>
        </div>
        {runtime?.lastEvent && <p className="notice">{runtime.lastEvent}</p>}
        {runtime?.lastError && <div className="error-box"><p>{runtime.lastError}</p></div>}
        {runtime?.decisionBlockReason && (
          <p className="notice neg">Último bloqueio: {runtime.decisionBlockReason}</p>
        )}
      </section>

      {error && <div className="error-box"><p>{error}</p></div>}

      <StrategyDiagnosticPanel
        manager={manager}
        runtime={runtime}
        strategies={strategies}
        selectedSymbol={selectedSymbol}
        granularity={granularity}
      />

      <section className="panel">
        <header className="panel-head">
          <h2>Mercado e testes</h2>
          <span className="muted">Backtest histórico · simulação · DEMO</span>
        </header>
        <div className="risk-grid">
          <div className="conn-field">
            <label>Mercado</label>
            <select value={marketCategory} onChange={(e) => onCategoryChange(e.target.value as "FOREX" | "SYNTHETIC")}>
              <option value="SYNTHETIC">Índices sintéticos</option>
              <option value="FOREX">Forex</option>
            </select>
          </div>
          <div className="conn-field">
            <label>Ativo</label>
            <select value={selectedSymbol} onChange={(e) => applyMarketDefaults(e.target.value, marketCategory)}>
              {marketCategory === "SYNTHETIC"
                ? (markets?.synthetic ?? []).map((m) => (
                    <option key={m.symbol} value={m.symbol}>
                      {m.label} ({m.symbol}){m.available ? "" : " · indisponível"}
                    </option>
                  ))
                : (markets?.forex ?? []).map((m) => (
                    <option key={m.symbol} value={m.symbol}>
                      {m.label} ({m.symbol}){m.available ? "" : " · indisponível"}
                    </option>
                  ))}
            </select>
          </div>
          <div className="conn-field">
            <label>Timeframe (candles)</label>
            <select value={granularity} onChange={(e) => setGranularity(e.target.value)}>
              {ALLOWED_GRANULARITIES.map((g) => (
                <option key={g} value={g}>
                  {GRANULARITY_LABELS[g]} ({g}s)
                </option>
              ))}
            </select>
          </div>
          <div className="conn-field">
            <label>Duração</label>
            <div className="inline">
              <input type="text" value={duration} onChange={(e) => setDuration(e.target.value)} />
              <select value={durationUnit} onChange={(e) => setDurationUnit(e.target.value as StrategyConfig["durationUnit"])}>
                <option value="s">s</option>
                <option value="m">m</option>
                <option value="h">h</option>
                <option value="t">t</option>
              </select>
            </div>
          </div>
          <div className="conn-actions">
            <button className="btn" onClick={() => void loadMarkets()} disabled={busy !== null}>
              Carregar mercados
            </button>
            <button className="btn btn-primary" onClick={onTestAll} disabled={busy !== null}>
              Testar estratégias
            </button>
            <button className="btn btn-primary" onClick={onTestDemo} disabled={busy !== null || !activeId}>
              Testar em DEMO
            </button>
          </div>
        </div>
        {marketCategory === "SYNTHETIC"
          ? (() => {
              const m = markets?.synthetic.find((s) => s.symbol === selectedSymbol);
              if (!m) return null;
              return (
                <p className="notice">
                  {m.available
                    ? `${m.label} · Rise/Fall disponível`
                    : `${m.label} · contrato Rise/Fall indisponível`}
                  {m.minDuration ? ` · duração ${m.minDuration}–${m.maxDuration}` : " · duração a validar na API"}
                </p>
              );
            })()
          : (() => {
              const m = markets?.forex.find((s) => s.symbol === selectedSymbol);
              if (!m) return null;
              return (
                <p className="notice">
                  {m.available
                    ? `${m.label} · Rise/Fall disponível`
                    : `${m.label} · contrato Rise/Fall indisponível`}
                  {" · duração a validar na API"}
                </p>
              );
            })()}
        <p className="notice muted">
          O teste histórico NÃO envia ordens. O teste DEMO executa apenas a estratégia selecionada, na conta demo, respeitando risco e validação de contrato.
        </p>
      </section>

      {batchResult && (
        <section className="panel">
          <header className="panel-head">
            <h2>Comparação das estratégias — Backtest histórico (simulação)</h2>
            <span className="muted">
              {batchResult.symbol} · {batchResult.totalCandles} candles
              {batchResult.contractAvailable ? "" : " · contrato indisponível"}
            </span>
          </header>
          {batchResult.breakEvenWinRate > 0 && (
            <p className="notice muted">
              Payout {batchResult.payout.toFixed(2)} · ponto de equilíbrio{" "}
              <b>{batchResult.breakEvenWinRate.toFixed(1)}%</b> de acerto — assertividade
              abaixo disso gera prejuízo esperado.
            </p>
          )}
          {!batchResult.contractAvailable && (
            <p className="notice neg">Incompatibilidade de contrato: {batchResult.contractReason}</p>
          )}
          <table className="table">
            <thead>
              <tr>
                <th>Estratégia</th>
                <th>Sinais</th>
                <th>Operações</th>
                <th>Acertos</th>
                <th>Erros</th>
                <th>Assertividade</th>
                <th>Lucro/Prejuízo</th>
                <th>Drawdown</th>
              </tr>
            </thead>
            <tbody>
              {batchResult.results.map((r) => (
                <tr key={r.strategyId}>
                  <td>
                    {r.name}
                    {r.strategyId === "PRECISAO_EXTREMA" && <span className="muted"> *</span>}
                    {r.noSignals && <span className="muted"> (sem sinais)</span>}
                  </td>
                  <td>{r.signals.buy + r.signals.sell}</td>
                  <td>{r.metrics.trades}</td>
                  <td className="pos">{r.metrics.wins}</td>
                  <td className="neg">{r.metrics.losses}</td>
                  <td>{r.metrics.trades > 0 ? `${r.metrics.winRate.toFixed(1)}%` : "—"}</td>
                  <td className={r.metrics.netPnl >= 0 ? "pos" : "neg"}>{fmtMoney(r.metrics.netPnl)}</td>
                  <td>{r.metrics.trades > 0 ? `${r.metrics.maxDrawdownPct.toFixed(1)}%` : "—"}</td>
                </tr>
              ))}
            </tbody>
          </table>
          <p className="notice muted">
            {batchResult.note}
          </p>
          <p className="notice muted">
            * Precisão Extrema: a assertividade exibida é apenas a observada nos dados; NÃO é a meta de 98% até ser comprovada.
          </p>
        </section>
      )}

      <section className="panel">
        <header className="panel-head">
          <h2>Central de Estratégias</h2>
          <span className="muted">Uma estratégia ativa por instância</span>
        </header>
        <div className="strat-grid">
          {strategies.map((s) => (
            <div key={s.metadata.id} className={`strat-card ${s.active ? "is-active" : ""}`}>
              <div className="strat-card-head">
                <h3>
                  {s.metadata.name} — {durationLabel(s.config.duration, s.config.durationUnit)}
                </h3>
                {s.active && <span className="mode-badge">ATIVA</span>}
              </div>
              <p className="strat-desc">{s.metadata.description}</p>
              <div className="strat-meta">
                <span><b>Indicadores:</b> {s.metadata.indicators.join(", ")}</span>
                <span><b>Perfil:</b> {PROFILE_LABEL[s.metadata.profile]}</span>
                <span><b>Frequência:</b> {FREQ_LABEL[s.metadata.frequency]}</span>
                <span><b>Mercados:</b> {s.metadata.markets.join(", ")}</span>
                {s.live ? (
                  <span><b>Histórico (live):</b> {s.live.trades} ops · acerto {fmtPct(s.live.winRate)} · {fmtMoney(s.live.pnl)}</span>
                ) : (
                  <span className="muted"><b>Histórico:</b> sem dados reais suficientes</span>
                )}
              </div>
              <div className="strat-card-actions">
                <button className="btn btn-primary" disabled={busy !== null} onClick={() => onSelect(s.metadata.id)}>
                  Selecionar estratégia
                </button>
                <button className="btn" onClick={() => setConfiguring(s)}>Configurar</button>
                <button className="btn" disabled={busy !== null} onClick={() => run("backtest", () => onBacktest(s.metadata.id)())}>
                  Ver desempenho
                </button>
              </div>
            </div>
          ))}
        </div>
      </section>

      <section className="panel">
        <header className="panel-head">
          <h2>Gerenciamento de risco global</h2>
          <span className="muted">Aplica-se a todas as estratégias</span>
        </header>
        {riskDraft && (
          <div className="risk-grid">
            <div className="conn-field">
              <label>Modo da stake</label>
              <select value={riskDraft.stakeMode} onChange={(e) => updateRisk({ stakeMode: e.target.value as "PERCENT" | "FIXED" })}>
                <option value="PERCENT">Percentual</option>
                <option value="FIXED">Fixo</option>
              </select>
            </div>
            {riskDraft.stakeMode === "PERCENT" ? (
              <div className="conn-field">
                <label>Stake (%)</label>
                <input type="text" value={riskDraft.stakePercent} onChange={(e) => updateRisk({ stakePercent: Number(e.target.value) })} />
              </div>
            ) : (
              <div className="conn-field">
                <label>Stake fixa</label>
                <input type="text" value={riskDraft.fixedStake} onChange={(e) => updateRisk({ fixedStake: Number(e.target.value) })} />
              </div>
            )}
            <div className="conn-field">
              <label>Stop diário (%)</label>
              <input type="text" value={riskDraft.dailyStopPct} onChange={(e) => updateRisk({ dailyStopPct: Number(e.target.value) })} />
            </div>
            <div className="conn-field">
              <label>Meta diária (%)</label>
              <input type="text" value={riskDraft.dailyTargetPct ?? ""} onChange={(e) => updateRisk({ dailyTargetPct: e.target.value === "" ? null : Number(e.target.value) })} />
            </div>
            <div className="conn-field">
              <label>Exposição máx. (%)</label>
              <input type="text" value={riskDraft.maxExposurePct} onChange={(e) => updateRisk({ maxExposurePct: Number(e.target.value) })} />
            </div>
            <div className="conn-field">
              <label>Máx. operações simultâneas</label>
              <input type="text" value={riskDraft.maxOpenTrades} onChange={(e) => updateRisk({ maxOpenTrades: Number(e.target.value) })} />
            </div>
            <div className="conn-field">
              <label>Cooldown (s)</label>
              <input type="text" value={riskDraft.cooldownSeconds} onChange={(e) => updateRisk({ cooldownSeconds: Number(e.target.value) })} />
            </div>
            <div className="conn-field">
              <label>Perdas consecutivas (vazio = off)</label>
              <input type="text" value={riskDraft.maxConsecutiveLosses ?? ""} onChange={(e) => updateRisk({ maxConsecutiveLosses: e.target.value === "" ? null : Number(e.target.value) })} />
            </div>
            <div className="conn-actions">
              <button className="btn btn-primary" disabled={busy !== null} onClick={onSaveRisk}>Salvar risco</button>
            </div>
          </div>
        )}
        <p className="notice">
          Sem Martingale: a stake nunca aumenta automaticamente para recuperar perdas.
        </p>
      </section>

      <section className="panel">
        <header className="panel-head">
          <h2>Precisão Extrema — Meta Experimental</h2>
          <span className="mode-badge">98% · não garantido</span>
        </header>
        {(() => {
          const pe = backtests.find((b) => b.strategyId === "PRECISAO_EXTREMA");
          if (!pe) {
            return (
              <p className="notice muted">
                Rode "Ver desempenho" na estratégia Precisão Extrema para exibir a assertividade observada.
                A meta de 98% é experimental e NÃO deve ser exibida como assertividade real.
              </p>
            );
          }
          const m = pe.aggregate;
          return (
            <div className="summary">
              <div className="stat">
                <div className="stat-label">Meta experimental</div>
                <div className="stat-value">98%</div>
              </div>
              <div className="stat">
                <div className="stat-label">Assertividade observada</div>
                <div className="stat-value">{fmtPct(m.winRate, 1)}</div>
              </div>
              <div className="stat">
                <div className="stat-label">Operações</div>
                <div className="stat-value">{m.trades}</div>
              </div>
              <div className="stat">
                <div className="stat-label">IC 95% (acerto)</div>
                <div className="stat-value">
                  {m.winRateCI ? `${m.winRateCI.low.toFixed(1)}–${m.winRateCI.high.toFixed(1)}%` : "—"}
                </div>
              </div>
              <div className="stat">
                <div className="stat-label">P/L líquido (estimado)</div>
                <div className={`stat-value ${m.netPnl >= 0 ? "pos" : "neg"}`}>{fmtMoney(m.netPnl)}</div>
              </div>
              <div className="stat">
                <div className="stat-label">Drawdown máx.</div>
                <div className="stat-value">{fmtPct(m.maxDrawdownPct, 1)}</div>
              </div>
              <div className="stat">
                <div className="stat-label">Payout médio (modelo)</div>
                <div className="stat-value">{pe.avgPayout.toFixed(2)}x</div>
              </div>
              <div className="stat">
                <div className="stat-label">Expectativa</div>
                <div className={`stat-value ${m.expectancy >= 0 ? "pos" : "neg"}`}>{m.expectancy.toFixed(3)}</div>
              </div>
            </div>
          );
        })()}
        <p className="notice muted">
          A pontuação (9/9) representa apenas a quantidade de condições atendidas, não a probabilidade de vitória.
          Evite otimizar apenas para atingir 98% em dados históricos (risco de overfitting). Resultado financeiro estimado.
        </p>
      </section>

      <section className="panel">
        <header className="panel-head">
          <h2>Análise de Estratégias</h2>
        </header>

        {runtime && (
          <div className="summary">
            <div className="stat">
              <div className="stat-label">Operações (live)</div>
              <div className="stat-value">{runtime.stats.trades}</div>
            </div>
            <div className="stat">
              <div className="stat-label">Acerto</div>
              <div className="stat-value">{fmtPct(runtime.stats.winRate)}</div>
            </div>
            <div className="stat">
              <div className="stat-label">Resultado</div>
              <div className={`stat-value ${runtime.stats.pnl >= 0 ? "pos" : "neg"}`}>{fmtMoney(runtime.stats.pnl)}</div>
            </div>
            <div className="stat">
              <div className="stat-label">Regime atual</div>
              <div className="stat-value">{manager?.regime ?? "—"}</div>
            </div>
          </div>
        )}

        <table className="table">
          <thead>
            <tr>
              <th>Estratégia</th>
              <th>Ops (live)</th>
              <th>Acerto (live)</th>
              <th>Resultado (live)</th>
              <th>Backtest (teste)</th>
              <th>Acerto (teste)</th>
              <th>Profit Factor</th>
              <th>Drawdown</th>
            </tr>
          </thead>
          <tbody>
            {strategies.map((s) => {
              const bt = backtests.find((b) => b.strategyId === s.metadata.id);
              return (
                <tr key={s.metadata.id}>
                  <td>{s.metadata.name}</td>
                  <td>{s.live?.trades ?? 0}</td>
                  <td>{fmtPct(s.live?.winRate)}</td>
                  <td className={(s.live?.pnl ?? 0) >= 0 ? "pos" : "neg"}>{fmtMoney(s.live?.pnl)}</td>
                  <td>{bt ? bt.aggregate.trades : "—"}</td>
                  <td>{bt ? fmtPct(bt.aggregate.winRate) : "—"}</td>
                  <td>{bt ? (Number.isFinite(bt.aggregate.profitFactor) ? bt.aggregate.profitFactor.toFixed(2) : "∞") : "—"}</td>
                  <td>{bt ? fmtPct(bt.aggregate.maxDrawdownPct) : "—"}</td>
                </tr>
              );
            })}
          </tbody>
        </table>
        <p className="notice muted">
          Backtests usam candles históricos e NÃO são um backtest financeiro fiel — a liquidação do contrato é estimada.
          A melhor estratégia não é escolhida apenas pela taxa de acerto.
        </p>

        {manager && manager.rejectedSignals.length > 0 && (
          <>
            <h3 className="subhead">Últimas operações rejeitadas</h3>
            <table className="table">
              <thead>
                <tr><th>Horário</th><th>Estratégia</th><th>Direção</th><th>Motivo</th></tr>
              </thead>
              <tbody>
                {manager.rejectedSignals.slice().reverse().slice(0, 10).map((r, i) => (
                  <tr key={i}>
                    <td>{fmtTime(r.timestamp)}</td>
                    <td>{r.strategyId}</td>
                    <td><span className={`signal-badge ${dirClass(r.direction)}`}>{fmtDir(r.direction)}</span></td>
                    <td className="neg">{r.reason}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </>
        )}

        {manager && manager.signalHistory.length > 0 && (
          <>
            <h3 className="subhead">Últimos sinais identificados</h3>
            <table className="table">
              <thead>
                <tr><th>Horário</th><th>Direção</th><th>Preço</th><th>Motivo</th></tr>
              </thead>
              <tbody>
                {manager.signalHistory.slice().reverse().slice(0, 10).map((s, i) => (
                  <tr key={i}>
                    <td>{fmtTime(s.timestamp)}</td>
                    <td><span className={`signal-badge ${dirClass(s.direction)}`}>{fmtDir(s.direction)}</span></td>
                    <td>{s.price?.toFixed(5) ?? "—"}</td>
                    <td className="muted">{s.reason}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </>
        )}
      </section>

      <TradeHistoryPanel />

      {configuring && (
        <StrategyConfigModal
          strategyId={configuring.metadata.id}
          name={configuring.metadata.name}
          config={configuring.config}
          onClose={() => setConfiguring(null)}
          onSave={onSaveConfig(configuring.metadata.id)}
          onReset={onResetConfig(configuring.metadata.id)}
          onBacktest={async () => {
            await onBacktest(configuring.metadata.id)();
          }}
          onActivate={async () => {
            await onActivate(configuring.metadata.id)();
          }}
        />
      )}
    </div>
  );
}
