import { EventEmitter } from "node:events";
import { logger } from "../logger/index.js";
import { DerivApiClient, AuthExpiredError } from "../deriv/apiClient.js";
import { WebSocketManager } from "../deriv/wsManager.js";
import { fetchTickPrices } from "../services/marketDataService.js";
import {
  computeRapidSignal,
  type RapidSignal,
} from "../services/rapidStrategy.js";
import {
  evaluateRapidRisk,
  normalizeStake,
  type RapidRiskConfig,
} from "../services/riskManager.js";
import {
  TradeExecutor,
  ContractUnavailableError,
  ProposalValidationError,
  contractIdParam,
} from "../services/tradeExecutor.js";
import { TradeMonitor } from "../services/tradeMonitor.js";
import { getEnv } from "../config/env.js";
import { resolveRapidAsset } from "../deriv/symbols.js";
import { tradeHistoryStore } from "../storage/tradeHistory.js";
import type { SettledTrade } from "../services/tradeMonitor.js";
import type {
  Direction,
  OpenTrade,
  EntryType,
  RapidPhase,
  SplitStats,
  RapidStats,
  TradeRecord,
} from "../types.js";

export type BotMode = "SIGNAL_ONLY" | "DEMO_TRADE";
export type BotState = "STOPPED" | "RUNNING" | "PAUSED";

export interface BotSnapshot {
  state: BotState;
  mode: BotMode;
  symbol: string;
  label: string;
  contract: string;
  phase: RapidPhase;
  price: number | null;
  direction: string;
  score: number;
  confirmations: number | null;
  confirmationsTotal: number | null;
  momentum: number | null;
  rsi: number | null;
  fastEma: number | null;
  slowEma: number | null;
  volatilityPct: number | null;
  signalReason: string | null;
  openTrades: OpenTrade[];
  exposurePct: number;
  lastEntryTime: number | null;
  nextEntryAllowedAt: number | null;
  balance: number | null;
  currency: string | null;
  lastEvent: string | null;
  lastError: string | null;
  decisionBlockReason: string | null;
  stats: SplitStats;
  history: TradeRecord[];
}

const TICK_BUFFER_SIZE = 150;
const RECONNECT_DELAY_MS = 3000;
const SETTLEMENT_CHECK_INTERVAL_MS = 15000;
const SETTLEMENT_GRACE_SECONDS = 5;
const ACTIVE_EXIT_TICKS = 5;
const CONTRACT_LABEL = "RISE/FALL";

function emptyRapidStats(): RapidStats {
  return { trades: 0, wins: 0, losses: 0, pnl: 0, winRate: 0 };
}

function emptyStats(): SplitStats {
  return {
    initial: emptyRapidStats(),
    active: emptyRapidStats(),
    total: emptyRapidStats(),
    consecutiveLosses: 0,
    maxConsecutiveLosses: 0,
    initialBalance: 0,
    currentBalance: 0,
    sessionPnL: 0,
  };
}

export class Bot extends EventEmitter {
  private readonly api = new DerivApiClient();
  private readonly executor = new TradeExecutor();
  private readonly monitor = new TradeMonitor();
  private ws: WebSocketManager | null = null;
  private state: BotState = "STOPPED";
  private mode: BotMode = "SIGNAL_ONLY";

  private readonly symbol: string;
  private readonly label: string;
  private readonly duration: number;
  private readonly durationUnit: "s" | "t";
  private readonly initialThreshold: number;
  private readonly activeThreshold: number;
  private readonly minEntryIntervalMs: number;
  private readonly riskConfig: RapidRiskConfig;

  private phase: RapidPhase = "WAITING_SETUP";
  private tickPrices: number[] = [];
  private latestSignal: RapidSignal | null = null;
  private openTrades: OpenTrade[] = [];
  private history: TradeRecord[] = [];
  private stats: SplitStats = emptyStats();
  private balance: number | null = null;
  private currency: string | null = null;
  private lastEntryTime: number | null = null;
  private tradeInFlight = false;
  private tradeBlocked = false;
  private tradeBlockReason: string | null = null;
  private belowThresholdTicks = 0;
  private lastEvent: string | null = null;
  private lastError: string | null = null;
  private decisionBlockReason: string | null = null;
  private reconnectTimer: NodeJS.Timeout | null = null;
  private settlementCheckTimer: NodeJS.Timeout | null = null;
  private settlementCheckRunning = false;
  private stoppedByUser = false;

  constructor() {
    super();
    const env = getEnv();
    this.symbol = env.RAPID_SYMBOL;
    this.label = "VOLATILITY 100";
    this.duration = env.RAPID_DURATION;
    this.durationUnit = env.RAPID_DURATION_UNIT;
    this.initialThreshold = env.INITIAL_THRESHOLD;
    this.activeThreshold = env.ACTIVE_THRESHOLD;
    this.minEntryIntervalMs = env.MIN_ENTRY_INTERVAL_SECONDS * 1000;
    this.riskConfig = {
      maxOpenTrades: env.MAX_OPEN_TRADES,
      maxTotalExposurePct: env.MAX_TOTAL_EXPOSURE_PERCENT,
      activeRiskPct: env.ACTIVE_RISK_PERCENT,
      initialRiskPct: env.INITIAL_RISK_PERCENT,
      maxConsecutiveLosses: env.BOT_MAX_CONSECUTIVE_LOSSES,
      dailyStopPct: env.BOT_DAILY_STOP_PERCENT,
      dailyTargetPct: env.BOT_DAILY_TARGET_PERCENT,
    };
    this.monitor.onSettled((settled) => this.handleSettled(settled));
  }

  getState(): BotState {
    return this.state;
  }

  getMode(): BotMode {
    return this.mode;
  }

  async start(mode: BotMode = "DEMO_TRADE"): Promise<void> {
    if (this.state === "RUNNING") {
      return;
    }
    this.mode = mode;
    this.stoppedByUser = false;
    this.stats = emptyStats();
    this.openTrades = [];
    this.history = [];
    this.tickPrices = [];
    this.latestSignal = null;
    this.tradeInFlight = false;
    this.tradeBlocked = false;
    this.tradeBlockReason = null;
    this.phase = "WAITING_SETUP";
    this.belowThresholdTicks = 0;
    this.lastEntryTime = null;
    this.setState("RUNNING");
    this.setEvent(mode === "DEMO_TRADE" ? "BOT INICIADO (DEMO TRADE)" : "BOT INICIADO (SINAL)");
    logger.info("Bot rápido iniciado", { mode, symbol: this.symbol });
    this.startSettlementChecks();
    await this.connectAndRun();
  }

  pause(): void {
    if (this.state !== "RUNNING") {
      return;
    }
    this.setState("PAUSED");
    this.setEvent("BOT PAUSADO");
    logger.info("Bot pausado");
  }

  resume(): void {
    if (this.state !== "PAUSED") {
      return;
    }
    this.setState("RUNNING");
    this.setEvent("BOT RETOMADO");
    logger.info("Bot retomado");
  }

  async stop(): Promise<void> {
    this.stoppedByUser = true;
    if (this.reconnectTimer) {
      clearTimeout(this.reconnectTimer);
      this.reconnectTimer = null;
    }
    this.stopSettlementChecks();
    this.setState("STOPPED");
    this.setEvent("BOT PARADO");
    logger.info("Bot parado");
    await this.ws?.close();
    this.ws = null;
  }

  getSnapshot(): BotSnapshot {
    return {
      state: this.state,
      mode: this.mode,
      symbol: this.symbol,
      label: this.label,
      contract: `${CONTRACT_LABEL} — ${this.duration}${this.durationUnit === "s" ? " SEGUNDOS" : " TICKS"}`,
      phase: this.phase,
      price: this.latestSignal?.price ?? null,
      direction: this.latestSignal?.direction ?? "WAIT",
      score: this.latestSignal?.score ?? 0,
      confirmations: this.latestSignal?.confirmations ?? null,
      confirmationsTotal: this.latestSignal?.confirmationsTotal ?? null,
      momentum: this.latestSignal?.momentum ?? null,
      rsi: this.latestSignal?.rsi ?? null,
      fastEma: this.latestSignal?.fastEma ?? null,
      slowEma: this.latestSignal?.slowEma ?? null,
      volatilityPct: this.latestSignal?.volatilityPct ?? null,
      signalReason: this.latestSignal?.reason ?? null,
      openTrades: this.openTrades.map((t) => ({ ...t })),
      exposurePct: this.currentExposurePct(),
      lastEntryTime: this.lastEntryTime,
      nextEntryAllowedAt: this.lastEntryTime
        ? this.lastEntryTime + this.minEntryIntervalMs
        : null,
      balance: this.balance,
      currency: this.currency,
      lastEvent: this.lastEvent,
      lastError: this.lastError,
      decisionBlockReason: this.decisionBlockReason,
      stats: this.publicStats(),
      history: this.history.slice(-100),
    };
  }

  private publicStats(): SplitStats {
    const s = this.stats;
    return {
      initial: { ...s.initial },
      active: { ...s.active },
      total: { ...s.total },
      consecutiveLosses: s.consecutiveLosses,
      maxConsecutiveLosses: s.maxConsecutiveLosses,
      initialBalance: s.initialBalance,
      currentBalance: s.currentBalance,
      sessionPnL: s.sessionPnL,
    };
  }

  private setState(state: BotState): void {
    this.state = state;
    this.emit("state", state);
  }

  private setEvent(event: string): void {
    this.lastEvent = event;
    this.emit("event", event);
  }

  private currentExposurePct(): number {
    if (!this.balance || this.balance <= 0) {
      return 0;
    }
    const open = this.openTrades.filter((t) => t.status === "OPEN");
    const totalStake = open.reduce((a, t) => a + t.stake, 0);
    return (totalStake / this.balance) * 100;
  }

  private async connectAndRun(): Promise<void> {
    try {
      const url = await this.api.getDemoWebSocketUrl();
      const ws = new WebSocketManager();
      this.ws = ws;

      ws.onMessage((msg) => this.handleMessage(msg));
      ws.onClose(() => this.handleDisconnect());

      await ws.connect(url);

      const resolved = await resolveRapidAsset(ws, this.symbol);
      if (!resolved.available) {
        throw new Error(`${this.symbol} indisponível (sem contrato Rise/Fall).`);
      }

      const ticks = await fetchTickPrices(ws, this.symbol, TICK_BUFFER_SIZE);
      this.tickPrices = ticks.map((t) => t.quote);
      if (this.tickPrices.length > 0) {
        this.latestSignal = computeRapidSignal(this.tickPrices);
      }
      logger.info("Histórico de ticks carregado", {
        symbol: this.symbol,
        count: this.tickPrices.length,
      });

      const balanceMsg = await ws.request({ balance: 1 });
      const b = balanceMsg.balance as { balance: number; currency: string } | undefined;
      if (b) {
        this.updateBalance(b.balance, b.currency);
      }

      await ws.request({ ticks: this.symbol, subscribe: 1 });
      await this.resubscribeOpenTrades(ws);
      this.setEvent(this.mode === "DEMO_TRADE" ? "DEMO TRADE ATIVO" : "SIGNAL ONLY ATIVO");
    } catch (err) {
      this.lastError = err instanceof Error ? err.message : String(err);
      logger.error("Falha ao iniciar bot", { message: this.lastError });
      if (err instanceof AuthExpiredError) {
        this.setEvent("CONEXÃO EXPIRADA — RECONECTE SUA CONTA DEMO");
      } else {
        this.setEvent("ERRO DA API");
      }
      this.stopSettlementChecks();
      this.setState("STOPPED");
    }
  }

  private handleMessage(msg: Record<string, any>): void {
    if (this.state !== "RUNNING" && this.state !== "PAUSED") {
      return;
    }
    this.monitor.handleMessage(msg);
    if (msg.msg_type === "tick" && msg.tick?.symbol === this.symbol) {
      const tick = msg.tick as { quote: number; epoch: number };
      this.onTick(tick.quote);
    } else if (msg.msg_type === "balance" && msg.balance) {
      const b = msg.balance as { balance: number; currency: string };
      this.updateBalance(b.balance, b.currency);
    }
  }

  private onTick(quote: number): void {
    this.tickPrices.push(quote);
    if (this.tickPrices.length > TICK_BUFFER_SIZE) {
      this.tickPrices = this.tickPrices.slice(-TICK_BUFFER_SIZE);
    }
    this.latestSignal = computeRapidSignal(this.tickPrices);

    if (this.state !== "RUNNING") {
      return;
    }
    if (this.mode === "DEMO_TRADE") {
      void this.evaluateAndMaybeTrade();
    }
  }

  private updateBalance(balance: number, currency: string): void {
    this.balance = balance;
    this.currency = currency;
    this.stats.currentBalance = balance;
    if (this.stats.initialBalance === 0) {
      this.stats.initialBalance = balance;
    }
    this.stats.sessionPnL = balance - this.stats.initialBalance;
    this.emit("balance", { balance, currency });
  }

  private async evaluateAndMaybeTrade(): Promise<void> {
    const trace = {
      symbol: this.symbol,
      confirmations: "-",
      score: 0,
      threshold: 0,
      direction: "WAIT",
      signalValid: false,
      stateAllowsEntry: false,
      riskAllowsEntry: false,
      cooldownAllowsEntry: false,
      exposureAllowsEntry: false,
      blockReason: null as string | null,
    };

    const signal = this.latestSignal;
    if (signal) {
      trace.confirmations = `${signal.confirmations}/${signal.confirmationsTotal}`;
      trace.score = signal.score;
      trace.direction = signal.direction;
    }

    const threshold =
      this.phase === "WAITING_SETUP" ? this.initialThreshold : this.activeThreshold;
    trace.threshold = threshold;

    trace.signalValid =
      !!signal && signal.direction !== "WAIT" && signal.score >= threshold;

    trace.stateAllowsEntry =
      this.state === "RUNNING" && !this.tradeBlocked && !this.tradeInFlight;
    if (!trace.stateAllowsEntry) {
      trace.blockReason = this.tradeBlocked
        ? `Contrato/proposta previamente bloqueada${this.tradeBlockReason ? `: ${this.tradeBlockReason}` : ""}`
        : this.tradeInFlight
          ? "Operação anterior ainda em execução"
          : "Bot não está em execução";
    }

    if (!trace.stateAllowsEntry) {
      this.decisionBlockReason = trace.blockReason;
      if (trace.signalValid) this.logDecision(trace);
      return;
    }

    if (!this.ws || this.balance === null || this.currency === null) {
      trace.blockReason = this.balance === null ? "Saldo não disponível" : "Conexão WebSocket indisponível";
      this.decisionBlockReason = trace.blockReason;
      if (trace.signalValid) this.logDecision(trace);
      return;
    }

    if (!signal || !trace.signalValid) {
      if (this.phase === "ACTIVE_MODE") {
        this.belowThresholdTicks += 1;
        if (this.belowThresholdTicks >= ACTIVE_EXIT_TICKS) {
          this.phase = "WAITING_SETUP";
          this.belowThresholdTicks = 0;
          this.setEvent("MODO ATIVO ENCERRADO — AGUARDANDO SETUP");
          logger.info("Saída do ACTIVE_MODE", { reason: "contexto desapareceu" });
        }
      } else {
        this.belowThresholdTicks = 0;
      }
      trace.blockReason =
        !signal || signal.direction === "WAIT"
          ? "Sem direção confirmada (WAIT)"
          : `Score ${signal.score} abaixo do threshold ${threshold}`;
      this.decisionBlockReason = trace.blockReason;
      if (signal && signal.direction !== "WAIT") this.logDecision(trace);
      return;
    }

    if (this.phase === "ACTIVE_MODE") {
      this.belowThresholdTicks = 0;
    }

    const risk = evaluateRapidRisk(
      {
        openCount: this.openTrades.filter((t) => t.status === "OPEN").length,
        exposurePct: this.currentExposurePct(),
        consecutiveLosses: this.stats.consecutiveLosses,
        pnlPct:
          this.stats.initialBalance > 0
            ? (this.stats.sessionPnL / this.stats.initialBalance) * 100
            : 0,
      },
      this.riskConfig,
    );
    trace.riskAllowsEntry = risk.ok;
    trace.exposureAllowsEntry =
      this.openTrades.filter((t) => t.status === "OPEN").length < this.riskConfig.maxOpenTrades &&
      this.currentExposurePct() < this.riskConfig.maxTotalExposurePct;
    if (!risk.ok) {
      if (this.stats.consecutiveLosses >= this.riskConfig.maxConsecutiveLosses) {
        this.decisionBlockReason = "Limite de perdas atingido";
        trace.blockReason = this.decisionBlockReason;
        this.logDecision(trace);
        this.setEvent("BOT PARADO — LIMITE DE PERDAS ATINGIDO");
        await this.stop();
        return;
      }
      trace.blockReason = risk.reason;
      this.decisionBlockReason = risk.reason;
      this.logDecision(trace);
      this.setEvent(risk.reason);
      logger.warn("Operação bloqueada pelo risco", { reason: risk.reason });
      return;
    }

    if (this.lastEntryTime !== null) {
      const elapsed = Date.now() - this.lastEntryTime;
      if (elapsed < this.minEntryIntervalMs) {
        trace.blockReason = `Cooldown (próxima entrada em ${Math.ceil(
          (this.minEntryIntervalMs - elapsed) / 1000,
        )}s)`;
        this.decisionBlockReason = trace.blockReason;
        this.logDecision(trace);
        return;
      }
    }
    trace.cooldownAllowsEntry = true;

    const direction: Direction = signal.direction === "PUT" ? "PUT" : "CALL";
    const entryType: EntryType =
      this.phase === "WAITING_SETUP" ? "INITIAL" : "ACTIVE";
    trace.blockReason = null;
    this.decisionBlockReason = null;
    this.logDecision(trace, entryType);
    await this.placeTrade(direction, entryType, signal.score);
  }

  private logDecision(
    trace: Record<string, unknown>,
    entryType?: EntryType,
  ): void {
    logger.info("INITIAL DECISION", {
      symbol: trace.symbol,
      confirmations: trace.confirmations,
      score: trace.score,
      threshold: trace.threshold,
      direction: trace.direction,
      signalValid: trace.signalValid,
      stateAllowsEntry: trace.stateAllowsEntry,
      riskAllowsEntry: trace.riskAllowsEntry,
      cooldownAllowsEntry: trace.cooldownAllowsEntry,
      exposureAllowsEntry: trace.exposureAllowsEntry,
      entryType: entryType ?? null,
      blockReason: trace.blockReason,
    });
  }

  private async placeTrade(
    direction: Direction,
    entryType: EntryType,
    score: number,
  ): Promise<void> {
    if (!this.ws || this.balance === null) {
      return;
    }
    const riskPct =
      entryType === "INITIAL"
        ? this.riskConfig.initialRiskPct
        : this.riskConfig.activeRiskPct;
    const rawStake = (this.balance * riskPct) / 100;
    const stake = normalizeStake(rawStake, this.currency ?? "USD");
    if (!Number.isFinite(stake) || stake <= 0) {
      this.lastError = "Stake inválida após normalização.";
      this.decisionBlockReason = "Stake inválida";
      this.setEvent("STAKE INVÁLIDA — OPERAÇÃO NÃO EXECUTADA");
      logger.error("Stake inválida", { rawStake, stake });
      return;
    }

    this.tradeInFlight = true;
    try {
      const trade = await this.executor.execute(
        this.ws,
        this.symbol,
        direction,
        stake,
        this.duration,
        this.durationUnit,
        this.currency ?? "USD",
      );
      const entryTime = Date.now();
      const open: OpenTrade = {
        contractId: trade.contractId,
        proposalId: trade.proposalId,
        symbol: this.symbol,
        direction,
        stake,
        entryTime,
        durationSeconds: this.durationUnit === "s" ? this.duration : 0,
        durationUnit: this.durationUnit,
        askPrice: trade.askPrice,
        payout: trade.payout,
        entryType,
        status: "OPEN",
        profit: null,
        settlementTime: null,
      };
      this.openTrades.push(open);
      this.lastEntryTime = entryTime;
      if (entryType === "INITIAL") {
        this.phase = "ACTIVE_MODE";
        this.belowThresholdTicks = 0;
      }
      this.setEvent(
        `OPERAÇÃO ${entryType} ABERTA — ${direction} ${stake.toFixed(2)} (${this.duration}${this.durationUnit})`,
      );
      logger.info("Operação aberta", {
        symbol: this.symbol,
        direction,
        entryType,
        stake,
        askPrice: trade.askPrice,
        payout: trade.payout,
        score,
        contractId: trade.contractId,
        proposalId: trade.proposalId,
      });
      try {
        await this.subscribeOpenContract(this.ws, trade.contractId);
      } catch (err) {
        logger.warn("Falha ao assinar contrato aberto; a conferência periódica cuidará do resultado", {
          contractId: trade.contractId,
          message: err instanceof Error ? err.message : String(err),
        });
      }
    } catch (err) {
      this.lastError = err instanceof Error ? err.message : String(err);
      if (
        err instanceof ContractUnavailableError ||
        err instanceof ProposalValidationError
      ) {
        this.tradeBlocked = true;
        this.tradeBlockReason = this.lastError;
        this.setEvent(`OPERAÇÃO BLOQUEADA — ${this.lastError}`);
        logger.error("Operação bloqueada por validação de contrato/proposta", {
          message: this.lastError,
        });
      } else {
        this.setEvent("ERRO AO OPERAR");
        logger.error("Falha ao executar operação", { message: this.lastError });
      }
    } finally {
      this.tradeInFlight = false;
    }
  }

  private subscribeOpenContract(ws: WebSocketManager, contractId: string): Promise<unknown> {
    return ws.request({
      proposal_open_contract: 1,
      contract_id: contractIdParam(contractId),
      subscribe: 1,
    });
  }

  private async resubscribeOpenTrades(ws: WebSocketManager): Promise<void> {
    for (const t of this.openTrades) {
      if (t.status !== "OPEN") {
        continue;
      }
      try {
        await this.subscribeOpenContract(ws, t.contractId);
        logger.info("Contrato aberto re-assinado após reconexão", { contractId: t.contractId });
      } catch (err) {
        logger.warn("Falha ao re-assinar contrato aberto", {
          contractId: t.contractId,
          message: err instanceof Error ? err.message : String(err),
        });
      }
    }
  }

  private startSettlementChecks(): void {
    this.stopSettlementChecks();
    this.settlementCheckTimer = setInterval(() => {
      void this.reconcileExpiredTrades();
    }, SETTLEMENT_CHECK_INTERVAL_MS);
  }

  private stopSettlementChecks(): void {
    if (this.settlementCheckTimer) {
      clearInterval(this.settlementCheckTimer);
      this.settlementCheckTimer = null;
    }
  }

  /**
   * Consulta na API os contratos cuja duração já terminou e que continuam
   * abertos localmente. A resposta passa pelo mesmo fluxo de mensagens, então
   * a liquidação é tratada por handleSettled (que ignora duplicatas).
   */
  private async reconcileExpiredTrades(): Promise<void> {
    const ws = this.ws;
    if (this.settlementCheckRunning || !ws || !ws.isConnected) {
      return;
    }
    this.settlementCheckRunning = true;
    try {
      const now = Date.now();
      const expired = this.openTrades.filter(
        (t) =>
          t.status === "OPEN" &&
          t.durationSeconds > 0 &&
          now - t.entryTime >= (t.durationSeconds + SETTLEMENT_GRACE_SECONDS) * 1000,
      );
      for (const t of expired) {
        try {
          await ws.request({
            proposal_open_contract: 1,
            contract_id: contractIdParam(t.contractId),
          });
        } catch (err) {
          logger.warn("Falha ao consultar contrato vencido", {
            contractId: t.contractId,
            message: err instanceof Error ? err.message : String(err),
          });
        }
      }
    } finally {
      this.settlementCheckRunning = false;
    }
  }

  private handleSettled(settled: SettledTrade): void {
    const open = this.openTrades.find(
      (t) => t.status === "OPEN" && t.contractId === settled.contractId,
    );
    if (!open) {
      return;
    }

    open.status = "SETTLED";
    open.profit = settled.profitLoss;
    open.settlementTime = Date.now();

    const bucket = open.entryType === "INITIAL" ? "initial" : "active";
    this.stats[bucket].trades += 1;
    this.stats.total.trades += 1;
    if (settled.result === "WIN") {
      this.stats[bucket].wins += 1;
      this.stats.total.wins += 1;
      this.stats.consecutiveLosses = 0;
    } else if (settled.result === "LOSS") {
      this.stats[bucket].losses += 1;
      this.stats.total.losses += 1;
      this.stats.consecutiveLosses += 1;
      if (this.stats.consecutiveLosses > this.stats.maxConsecutiveLosses) {
        this.stats.maxConsecutiveLosses = this.stats.consecutiveLosses;
      }
    }
    this.stats[bucket].pnl += settled.profitLoss;
    this.stats.total.pnl += settled.profitLoss;
    this.recalcWinRates();

    this.history.push({
      id: open.contractId,
      timestamp: open.entryTime,
      symbol: open.symbol,
      direction: open.direction,
      stake: open.stake,
      entryPrice: open.askPrice,
      score: open.entryType === "INITIAL" ? this.initialThreshold : this.activeThreshold,
      marketCondition: "INDEFINIDO",
      strategy: "NENHUMA",
      result:
        settled.result === "WIN"
          ? "WIN"
          : settled.result === "LOSS"
            ? "LOSS"
            : "UNKNOWN",
      profitLoss: settled.profitLoss,
      balanceAfter: this.balance,
      entryType: open.entryType,
    });

    // Persiste a operação liquidada (histórico de auditoria).
    tradeHistoryStore.append({
      id: open.contractId,
      timestamp: open.entryTime,
      settlementTime: open.settlementTime ?? Date.now(),
      symbol: open.symbol,
      direction: open.direction,
      strategy: "RAPID",
      contractType: "callput",
      duration: this.duration,
      durationUnit: this.durationUnit,
      granularity: null,
      stake: open.stake,
      buyPrice: open.askPrice,
      entryPrice: open.askPrice,
      payout: open.payout,
      result:
        settled.result === "WIN"
          ? "WIN"
          : settled.result === "LOSS"
            ? "LOSS"
            : "UNKNOWN",
      profitLoss: settled.profitLoss,
      balanceAfter: this.balance,
      entryType: open.entryType,
      reason: null,
    });

    const sign = settled.profitLoss >= 0 ? "+" : "";
    this.setEvent(
      `RESULTADO ${open.entryType} — ${settled.result} (${sign}${settled.profitLoss.toFixed(2)})`,
    );
    logger.info("Resultado da operação", {
      ...settled,
      entryType: open.entryType,
      balance: this.balance,
    });

    if (this.stats.consecutiveLosses >= this.riskConfig.maxConsecutiveLosses) {
      this.setEvent("BOT PARADO — LIMITE DE PERDAS ATINGIDO");
      void this.stop();
    }
  }

  private recalcWinRates(): void {
    for (const key of ["initial", "active", "total"] as const) {
      const s = this.stats[key];
      s.winRate = s.trades > 0 ? (s.wins / s.trades) * 100 : 0;
    }
  }

  private handleDisconnect(): void {
    if (this.stoppedByUser || this.state === "STOPPED") {
      return;
    }
    this.setEvent("WEBSOCKET DESCONECTADO");
    logger.warn("WebSocket desconectado; agendando reconexão");
    if (this.reconnectTimer) {
      clearTimeout(this.reconnectTimer);
    }
    this.reconnectTimer = setTimeout(() => {
      this.reconnectTimer = null;
      if (this.state !== "STOPPED" && !this.stoppedByUser) {
        this.setEvent("WEBSOCKET RECONECTADO");
        this.connectAndRun().catch((err) => {
          this.lastError = err instanceof Error ? err.message : String(err);
          logger.error("Falha na reconexão", { message: this.lastError });
        });
      }
    }, RECONNECT_DELAY_MS);
  }
}
