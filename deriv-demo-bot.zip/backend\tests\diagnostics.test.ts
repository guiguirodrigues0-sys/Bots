import { test } from "node:test";
import assert from "node:assert/strict";
import type { Candle } from "../src/types.js";
import { createStrategy } from "../src/strategies/registry.js";
import { defaultConfig, STRATEGY_IDS } from "../src/strategies/definitions.js";
import { diagnoseStrategiesOnCandles } from "../src/strategies/diagnostics.js";
import type { StrategySignal } from "../src/strategies/types.js";

process.env.LOG_LEVEL = "error";

function mk(closes: number[]): Candle[] {
  const out: Candle[] = [];
  for (let i = 0; i < closes.length; i++) {
    const close = closes[i]!;
    const open = i === 0 ? close : closes[i - 1]!;
    out.push({
      time: i * 60,
      open,
      high: Math.max(open, close) + 0.02,
      low: Math.min(open, close) - 0.02,
      close,
    });
  }
  return out;
}

function uptrend(n: number, step = 0.02): Candle[] {
  const closes: number[] = [];
  let c = 100;
  for (let i = 0; i < n; i++) {
    closes.push(c);
    c += step + (i % 4) * 0.005;
  }
  return mk(closes);
}

function downtrend(n: number, step = 0.02): Candle[] {
  const closes: number[] = [];
  let c = 100;
  for (let i = 0; i < n; i++) {
    closes.push(c);
    c -= step + (i % 4) * 0.005;
  }
  return mk(closes);
}

/** Oscilação lateral (baixa tendência): indicadores válidos, sem sinal claro. */
function sideways(n: number): Candle[] {
  const closes: number[] = [];
  for (let i = 0; i < n; i++) {
    closes.push(100 + Math.sin(i / 5) * 0.5);
  }
  return mk(closes);
}

/** Queda seguida de alta: gera cruzamento de EMAs/MACD para cima. */
function downThenUp(downN: number, downStep: number, upN: number, upStep: number): Candle[] {
  const closes: number[] = [];
  let c = 100;
  for (let i = 0; i < downN; i++) {
    closes.push(c);
    c -= downStep;
  }
  for (let i = 0; i < upN; i++) {
    closes.push(c);
    c += upStep;
  }
  return mk(closes);
}

/** Alta seguida de queda: gera cruzamento para baixo. */
function upThenDown(upN: number, upStep: number, downN: number, downStep: number): Candle[] {
  const closes: number[] = [];
  let c = 100;
  for (let i = 0; i < upN; i++) {
    closes.push(c);
    c += upStep;
  }
  for (let i = 0; i < downN; i++) {
    closes.push(c);
    c -= downStep;
  }
  return mk(closes);
}

/** Tendência com ruído (para MACD_ADX). */
function trend(n: number, step: number, noise: number, down = false): Candle[] {
  const closes: number[] = [];
  let c = 100;
  for (let i = 0; i < n; i++) {
    closes.push(c);
    const s = (down ? -step : step) + (i % 5) * noise * (i % 2 === 0 ? 1 : -1);
    c += s;
  }
  return mk(closes);
}

/** Rally forte, recuo até a EMA50 e retomada (para TENDENCIA). */
function rallyPullback(): Candle[] {
  const closes: number[] = [];
  let c = 100;
  for (let i = 0; i < 200; i++) {
    closes.push(c);
    c += 0.1;
  }
  for (let i = 0; i < 10; i++) {
    closes.push(c);
    c -= 0.2;
  }
  for (let i = 0; i < 20; i++) {
    closes.push(c);
    c += 0.01;
  }
  return mk(closes);
}

function scan(id: Parameters<typeof createStrategy>[0], candles: Candle[]): StrategySignal[] {
  const strategy = createStrategy(id);
  const config = defaultConfig(id);
  const signals: StrategySignal[] = [];
  for (let i = 0; i < candles.length; i++) {
    strategy.onCandle(candles[i]!);
    signals.push(strategy.evaluateSignal(candles.slice(0, i + 1), config));
  }
  strategy.dispose();
  return signals;
}

// -------------------------------------------------------------- Diagnóstico

test("diagnoseStrategiesOnCandles retorna as oito estratégias", () => {
  const r = diagnoseStrategiesOnCandles(uptrend(300), "R_100", 60);
  assert.equal(r.results.length, 8);
  for (const e of r.results) {
    assert.equal(e.evaluations, 300);
    assert.equal(e.errors, 0);
    assert.equal(e.buy + e.sell + e.wait, 300);
  }
});

test("diagnoseStrategiesOnCandles não marca ausência legítima como falha", () => {
  const r = diagnoseStrategiesOnCandles(sideways(300), "R_100", 60);
  for (const e of r.results) {
    assert.equal(e.errors, 0);
    assert.notEqual(e.status, "ERRO");
  }
});

test("diagnoseStrategiesOnCandles detecta sinais em tendência (rompimento)", () => {
  const r = diagnoseStrategiesOnCandles(uptrend(400), "R_100", 60);
  const romp = r.results.find((x) => x.strategyId === "ROMPIMENTO");
  assert.ok(romp);
  assert.ok(romp.buy > 0, "ROMPIMENTO deveria gerar BUY em tendência de alta");
  assert.equal(romp.sell, 0);
  assert.equal(romp.status, "OK");
});

// --------------------------------------------------------- Códigos de motivo

for (const id of STRATEGY_IDS) {
  test(`${id}: candles vazios geram WAIT com INSUFFICIENT_CANDLES`, () => {
    const strategy = createStrategy(id);
    const signal = strategy.evaluateSignal([], defaultConfig(id));
    assert.equal(signal.direction, "WAIT");
    assert.equal(signal.reasonCode, "INSUFFICIENT_CANDLES");
  });

  test(`${id}: sinal de espera sempre carrega um motivo padronizado`, () => {
    const signals = scan(id, sideways(300));
    for (const s of signals) {
      if (s.direction === "WAIT") {
        assert.ok(
          s.reasonCode === "INSUFFICIENT_CANDLES" ||
            s.reasonCode === "INVALID_INDICATOR" ||
            s.reasonCode === "NO_SIGNAL",
          `${id} retornou WAIT sem reasonCode válido (${s.reasonCode})`,
        );
      } else {
        assert.equal(s.reasonCode, null);
      }
    }
  });
}

test("WAIT por critérios não atendidos usa NO_SIGNAL (não INSUFFICIENT_CANDLES)", () => {
  const signals = scan("CONFLUENCIA", sideways(300));
  const last = signals[signals.length - 1]!;
  assert.notEqual(last.reasonCode, "INSUFFICIENT_CANDLES");
});

// ------------------------------------------------- Cenários controlados (BUY/SELL)

test("ROMPIMENTO: tendência de alta gera BUY e de baixa gera SELL", () => {
  const up = scan("ROMPIMENTO", uptrend(400));
  const down = scan("ROMPIMENTO", downtrend(400));
  assert.ok(up.some((s) => s.direction === "BUY"), "deveria gerar BUY em alta");
  assert.ok(down.some((s) => s.direction === "SELL"), "deveria gerar SELL em baixa");
});

test("SCALPING: cruzamento de alta gera BUY e de baixa gera SELL", () => {
  const up = scan("SCALPING", downThenUp(60, 0.05, 30, 0.05));
  const down = scan("SCALPING", upThenDown(60, 0.05, 30, 0.05));
  assert.ok(up.some((s) => s.direction === "BUY"), "deveria gerar BUY no cruzamento de alta");
  assert.ok(down.some((s) => s.direction === "SELL"), "deveria gerar SELL no cruzamento de baixa");
});

test("MACD_ADX: tendência de alta gera BUY e de baixa gera SELL", () => {
  const up = scan("MACD_ADX", trend(400, 0.02, 0.01));
  const down = scan("MACD_ADX", trend(400, 0.02, 0.01, true));
  assert.ok(up.some((s) => s.direction === "BUY"), "deveria gerar BUY em alta");
  assert.ok(down.some((s) => s.direction === "SELL"), "deveria gerar SELL em baixa");
});

test("TENDENCIA: recuo até a EMA50 seguido de retomada gera BUY", () => {
  const signals = scan("TENDENCIA", rallyPullback());
  assert.ok(signals.some((s) => s.direction === "BUY"), "deveria gerar BUY após recuo");
});

test("tendência de alta nunca gera SELL; tendência de baixa nunca gera BUY", () => {
  for (const id of [
    "CONFLUENCIA",
    "SCALPING",
    "TENDENCIA",
    "MACD_ADX",
    "ROMPIMENTO",
    "PRECISAO_EXTREMA",
  ] as const) {
    const up = scan(id, uptrend(300));
    const down = scan(id, downtrend(300));
    assert.ok(!up.some((s) => s.direction === "SELL"), `${id} gerou SELL em alta`);
    assert.ok(!down.some((s) => s.direction === "BUY"), `${id} gerou BUY em baixa`);
  }
});

// --------------------------------------------------------- Recuperação de erro

test("estratégia se recupera após candles vazios/inválidos (sem estado corrompido)", () => {
  const strategy = createStrategy("CONFLUENCIA");
  const config = defaultConfig("CONFLUENCIA");
  strategy.initialize();
  const first = strategy.evaluateSignal([], config);
  assert.equal(first.direction, "WAIT");
  assert.equal(first.reasonCode, "INSUFFICIENT_CANDLES");

  const candles = uptrend(300);
  for (let i = 0; i < candles.length; i++) {
    strategy.onCandle(candles[i]!);
    const s = strategy.evaluateSignal(candles.slice(0, i + 1), config);
    assert.ok(["BUY", "SELL", "WAIT"].includes(s.direction));
  }
  strategy.dispose();
});

test("candles duplicados não corrompem o buffer (mesma janela de tempo)", () => {
  const candles = uptrend(50);
  const last = candles[candles.length - 1]!;
  const strategy = createStrategy("ROMPIMENTO");
  const config = defaultConfig("ROMPIMENTO");
  // Avalia a série duas vezes com o último candle repetido: não deve lançar.
  for (let i = 0; i < candles.length; i++) {
    strategy.onCandle(candles[i]!);
  }
  strategy.onCandle(last); // candle duplicado (mesma janela)
  const s = strategy.evaluateSignal(candles, config);
  assert.ok(["BUY", "SELL", "WAIT"].includes(s.direction));
  strategy.dispose();
});
