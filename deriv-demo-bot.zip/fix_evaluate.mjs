import fs from 'fs';

const filePath = 'backend/src/strategies/runtime.ts';
let content = fs.readFileSync(filePath, 'utf8');

// Fix the trade.contractId reference in evaluateAndMaybeTrade
content = content.replace(
  'if (!this.reserveSlot(trade.contractId, stake, config.symbol)) {',
  'const tempContractId = `temp_${Date.now()}_${Math.random().toString(36).slice(2, 9)}`;\n    if (!this.reserveSlot(tempContractId, stake, config.symbol)) {'
);

fs.writeFileSync(filePath, content);
console.log('Fixed!');