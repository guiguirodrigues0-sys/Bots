import { EventEmitter } from "node:events";
import { logger } from "../logger/index.js";
import { DerivApiClient, AuthExpiredError } from "../deriv/apiClient.js";
import { WebSocketManager, type WsMessage } from "../deriv/wsManager.js";
import {
  fetchCandles,
  CandleAggregator,
} from "../services/marketDataService.js";
import {
  TradeExecutor,
  ContractUnavailableError,
  ProposalValidationError,
  contractIdParam,
} from "../services/tradeExecutor.js";
import { TradeMonitor, type SettledTrade } from "../services/tradeMonitor.js";
import {
  evaluateStrategyRisk,
  computeEffectiveStrategyStake,
  effectiveCooldownSeconds,
  type StrategyRiskConfig,
} from "../services/riskManager.js";
import { validateStrategyContract, durationLabel } from "../deriv/symbols.js";
import { tradeHistoryStore } from "../storage/tradeHistory.js";
import { STRATEGY_IDS } from "./definitions.js";
import type { StrategyManager } from "./manager.js";
import type { StrategyStore } from "./store.js";
import type {
  StrategyDirection,
  StrategyId,
  StrategyReasonCode,
  StrategySignal,
} from "./types.js";
import type { Candle, Direction } from "../types.js";

export type StrategyRuntimeState = "STOPPED" | "RUNNING" | "PAUSED";

export interface StrategyRuntimeStats {
  trades: number;
  wins: number;
  losses: number;
  pnl: number;
  winRate: number;
  consecutiveLosses: number;
  maxConsecutiveLosses: number;
  initialBalance: number;
  currentBalance: number;
  sessionPnL: number;
}

export interface StrategyTradeRecord {
  id: string;
  timestamp: number;
  symbol: string;
  direction: Direction;
  strategyId: StrategyId;
  stake: number;
  entryPrice: number;
  result: "WIN" | "LOSS" | "PENDING" | "UNKNOWN";
  profitLoss: number | null;
}

interface OpenStrategyTrade {
  contractId: string;
  proposalId: string;
  symbol: string;
  strategyId: StrategyId;
  direction: Direction;
  stake: number;
  entryTime: number;
  duration: number;
  durationSeconds: number;
  durationUnit: string;
  granularity: number;
  askPrice: number;
  buyPrice: number | null;
  payout: number | null;
  status: "OPEN" | "SETTLED" | "PENDING" | "RESERVED";
  profit: number | null;
  reconciliationState: "PENDING_RECONCILIATION" | "RECONCILED" | "SYNC_ERROR" | "NONE";
  lastReconciliationAt: number | null;
  lastTickAt: number | null;
}

export interface StrategyRuntimeSnapshot {
  state: StrategyRuntimeState;
  activeId: StrategyId | null;
  symbol: string;
  granularity: number;
  contract: string;
  duration: number;
  durationUnit: string;
  durationLabel: string;
  price: number | null;
  lastSignal: StrategySignal | null;
  openTrades: OpenStrategyTrade[];
  exposurePct: number;
  balance: number | null;
  currency: string | null;
  lastEvent: string | null;
  lastError: string | null;
  decisionBlockReason: string | null;
  lastProposal: StrategyProposalRecord | null;
  stats: StrategyRuntimeStats;
  history: StrategyTradeRecord[];
  /** Timestamp do último tick recebido. */
  lastTickAt: number | null;
  /** Timestamp do último candle fechado processado. */
  lastCandleAt: number | null;
  /** Timestamp da última avaliação da estratégia (geração de sinal). */
  lastEvaluationAt: number | null;
  /** Estado detalhado da conexão/processamento. */
  connectionState: "CONNECTED" | "RECONNECTING" | "DISCONNECTED" | "ERROR";
}

export interface StrategyProposalRecord {
  timestamp: number;
  direction: Direction;
  stake: number;
  accepted: boolean;
  detail: string;
}

const RECONNECT_DELAY_MS = 3000;
const CONTRACT_LABEL = "RISE/FALL";

/**
 * Traduz o motivo textual do gerenciamento de risco em um código padronizado.
 */
function riskReasonCode(reason: string): StrategyReasonCode {
  if (/Cooldown/.test(reason)) {
    return "COOLDOWN_ACTIVE";
  }
  if (/simultâneas|posiçõ/.test(reason)) {
    return "POSITION_ALREADY_OPEN";
  }
  return "RISK_BLOCKED";
}

/**
 * Traduz o motivo textual de validação de contrato em um código padronizado.
 */
function contractReasonCode(reason: string): StrategyReasonCode {
  if (/Stake/.test(reason)) {
    return "INVALID_STAKE";
  }
  if (/Duração indisponível|duração/.test(reason)) {
    return "INVALID_DURATION";
  }
  return "CONTRACT_UNAVAILABLE";
}

/** Converte duração + unidade em segundos (0 para ticks, que não são temporais). */
function durationInSeconds(duration: number, unit: string): number {
  switch (unit) {
    case "s":
      return duration;
    case "m":
      return duration * 60;
    case "h":
      return duration * 3600;
    case "d":
      return duration * 86400;
    default:
      return 0;
  }
}

function emptyStats(): StrategyRuntimeStats {
  return {
    trades: 0,
    wins: 0,
    losses: 0,
    pnl: 0,
    winRate: 0,
    consecutiveLosses: 0,
    maxConsecutiveLosses: 0,
    initialBalance: 0,
    currentBalance: 0,
    sessionPnL: 0,
  };
}

export class StrategyRuntime extends EventEmitter {
  private readonly api = new DerivApiClient();
  private readonly monitor = new TradeMonitor();
  /** Executor de operações — pode ser substituído em testes via setExecutorForTesting. */
  executor: TradeExecutor = new TradeExecutor();

  /** Permite injetar um executor mockado para testes. */
  setExecutorForTesting(executor: { execute: TradeExecutor["execute"] }): void {
    this.executor = executor as TradeExecutor;
  }

  private ws: WebSocketManager | null = null;
  private aggregator: CandleAggregator | null = null;
  private state: StrategyRuntimeState = "STOPPED";

  private balance: number | null = null;
  private currency: string | null = null;
  private openTrades: OpenStrategyTrade[] = [];
  private history: StrategyTradeRecord[] = [];
  private stats: StrategyRuntimeStats = emptyStats();

  private lastSignal: StrategySignal | null = null;
  private lastProposal: StrategyProposalRecord | null = null;
  private lastEntryTime: number | null = null;
  private tradeInFlight = false;
  private switching = false;
  private warmup = true;
  private lastEvent: string | null = null;
  private lastError: string | null = null;
  private decisionBlockReason: string | null = null;
  private reconnectTimer: NodeJS.Timeout | null = null;
  private settlementCheckTimer: NodeJS.Timeout | null = null;
  private tickHealthCheckTimer: NodeJS.Timeout | null = null;
  private candleHealthCheckTimer: NodeJS.Timeout | null = null;
  private stoppedByUser = false;
  /** IDs já liquidados (evita dupla contabilização de estatísticas). */
  private settledIds = new Set<string>();
  /** Rastreia tentativas de reconciliação por contract_id para evitar duplicatas e implementar backoff. */
  private reconciliationAttempts = new Map<string, { count: number; lastAttempt: number; nextRetryAt: number }>();
  /** Rastreia reservas de slots para compras em andamento (PENDING) */
  private pendingReservations = new Map<string, { contractId: string; reservedAt: number; stake: number; symbol: string }>();
  /** Timestamp do último tick recebido. */
  private lastTickAt: number | null = null;
  /** Timestamp do último candle fechado processado. */
  private lastCandleAt: number | null = null;
  /** Timestamp da última avaliação da estratégia. */
  private lastEvaluationAt: number | null = null;
  /** Estado da conexão WebSocket. */
  private connectionState: "CONNECTED" | "RECONNECTING" | "DISCONNECTED" | "ERROR" = "DISCONNECTED";

  constructor(
    private readonly manager: StrategyManager,
    private readonly store: StrategyStore,
  ) {
    super();
    this.monitor.onSettled((settled) => this.handleSettled(settled));
  }

  getState(): StrategyRuntimeState {
    return this.state;
  }

  getRiskConfig(): StrategyRiskConfig {
    return this.store.get().riskConfig;
  }

  private activeConfig() {
    const id = this.manager.getActiveId();
    if (!id) {
      return null;
    }
    return this.manager.getConfig(id);
  }

  async start(): Promise<{ ok: boolean; error?: string }> {
    if (this.state === "RUNNING") {
      return { ok: true };
    }
    const active = this.manager.getActiveId();
    if (!active) {
      return { ok: false, error: "Selecione uma estratégia antes de iniciar." };
    }
    const config = this.manager.getConfig(active);
    const instance = this.manager.getInstance(active);
    const validation = instance.validateConfig(config);
    if (!validation.ok) {
      return { ok: false, error: validation.errors.join(" ") };
    }

    this.stoppedByUser = false;
    this.stats = emptyStats();
    this.openTrades = [];
    this.history = [];
    this.settledIds = new Set<string>();
    this.lastEntryTime = null;
    this.tradeInFlight = false;
    this.switching = false;
    this.warmup = true;
    this.lastSignal = null;
    this.lastProposal = null;
    this.lastTickAt = null;
    this.lastCandleAt = null;
    this.lastEvaluationAt = null;
    this.connectionState = "DISCONNECTED";
    this.setState("RUNNING");
    this.setEvent("ESTRATÉGIA INICIADA (DEMO)");
    this.startSettlementChecks();
    this.startHealthChecks();
    try {
      await this.connectAndRun();
      return { ok: true };
    } catch (err) {
      this.lastError = err instanceof Error ? err.message : String(err);
      this.setEvent(
        err instanceof AuthExpiredError
          ? "CONEXÃO EXPIRADA — RECONECTE SUA CONTA DEMO"
          : "ERRO DA API",
      );
      this.setState("STOPPED");
      return { ok: false, error: this.lastError };
    }
  }

  pause(): void {
    if (this.state !== "RUNNING") {
      return;
    }
    this.setState("PAUSED");
    this.setEvent("ESTRATÉGIA PAUSADA");
  }

  resume(): void {
    if (this.state !== "PAUSED") {
      return;
    }
    this.setState("RUNNING");
    this.setEvent("ESTRATÉGIA RETOMADA");
  }

  async stop(): Promise<void> {
    this.stoppedByUser = true;
    if (this.reconnectTimer) {
      clearTimeout(this.reconnectTimer);
      this.reconnectTimer = null;
    }
    this.stopSettlementChecks();
    this.stopHealthChecks();
    this.setState("STOPPED");
    this.setEvent("ESTRATÉGIA PARADA");
    await this.ws?.close();
    this.ws = null;
    this.aggregator = null;
  }

  getSnapshot(): StrategyRuntimeSnapshot {
    const config = this.activeConfig();
    const duration = config?.duration ?? 0;
    const durationUnit = config?.durationUnit ?? "m";
    return {
      state: this.state,
      activeId: this.manager.getActiveId(),
      symbol: config?.symbol ?? "",
      granularity: config?.granularity ?? 0,
      contract: config
        ? `${CONTRACT_LABEL} — ${durationLabel(config.duration, config.durationUnit)}`
        : "",
      duration,
      durationUnit,
      durationLabel: config ? durationLabel(config.duration, config.durationUnit) : "",
      price: this.lastSignal?.price ?? null,
      lastSignal: this.lastSignal ? { ...this.lastSignal } : null,
      openTrades: this.openTrades.map((t) => ({ ...t })),
      exposurePct: this.currentExposurePct(),
      balance: this.balance,
      currency: this.currency,
      lastEvent: this.lastEvent,
      lastError: this.lastError,
      decisionBlockReason: this.decisionBlockReason,
      lastProposal: this.lastProposal ? { ...this.lastProposal } : null,
      stats: { ...this.stats },
      history: this.history.slice(-100),
      lastTickAt: this.lastTickAt,
      lastCandleAt: this.lastCandleAt,
      lastEvaluationAt: this.lastEvaluationAt,
      connectionState: this.connectionState,
    };
  }

  private setState(state: StrategyRuntimeState): void {
    this.state = state;
    this.emit("state", state);
  }

  private setEvent(event: string): void {
    this.lastEvent = event;
    this.emit("event", event);
  }

  /**
   * Calcula a exposição atual considerando posições OPEN e PENDING.
   * PENDING deve ser contado pois representa compras já enviadas à Deriv
   * que ainda não tiveram confirmação final de liquidação.
   */
  private currentExposurePct(): number {
    if (!this.balance || this.balance <= 0) {
      return 0;
    }
    // OPEN e PENDING contam para exposição - ambos representam capital comprometido
    const active = this.openTrades.filter((t) => t.status === "OPEN" || t.status === "PENDING");
    const totalStake = active.reduce(
      (a, t) => a + (t.buyPrice ?? t.stake),
      0,
    );
    return (totalStake / this.balance) * 100;
  }

  /**
   * Conta posições ativas (OPEN + PENDING) para limites de risco.
   * PENDING deve ser contado pois representa compras já enviadas à Deriv
   * que ainda não tiveram confirmação final de liquidação.
   */
  private activePositionCount(): number {
    return this.openTrades.filter((t) => t.status === "OPEN" || t.status === "PENDING").length;
  }

  /**
   * Reserva atômica de slot para uma nova operação.
   * Retorna true se a reserva foi bem-sucedida, false se exceder limites.
   */
  private reserveSlot(contractId: string, stake: number, symbol: string): boolean {
    if (!this.balance || this.balance <= 0) {
      return false;
    }
    
    const activeCount = this.activePositionCount();
    const risk = this.getRiskConfig();
    
    // Verifica limite de posições simultâneas
    if (this.activePositionCount() >= risk.maxOpenTrades) {
      return false;
    }
    
    // Verifica exposição total
    const activeStake = this.openTrades
      .filter((t) => t.status === "OPEN" || t.status === "PENDING")
      .reduce((a, t) => a + (t.buyPrice ?? t.stake), 0);
    
    const newExposurePct = ((activeStake + stake) / this.balance!) * 100;
    if (newExposurePct >= this.getRiskConfig().maxExposurePct) {
      return false;
    }
    
    // Reserva o slot
    this.pendingReservations.set(contractId, {
      contractId: contractId,
      reservedAt: Date.now(),
      stake: stake,
      symbol: symbol,
    });
    
    return true;
  }

  /**
   * Libera uma reserva (sucesso ou falha na compra).
   */
  private releaseReservation(contractId: string): void {
    this.pendingReservations.delete(contractId);
  }

  private async connectAndRun(): Promise<void> {
    const config = this.activeConfig();
    if (!config) {
      throw new Error("Nenhuma estratégia ativa.");
    }
    const url = await this.api.getDemoWebSocketUrl();
    const ws = new WebSocketManager();
    this.ws = ws;

    ws.onMessage((msg) => this.handleMessage(msg));
    ws.onClose(() => this.handleDisconnect());

    await ws.connect(url);
    this.connectionState = "CONNECTED";
    this.setEvent("WEBSOCKET CONECTADO");
    await this.loadMarket(config.symbol, config.granularity);
    this.restorePendingTrades();
    await this.resubscribePending(ws);

    const balanceMsg = await ws.request({ balance: 1 });
    const b = balanceMsg.balance as { balance: number; currency: string } | undefined;
    if (b) {
      this.updateBalance(b.balance, b.currency);
    }
  }

  /**
   * Re-assina contratos pendentes persistidos (após reinício) para que a
   * liquidação seja recebida e reconciliada.
   * TODOS os símbolos são re-assinados para garantir reconciliação completa.
   */
  private async resubscribePending(ws: WebSocketManager): Promise<void> {
    for (const pending of tradeHistoryStore.listPending()) {
      try {
        await ws.request({
          proposal_open_contract: 1,
          contract_id: contractIdParam(pending.id),
          subscribe: 1,
        });
        logger.info("Re-assinando contrato pendente", { contractId: pending.id, symbol: pending.symbol });
      } catch (err) {
        logger.warn("Falha ao re-assinar contrato pendente", {
          contractId: pending.id,
          message: err instanceof Error ? err.message : String(err),
        });
      }
    }
  }

  /**
   * Restaura TODOS os contratos PENDING persistidos (de sessões/reinícios anteriores)
   * para a memória, de modo que:
   * - o painel mostre a posição em andamento;
   * - o gerenciamento de risco conte a exposição/bloqueio corretamente;
   * - novas compras sejam bloqueadas enquanto o estado for desconhecido.
   *
   * TODOS os símbolos são restaurados para garantir reconciliação completa.
   * O estado de reconciliação é rastreado separadamente.
   */
  private restorePendingTrades(): void {
    const pending = tradeHistoryStore.listPending();
    for (const p of pending) {
      if (this.openTrades.some((t) => t.contractId === p.id)) {
        continue;
      }
      const strategyId = (STRATEGY_IDS as string[]).includes(p.strategy)
        ? (p.strategy as StrategyId)
        : (this.manager.getActiveId() ?? "CONFLUENCIA");
      this.openTrades.push({
        contractId: p.id,
        proposalId: "",
        symbol: p.symbol,
        strategyId,
        direction: p.direction,
        stake: p.stake,
        entryTime: p.timestamp,
        duration: p.duration,
        durationSeconds: durationInSeconds(p.duration, p.durationUnit),
        durationUnit: p.durationUnit,
        granularity: p.granularity ?? 0,
        askPrice: p.entryPrice,
        buyPrice: p.buyPrice,
        payout: p.payout,
        status: "PENDING", // Estado PENDING até reconciliação
        profit: null,
        reconciliationState: "PENDING_RECONCILIATION",
        lastReconciliationAt: null,
        lastTickAt: null,
      });
    }
    if (pending.length > 0) {
      logger.info("Contratos pendentes restaurados para reconciliação", {
        count: pending.length,
      });
    }
  }

  /** Inicia a verificação periódica de liquidação de contratos abertos. */
  private startSettlementChecks(): void {
    this.stopSettlementChecks();
    this.settlementCheckTimer = setInterval(() => {
      void this.checkExpiredContracts();
    }, 15000);
  }

  private stopSettlementChecks(): void {
    if (this.settlementCheckTimer) {
      clearInterval(this.settlementCheckTimer);
      this.settlementCheckTimer = null;
    }
  }

  private startHealthChecks(): void {
    this.stopHealthChecks();
    // Verificação de saúde do tick a cada 30 segundos
    this.tickHealthCheckTimer = setInterval(() => {
      void this.checkTickHealth();
    }, 30000);
    // Verificação de saúde do candle a cada 60 segundos
    this.candleHealthCheckTimer = setInterval(() => {
      void this.checkCandleHealth();
    }, 60000);
  }

  private stopHealthChecks(): void {
    if (this.tickHealthCheckTimer) {
      clearInterval(this.tickHealthCheckTimer);
      this.tickHealthCheckTimer = null;
    }
    if (this.candleHealthCheckTimer) {
      clearInterval(this.candleHealthCheckTimer);
      this.candleHealthCheckTimer = null;
    }
  }

  /**
   * Verifica se os ticks estão chegando normalmente.
   * Se não houver ticks por mais de 60 segundos, tenta re-assinar.
   */
  private async checkTickHealth(): Promise<void> {
    if (this.state !== "RUNNING" || !this.ws || !this.ws.isConnected) {
      return;
    }
    const now = Date.now();
    if (this.lastTickAt && now - this.lastTickAt > 60000) {
      this.lastError = `Sem ticks por ${Math.round((now - this.lastTickAt) / 1000)}s — tentando re-assinar`;
      this.setEvent("TICKS AUSENTES — REASSINANDO");
      logger.warn(this.lastError);
      try {
        const config = this.activeConfig();
        if (config) {
          await this.ws.request({ forget_all: "ticks" });
          await this.ws.request({ ticks: config.symbol, subscribe: 1 });
          this.setEvent("TICKS REASSINADOS");
        }
      } catch (err) {
        logger.error("Falha ao re-assinar ticks", { message: err instanceof Error ? err.message : String(err) });
      }
    }
  }

  /**
   * Verifica se os candles estão fechando normalmente.
   * Se não houver candle fechado por mais de 2x granularity, alerta.
   */
  private async checkCandleHealth(): Promise<void> {
    if (this.state !== "RUNNING") {
      return;
    }
    const config = this.activeConfig();
    if (!config || !config.granularity) {
      return;
    }
    const now = Date.now();
    const expectedInterval = config.granularity * 1000 * 2; // 2x o intervalo esperado
    if (this.lastCandleAt && now - this.lastCandleAt > expectedInterval) {
      const msg = `Candle não fecha há ${Math.round((now - this.lastCandleAt) / 1000)}s (esperado ~${config.granularity}s)`;
      this.lastError = msg;
      this.setEvent("CANDLE TRAVADO — VERIFICAR CONEXÃO");
      logger.warn(msg);
    }
  }

  /**
   * Re-consulta o estado de contratos abertos cuja duração já expirou. O
   * contador local NÃO é confirmação de liquidação — a API é a fonte da
   * verdade. Se a mensagem de liquidação (streaming) for perdida, esta
   * re-consulta garante a reconciliação.
   *
   * Implementa retry com backoff exponencial e evita consultas duplicadas
   * simultâneas para o mesmo contract_id.
   *
   * Para contratos de curta duração (< 5 min), verifica mais agressivamente.
   */
  private async checkExpiredContracts(): Promise<void> {
    const ws = this.ws;
    if (!ws || !ws.isConnected) {
      return;
    }
    const now = Date.now();
    const expired = this.openTrades.filter(
      (t) =>
        (t.status === "OPEN" || t.status === "PENDING") &&
        t.durationSeconds > 0 &&
        now - t.entryTime >= (t.durationSeconds + 5) * 1000,
    );
    for (const t of expired) {
      // Verifica se já tentou recentemente e deve aguardar (backoff exponencial)
      const attemptInfo = this.reconciliationAttempts.get(t.contractId);
      if (attemptInfo && now < attemptInfo.nextRetryAt) {
        continue; // Ainda não é hora de tentar novamente
      }

      try {
        const msg = await ws.request({
          proposal_open_contract: 1,
          contract_id: contractIdParam(t.contractId),
        });
        // Re-encaminha a resposta ao monitor, que centraliza a determinação
        // do resultado e a extração de profit/sell_price/buy_price.
        this.monitor.handleMessage(msg as WsMessage);
        // Sucesso: limpa o registro de tentativas
        this.reconciliationAttempts.delete(t.contractId);
      } catch (err) {
        // Registra a tentativa falhada com backoff exponencial
        const attemptCount = (attemptInfo?.count ?? 0) + 1;
        const baseDelayMs = 5000; // 5 segundos base
        const maxDelayMs = 300000; // 5 minutos máximo
        const delayMs = Math.min(baseDelayMs * Math.pow(2, attemptCount - 1), maxDelayMs);
        const nextRetryAt = Date.now() + delayMs;

        this.reconciliationAttempts.set(t.contractId, {
          count: attemptCount,
          lastAttempt: Date.now(),
          nextRetryAt,
        });

        // Extrai detalhes do erro da API (código, mensagem)
        const message = err instanceof Error ? err.message : String(err);
        const errorDetail = err && typeof err === "object" && "response" in err
          ? (err as any).response?.data ?? message
          : message;

        logger.warn("Falha ao re-consultar contrato expirado (tentativa será refeita)", {
          contractId: t.contractId,
          attempt: attemptCount,
          nextRetryInMs: delayMs,
          error: errorDetail,
        });

        this.lastError = `Erro de sincronização (tentativa ${attemptCount}) — não foi possível consultar a liquidação do contrato ${t.contractId}: ${errorDetail}`;
        this.setEvent(`ERRO DE SINCRONIZAÇÃO (tentativa ${attemptCount}) — REASSINANDO...`);
      }
    }

    // Verificação adicional: contratos PENDING que ainda não expiraram mas estão há mais de 30s sem atualização
    // (possível perda de mensagem de streaming)
    const stalePending = this.openTrades.filter(
      (t) =>
        t.status === "PENDING" &&
        now - t.entryTime >= 30000, // 30 segundos sem atualização
    );
    for (const t of stalePending) {
      try {
        const msg = await ws.request({
          proposal_open_contract: 1,
          contract_id: contractIdParam(t.contractId),
        });
        this.monitor.handleMessage(msg as WsMessage);
      } catch (err) {
        logger.debug("Falha ao verificar contrato PENDING antigo", {
          contractId: t.contractId,
          error: err instanceof Error ? err.message : String(err),
        });
      }
    }
  }

  private async loadMarket(symbol: string, granularity: number): Promise<void> {
    const ws = this.ws;
    if (!ws) {
      throw new Error("WebSocket indisponível.");
    }
    const candles = await fetchCandles(ws, symbol, granularity, 500);
    this.manager.resetBuffers();
    for (const c of candles) {
      this.manager.onCandle(c);
    }
    this.aggregator = new CandleAggregator(granularity, candles.at(-1));
    this.aggregator.onCandleClose((candle) => this.onCandleClose(candle));

    try {
      await ws.request({ forget_all: "ticks" });
    } catch {
      /* ignore */
    }
    await ws.request({ ticks: symbol, subscribe: 1 });
    this.warmup = false;
    this.setEvent("DADOS DE MERCADO CARREGADOS");
    logger.info("Mercado carregado", { symbol, granularity, candles: candles.length });
  }

  private handleMessage(msg: Record<string, any>): void {
    this.monitor.handleMessage(msg);
    const config = this.activeConfig();
    if (msg.msg_type === "tick" && msg.tick?.symbol === config?.symbol) {
      const tick = msg.tick as { quote: number; epoch: number };
      const now = Date.now();
      this.lastTickAt = now;
      // Atualiza lastTickAt dos trades abertos deste símbolo
      if (config) {
        for (const t of this.openTrades) {
          if (t.status === "OPEN" || t.status === "PENDING" && t.symbol === config.symbol) {
            t.lastTickAt = now;
          }
        }
      }
      this.aggregator?.onTick(tick.epoch, tick.quote);
    } else if (msg.msg_type === "balance" && msg.balance) {
      const b = msg.balance as { balance: number; currency: string };
      this.updateBalance(b.balance, b.currency);
    }
  }

  private onCandleClose(candle: Candle): void {
    const signal = this.manager.onCandle(candle);
    if (signal) {
      this.lastSignal = signal;
    }
    this.lastCandleAt = Date.now();
    if (this.warmup || this.state !== "RUNNING" || this.switching) {
      return;
    }
    if (signal && signal.direction !== "WAIT") {
      void this.evaluateAndMaybeTrade(signal);
    }
  }

  private updateBalance(balance: number, currency: string): void {
    this.balance = balance;
    this.currency = currency;
    this.stats.currentBalance = balance;
    if (this.stats.initialBalance === 0) {
      this.stats.initialBalance = balance;
    }
    this.stats.sessionPnL = balance - this.stats.initialBalance;
    this.emit("balance", { balance, currency });
  }

  private async evaluateAndMaybeTrade(signal: StrategySignal): Promise<void> {
    this.lastEvaluationAt = Date.now();
    const config = this.activeConfig();
    if (!config || !this.ws || this.balance === null || this.currency === null) {
      return;
    }
    if (signal.direction === "WAIT") {
      return;
    }

    // Evita condição de corrida: uma única operação em andamento por vez.
    if (this.tradeInFlight) {
      this.decisionBlockReason = "Operação anterior ainda em execução.";
      return;
    }

    const activeId = this.manager.getActiveId();
    if (!activeId) {
      return;
    }

    // Limite de operações por ativação (config individual; 0 = ilimitado).
    const maxTrades = config.maxTrades;
    if (maxTrades > 0 && this.stats.trades >= maxTrades) {
      this.decisionBlockReason = `Limite de ${maxTrades} operações atingido para esta estratégia.`;
      this.manager.recordRejected({
        timestamp: Date.now(),
        strategyId: activeId,
        direction: signal.direction,
        reason: this.decisionBlockReason,
        reasonCode: "RISK_BLOCKED",
      });
      return;
    }

    // Config global com o cooldown mais restritivo (global vs individual).
    const globalRisk = this.getRiskConfig();
    const effectiveRisk: StrategyRiskConfig = {
      ...globalRisk,
      cooldownSeconds: effectiveCooldownSeconds(globalRisk, config.cooldownSeconds),
    };

    const risk = evaluateStrategyRisk(
      {
        // OPEN e PENDING contam para limite de posições - ambos representam capital comprometido
        openCount: this.activePositionCount(),
        exposurePct: this.currentExposurePct(),
        consecutiveLosses: this.stats.consecutiveLosses,
        pnlPct:
          this.stats.initialBalance > 0
            ? (this.stats.sessionPnL / this.stats.initialBalance) * 100
            : 0,
        lastEntryAt: this.lastEntryTime,
        now: Date.now(),
      },
      effectiveRisk,
    );

    if (!risk.ok) {
      this.decisionBlockReason = risk.reason;
      this.manager.recordRejected({
        timestamp: Date.now(),
        strategyId: activeId,
        direction: signal.direction,
        reason: risk.reason,
        reasonCode: riskReasonCode(risk.reason),
      });
      if (/perdas consecutivas|Stop diário/.test(risk.reason)) {
        this.setEvent(`ESTRATÉGIA PARADA — ${risk.reason.toUpperCase()}`);
        await this.stop();
        return;
      }
      return;
    }

    // Stake efetiva: individual, mas nunca acima do teto global.
    const stake = computeEffectiveStrategyStake(
      this.balance,
      config,
      globalRisk,
      this.currency,
    );
    if (stake <= 0) {
      this.decisionBlockReason = "Stake inválida após normalização.";
      return;
    }

    const validation = await validateStrategyContract(
      this.ws,
      config.symbol,
      config.contractType,
      config.duration,
      config.durationUnit,
      stake,
    );
    if (!validation.ok) {
      this.decisionBlockReason = validation.reason;
      this.manager.recordRejected({
        timestamp: Date.now(),
        strategyId: activeId,
        direction: signal.direction,
        reason: validation.reason,
        reasonCode: contractReasonCode(validation.reason),
      });
      this.setEvent(`OPERAÇÃO BLOQUEADA — ${validation.reason}`);
      return;
    }

    const direction: Direction = signal.direction === "BUY" ? "CALL" : "PUT";
    // Reserva slot antes de enviar a compra
    const tempContractId = `temp_${Date.now()}_${Math.random().toString(36).slice(2, 9)}`;
    if (!this.reserveSlot(tempContractId, stake, config.symbol)) {
      this.decisionBlockReason = "Limite de risco atingido (posições simultâneas ou exposição).";
      this.setEvent("OPERAÇÃO BLOQUEADA — LIMITE DE RISCO");
      return;
    }
    await this.placeTrade(activeId, signal, direction, stake);
  }

  private async placeTrade(
    strategyId: StrategyId,
    signal: StrategySignal,
    direction: Direction,
    stake: number,
  ): Promise<void> {
    const config = this.activeConfig();
    if (!config || !this.ws || this.currency === null) {
      return;
    }
    this.tradeInFlight = true;
    
    // Reserva slot ANTES de enviar a compra (com ID temporário)
    const tempContractId = `temp_${Date.now()}_${Math.random().toString(36).slice(2, 9)}`;
    if (!this.reserveSlot("temp_" + Date.now(), stake, this.activeConfig()?.symbol || "")) {
      this.decisionBlockReason = "Limite de risco atingido (posições simultâneas ou exposição).";
      this.setEvent("OPERAÇÃO BLOQUEADA — LIMITE DE RISCO");
      this.tradeInFlight = false;
      return;
    }
    
    try {
      const trade = await this.executor.execute(
        this.ws,
        config.symbol,
        direction,
        stake,
        config.duration,
        config.durationUnit,
        this.currency,
        { skipAvailabilityCheck: true },
      );
      
      // Atualiza reserva com o contractId real
      this.releaseReservation("temp_" + Date.now()); // Remove reserva temporária
      this.reserveSlot(trade.contractId, stake, config.symbol); // Reserva com ID real
      
      const entryTime = Date.now();
      const open: OpenStrategyTrade = {
        contractId: trade.contractId,
        proposalId: trade.proposalId,
        symbol: config.symbol,
        strategyId,
        direction,
        stake,
        entryTime,
        duration: config.duration,
        durationSeconds: durationInSeconds(config.duration, config.durationUnit),
        durationUnit: config.durationUnit,
        granularity: config.granularity,
        askPrice: trade.askPrice,
        buyPrice: trade.buyPrice,
        payout: trade.payout,
        status: "PENDING",
        profit: null,
        reconciliationState: "NONE",
        lastReconciliationAt: null,
        lastTickAt: null,
      };
      
      // Adiciona à lista de operações abertas
      this.openTrades.push(open);
      
      // Saldo confirmado pela Deriv após a compra (balance_after). Sincroniza
      // o painel com o valor efetivo, independente de atualizações de stream.
      if (trade.balanceAfter !== null && trade.balanceAfter !== undefined) {
        this.balance = trade.balanceAfter;
        this.stats.currentBalance = trade.balanceAfter;
        this.stats.sessionPnL = trade.balanceAfter - this.stats.initialBalance;
        this.emit("balance", { balance: trade.balanceAfter, currency: this.currency });
      }

      // Divergência entre stake configurada e buy_price confirmado: registra
      // e exibe, sem inventar valores. A exposição passa a usar o buy_price.
      const buyPrice = trade.buyPrice ?? stake;
      const diverged =
        trade.buyPrice !== null && Math.abs(trade.buyPrice - stake) > 0.005;

      // Persiste o contrato em aberto (PENDING) para reconciliação futura.
      // upsert evita duplicação caso o mesmo contrato seja reprocessado.
      tradeHistoryStore.upsert({
        id: open.contractId,
        timestamp: open.entryTime,
        settlementTime: null,
        symbol: open.symbol,
        direction: open.direction,
        strategy: open.strategyId,
        contractType: "callput",
        duration: open.duration,
        durationUnit: open.durationUnit,
        granularity: open.granularity,
        stake: open.stake,
        buyPrice: open.buyPrice,
        entryPrice: open.askPrice,
        payout: open.payout,
        result: "PENDING",
        profitLoss: null,
        balanceAfter: trade.balanceAfter,
        entryType: null,
        reason: null,
      });

      this.lastProposal = {
        timestamp: entryTime,
        direction,
        stake: buyPrice,
        accepted: true,
        detail: `Compra confirmada — contrato ${trade.contractId} (cobrado ${buyPrice.toFixed(2)}).`,
      };
      this.setEvent(
        `OPERAÇÃO ABERTA — ${strategyId} ${direction} ${buyPrice.toFixed(2)} (${config.duration}${config.durationUnit})`,
      );
      if (diverged) {
        logger.warn("Divergência entre stake configurada e buy_price confirmado", {
          contractId: trade.contractId,
          stakeConfigurada: stake,
          buyPrice: trade.buyPrice,
        });
        this.setEvent(
          `AVISO — STAKE CONFIRMADA ${buyPrice.toFixed(2)} ≠ CONFIGURADA ${stake.toFixed(2)}`,
        );
      }
      logger.info("Operação de estratégia aberta", {
        strategyId,
        symbol: config.symbol,
        direction,
        // Stake: configurada, enviada à API e efetivamente cobrada.
        stakeMode: config.stakeMode,
        stakeConfigurada: config.stakeMode === "FIXED" ? config.fixedStake : config.stakePercent,
        stakeEnviada: stake,
        stakeCobrada: trade.buyPrice,
        proposalId: trade.proposalId,
        contractId: trade.contractId,
        sinalAt: signal.timestamp,
        compraAt: entryTime,
        latenciaMs: entryTime - signal.timestamp,
        precoEntrada: trade.askPrice,
        duracao: config.duration,
        duracaoUnit: config.durationUnit,
        payout: trade.payout,
        signal: signal.reason,
      });
      await this.ws.request({
        proposal_open_contract: 1,
        contract_id: contractIdParam(trade.contractId),
        subscribe: 1,
      });

      // Reconciliação imediata: consulta o estado do contrato logo após a assinatura
      // para detectar imediatamente se já foi liquidado (caso de duração muito curta).
      try {
        const immediateMsg = await this.ws.request({
          proposal_open_contract: 1,
          contract_id: contractIdParam(trade.contractId),
        });
        this.monitor.handleMessage(immediateMsg as WsMessage);
      } catch (err) {
        logger.debug("Falha na reconciliação imediata pós-compra", {
          contractId: trade.contractId,
          error: err instanceof Error ? err.message : String(err),
        });
      }
    } catch (err) {
      this.lastError = err instanceof Error ? err.message : String(err);
      // Libera a reserva em caso de erro
      this.releaseReservation("temp_" + Date.now()); // Tenta liberar reserva temporária
      
      if (
        err instanceof ContractUnavailableError ||
        err instanceof ProposalValidationError
      ) {
        this.decisionBlockReason = this.lastError;
        this.lastProposal = {
          timestamp: Date.now(),
          direction,
          stake,
          accepted: false,
          detail: this.lastError,
        };
        this.manager.recordRejected({
          timestamp: Date.now(),
          strategyId,
          direction: signal.direction,
          reason: this.lastError,
          reasonCode:
            err instanceof ContractUnavailableError
              ? "CONTRACT_UNAVAILABLE"
              : "PROPOSAL_REJECTED",
        });
        this.setEvent(`OPERAÇÃO BLOQUEADA — ${this.lastError}`);
      } else {
        this.lastProposal = {
          timestamp: Date.now(),
          direction,
          stake,
          accepted: false,
          detail: this.lastError,
        };
        this.manager.recordRejected({
          timestamp: Date.now(),
          strategyId,
          direction: signal.direction,
          reason: this.lastError,
          reasonCode: "DERIV_API_ERROR",
        });
        this.setEvent("ERRO AO OPERAR");
      }
    } finally {
      this.tradeInFlight = false;
    }
  }

  private handleSettled(settled: SettledTrade): void {
    // Evita dupla contabilização: streaming + re-consulta podem entregar o
    // mesmo contrato mais de uma vez.
    if (this.settledIds.has(settled.contractId)) {
      return;
    }
    this.settledIds.add(settled.contractId);

    const open = this.openTrades.find(
      (t) => t.status === "OPEN" || t.status === "PENDING" && t.contractId === settled.contractId,
    );
    if (!open) {
      // Reconciliação pós-reinício: contrato pendente persistido, mas não em
      // memória. Atualiza o registro persistido com o resultado.
      this.reconcileSettled(settled);
      return;
    }
    open.status = "SETTLED";
    open.profit = settled.profitLoss;
    open.reconciliationState = "RECONCILED";
    open.lastReconciliationAt = Date.now();
    if (settled.buyPrice !== null) {
      open.buyPrice = settled.buyPrice;
    }

    // Resultado desconhecido NÃO é contabilizado como vitória nem como perda:
    // registramos no histórico, mas não inventamos resultado.
    const isWin = settled.result === "WIN";
    const isLoss = settled.result === "LOSS";
    if (isWin || isLoss) {
      this.stats.trades += 1;
      if (isWin) {
        this.stats.wins += 1;
        this.stats.consecutiveLosses = 0;
      } else {
        this.stats.losses += 1;
        this.stats.consecutiveLosses += 1;
        if (this.stats.consecutiveLosses > this.stats.maxConsecutiveLosses) {
          this.stats.maxConsecutiveLosses = this.stats.consecutiveLosses;
        }
      }
      this.stats.pnl += settled.profitLoss;
      this.stats.winRate =
        this.stats.trades > 0 ? (this.stats.wins / this.stats.trades) * 100 : 0;
    }

    const result = isWin ? "WIN" : isLoss ? "LOSS" : "UNKNOWN";

    this.history.push({
      id: open.contractId,
      timestamp: open.entryTime,
      symbol: open.symbol,
      direction: open.direction,
      strategyId: open.strategyId,
      stake: open.stake,
      entryPrice: open.askPrice,
      result,
      profitLoss: settled.profitLoss,
    });

    // Atualiza o registro persistido (PENDING → WIN/LOSS/UNKNOWN) sem duplicar.
    tradeHistoryStore.upsert({
      id: open.contractId,
      timestamp: open.entryTime,
      settlementTime: Date.now(),
      symbol: open.symbol,
      direction: open.direction,
      strategy: open.strategyId,
      contractType: "callput",
      duration: open.duration,
      durationUnit: open.durationUnit,
      granularity: open.granularity,
      stake: open.stake,
      buyPrice: open.buyPrice,
      entryPrice: open.askPrice,
      payout: open.payout,
      result,
      profitLoss: settled.profitLoss,
      balanceAfter: this.balance,
      entryType: null,
      reason: null,
    });

    const sign = settled.profitLoss >= 0 ? "+" : "";
    this.setEvent(
      `RESULTADO ${open.strategyId} — ${settled.result} (${sign}${settled.profitLoss.toFixed(2)})`,
    );
    logger.info("Resultado da operação", {
      strategyId: open.strategyId,
      symbol: open.symbol,
      direction: open.direction,
      stake: open.stake,
      buyPrice: open.buyPrice,
      contractId: open.contractId,
      proposalId: open.proposalId,
      entradaAt: open.entryTime,
      liquidacaoAt: Date.now(),
      precoEntrada: open.askPrice,
      payout: open.payout,
      resultado: settled.result,
      profitLoss: settled.profitLoss,
      sellPrice: settled.sellPrice,
      status: settled.status,
    });

    const risk = this.getRiskConfig();
    if (
      isLoss &&
      risk.maxConsecutiveLosses !== null &&
      this.stats.consecutiveLosses >= risk.maxConsecutiveLosses
    ) {
      this.setEvent("ESTRATÉGIA PARADA — LIMITE DE PERDAS ATINGIDO");
      void this.stop();
    }
  }

  /** Reconcilia um contrato pendente cuja liquidação chegou após reinício. */
  private reconcileSettled(settled: SettledTrade): void {
    const result =
      settled.result === "WIN"
        ? "WIN"
        : settled.result === "LOSS"
          ? "LOSS"
          : "UNKNOWN";
    const existing = tradeHistoryStore.get(settled.contractId);
    if (!existing) {
      logger.warn("Contrato liquidado não encontrado no histórico", {
        contractId: settled.contractId,
      });
      return;
    }
    tradeHistoryStore.update(settled.contractId, {
      settlementTime: Date.now(),
      result,
      profitLoss: settled.profitLoss,
      buyPrice: settled.buyPrice ?? existing.buyPrice,
    });
    logger.info("Contrato pendente reconciliado", {
      contractId: settled.contractId,
      result,
      profitLoss: settled.profitLoss,
    });
  }

  private handleDisconnect(): void {
    if (this.stoppedByUser || this.state === "STOPPED") {
      return;
    }
    this.connectionState = "RECONNECTING";
    this.setEvent("WEBSOCKET DESCONECTADO — RECONECTANDO...");
    if (this.reconnectTimer) {
      clearTimeout(this.reconnectTimer);
    }
    this.reconnectTimer = setTimeout(() => {
      this.reconnectTimer = null;
      if (this.state !== "STOPPED" && !this.stoppedByUser) {
        this.setEvent("TENTANDO RECONEXÃO...");
        this.connectAndRun().catch((err) => {
          this.lastError = err instanceof Error ? err.message : String(err);
          this.connectionState = "ERROR";
          logger.error("Falha na reconexão", { message: this.lastError });
        });
      }
    }, RECONNECT_DELAY_MS);
  }
}


