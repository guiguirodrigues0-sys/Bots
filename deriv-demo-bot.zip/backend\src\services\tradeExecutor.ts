import type { Direction } from "../types.js";
import type { WebSocketManager, WsMessage } from "../deriv/wsManager.js";
import {
  checkContractAvailability,
  type DurationUnit,
} from "../deriv/symbols.js";
import { logger } from "../logger/index.js";

export interface ExecutedTrade {
  contractId: string;
  proposalId: string;
  direction: Direction;
  stake: number;
  buyPrice: number;
  askPrice: number;
  payout: number | null;
  balanceAfter: number | null;
  longcode?: string;
}

export class ContractUnavailableError extends Error {
  constructor(message: string) {
    super(message);
    this.name = "ContractUnavailableError";
  }
}

export class ProposalValidationError extends Error {
  constructor(message: string) {
    super(message);
    this.name = "ProposalValidationError";
  }
}

const CONTRACT_CATEGORY = "callput";
const MAX_PROPOSAL_ATTEMPTS = 4;
const RETRY_DELAY_MS = 200;

/**
 * Converte um `contract_id` (armazenado como string para nunca perder
 * precisão) no formato correto para envio à API Deriv.
 *
 * O `proposal_open_contract` espera `contract_id` como inteiro. IDs de
 * contrato da Deriv cabem no intervalo seguro de inteiros do JavaScript
 * (2^53), mas por segurança preservamos a representação original caso o
 * valor não seja representável com precisão — evitando arredondar um ID e
 * consultar/assinar o contrato ERRADO.
 */
export function contractIdParam(id: string): number | string {
  const n = Number(id);
  if (Number.isSafeInteger(n)) {
    return n;
  }
  return id;
}

/**
 * Erros transitórios na compra: a Deriv pode rejeitar a compra se o preço
 * mudou entre o sinal e o envio. Nesses casos refazemos a compra.
 */
function isTransientBuyError(err: unknown): boolean {
  const msg = err instanceof Error ? err.message : String(err);
  return /PriceMoved|price.*changed|InternalServerError|AuthorizationRequired|InvalidContractProposal|Unknown contract proposal/i.test(
    msg,
  );
}

export class TradeExecutor {
  async execute(
    ws: WebSocketManager,
    symbol: string,
    direction: Direction,
    stake: number,
    duration: number,
    durationUnit: DurationUnit,
    currency: string,
    opts?: { skipAvailabilityCheck?: boolean },
  ): Promise<ExecutedTrade> {
    // Segurança DEMO: este executor só opera sobre o WebSocket obtido por
    // getDemoWebSocketUrl(), que valida o ambiente (/ws/demo) e bloqueia
    // /ws/real (assertDemoUrl). A moeda vem do saldo da conta demo já
    // confirmada na conexão — não há nova chamada REST por operação.

    if (!opts?.skipAvailabilityCheck) {
      const availability = await checkContractAvailability(
        ws,
        symbol,
        CONTRACT_CATEGORY,
        duration,
        durationUnit,
      );
      if (!availability.ok) {
        throw new ContractUnavailableError(availability.reason);
      }
    }

    let lastError: unknown = null;
    for (let attempt = 1; attempt <= MAX_PROPOSAL_ATTEMPTS; attempt++) {
      try {
        return await this.buyContract(
          ws,
          symbol,
          direction,
          stake,
          duration,
          durationUnit,
          currency,
        );
      } catch (err) {
        lastError = err;
        const transient = isTransientBuyError(err);
        if (!transient || attempt === MAX_PROPOSAL_ATTEMPTS) {
          throw err;
        }
        logger.warn("Compra rejeitada (transitório); refazendo", {
          attempt,
          symbol,
          direction,
          message: err instanceof Error ? err.message : String(err),
        });
        await new Promise((r) => setTimeout(r, RETRY_DELAY_MS * attempt));
      }
    }
    throw lastError instanceof Error
      ? lastError
      : new Error(String(lastError));
  }

  /**
   * Compra um contrato passando os parâmetros diretamente.
   *
   * IMPORTANTE (nova API api.derivws.com): o `id` retornado pelo endpoint
   * `proposal` é um identificador por conexão usado pelo `forget` — NÃO é o
   * identificador de compra. A compra correta usa `buy: "1"` com os parâmetros
   * do contrato em `parameters`.
   */
  private async buyContract(
    ws: WebSocketManager,
    symbol: string,
    direction: Direction,
    stake: number,
    duration: number,
    durationUnit: DurationUnit,
    currency: string,
  ): Promise<ExecutedTrade> {
    const buyMsg = await ws.request({
      buy: "1",
      price: stake,
      parameters: {
        contract_type: direction,
        currency,
        underlying_symbol: symbol,
        amount: stake,
        basis: "stake",
        duration,
        duration_unit: durationUnit,
      },
    });

    const buy = buyMsg.buy as
      | {
          contract_id?: string | number;
          buy_price?: number | string;
          payout?: number | string;
          balance_after?: number | string;
          longcode?: string;
          transaction_id?: string | number;
        }
      | undefined;

    if (buy?.contract_id === undefined || buy?.contract_id === null) {
      throw new Error(`Operação recusada pela Deriv: ${JSON.stringify(buyMsg)}`);
    }

    return {
      contractId: String(buy.contract_id),
      proposalId: buy.transaction_id != null ? String(buy.transaction_id) : "",
      direction,
      stake,
      buyPrice: Number(buy.buy_price ?? stake),
      askPrice: stake,
      payout: buy.payout != null ? Number(buy.payout) : null,
      balanceAfter:
        buy.balance_after != null ? Number(buy.balance_after) : null,
      longcode: buy.longcode,
    };
  }
}
