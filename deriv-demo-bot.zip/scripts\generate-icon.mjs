import { deflateSync } from "node:zlib";
import { writeFileSync, mkdirSync } from "node:fs";

const BG = [11, 14, 19, 255]; // #0b0e13
const ACCENT = [43, 189, 130, 255]; // #2bbd82

function crc32(buf) {
  const table = (() => {
    const t = new Uint32Array(256);
    for (let i = 0; i < 256; i++) {
      let c = i;
      for (let k = 0; k < 8; k++) {
        c = c & 1 ? 0xedb88320 ^ (c >>> 1) : c >>> 1;
      }
      t[i] = c >>> 0;
    }
    return t;
  })();
  let crc = 0xffffffff;
  for (let i = 0; i < buf.length; i++) {
    crc = table[(crc ^ buf[i]) & 0xff] ^ (crc >>> 8);
  }
  return (crc ^ 0xffffffff) >>> 0;
}

function chunk(type, data) {
  const len = Buffer.alloc(4);
  len.writeUInt32BE(data.length, 0);
  const typeBuf = Buffer.from(type, "ascii");
  const crc = Buffer.alloc(4);
  crc.writeUInt32BE(crc32(Buffer.concat([typeBuf, data])), 0);
  return Buffer.concat([len, typeBuf, data, crc]);
}

function renderPixels(size) {
  const pixels = new Array(size * size).fill(BG);
  const apexY = size * 0.26;
  const baseY = size * 0.74;
  const halfBase = size * 0.3;
  const cx = size / 2;
  for (let y = 0; y < size; y++) {
    const t = (y - apexY) / (baseY - apexY);
    if (t < 0 || t > 1) continue;
    const halfW = halfBase * t;
    for (let x = 0; x < size; x++) {
      if (Math.abs(x - cx) <= halfW) {
        pixels[y * size + x] = ACCENT;
      }
    }
  }
  return pixels;
}

function makePng(size, pixels) {
  const raw = Buffer.alloc(size * (size * 4 + 1));
  let off = 0;
  for (let y = 0; y < size; y++) {
    raw[off++] = 0;
    for (let x = 0; x < size; x++) {
      const p = pixels[y * size + x];
      raw[off++] = p[0];
      raw[off++] = p[1];
      raw[off++] = p[2];
      raw[off++] = p[3];
    }
  }
  const ihdr = Buffer.alloc(13);
  ihdr.writeUInt32BE(size, 0);
  ihdr.writeUInt32BE(size, 4);
  ihdr[8] = 8;
  ihdr[9] = 6;
  const sig = Buffer.from([137, 80, 78, 71, 13, 10, 26, 10]);
  return Buffer.concat([
    sig,
    chunk("IHDR", ihdr),
    chunk("IDAT", deflateSync(raw, { level: 9 })),
    chunk("IEND", Buffer.alloc(0)),
  ]);
}

function makeIco(pngBuffer, size) {
  const header = Buffer.alloc(6);
  header.writeUInt16LE(0, 0);
  header.writeUInt16LE(1, 2);
  header.writeUInt16LE(1, 4);
  const entry = Buffer.alloc(16);
  entry[0] = size >= 256 ? 0 : size;
  entry[1] = size >= 256 ? 0 : size;
  entry.writeUInt16LE(1, 4);
  entry.writeUInt16LE(32, 6);
  entry.writeUInt32LE(pngBuffer.length, 8);
  entry.writeUInt32LE(6 + 16, 12);
  return Buffer.concat([header, entry, pngBuffer]);
}

mkdirSync("build", { recursive: true });

const png512 = makePng(512, renderPixels(512));
writeFileSync("build/icon.png", png512);

const png256 = makePng(256, renderPixels(256));
writeFileSync("build/icon.ico", makeIco(png256, 256));

console.log("build/icon.png e build/icon.ico gerados.");
