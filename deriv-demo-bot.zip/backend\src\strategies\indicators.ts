import type { Candle } from "../types.js";
import {
  emaSeries,
  rsiSeries,
  adxSeries,
  atrSeries,
  bollingerBands,
  lastValue,
} from "../services/indicatorService.js";

/** EMA sobre uma série esparsa (valores null ignorados, índice preservado). */
export function emaSparse(
  series: (number | null)[],
  period: number,
): (number | null)[] {
  const out: (number | null)[] = new Array(series.length).fill(null);
  const values: number[] = [];
  const indices: number[] = [];
  for (let i = 0; i < series.length; i++) {
    const v = series[i];
    if (v !== null && v !== undefined) {
      values.push(v);
      indices.push(i);
    }
  }
  if (values.length < period) {
    return out;
  }
  const alpha = 2 / (period + 1);
  let sum = 0;
  for (let j = 0; j < period; j++) {
    sum += values[j] ?? 0;
  }
  let ema = sum / period;
  out[indices[period - 1] ?? 0] = ema;
  for (let j = period; j < values.length; j++) {
    ema = alpha * (values[j] ?? 0) + (1 - alpha) * ema;
    out[indices[j] ?? 0] = ema;
  }
  return out;
}

export interface MacdResult {
  macd: (number | null)[];
  signal: (number | null)[];
  histogram: (number | null)[];
}

export function macdSeries(
  closes: number[],
  fast = 12,
  slow = 26,
  signalPeriod = 9,
): MacdResult {
  const emaFast = emaSeries(closes, fast);
  const emaSlow = emaSeries(closes, slow);
  const macd: (number | null)[] = closes.map((_, i) => {
    const f = emaFast[i];
    const s = emaSlow[i];
    if (f === null || f === undefined || s === null || s === undefined) {
      return null;
    }
    return f - s;
  });
  const signal = emaSparse(macd, signalPeriod);
  const histogram = macd.map((m, i) => {
    const s = signal[i];
    if (m === null || m === undefined || s === null || s === undefined) {
      return null;
    }
    return m - s;
  });
  return { macd, signal, histogram };
}

/** Série A cruza acima da série B no índice i (usando valores fechados). */
export function crossedAbove(
  a: (number | null)[],
  b: (number | null)[],
  i: number,
): boolean {
  if (i < 1) {
    return false;
  }
  const a0 = a[i];
  const b0 = b[i];
  const a1 = a[i - 1];
  const b1 = b[i - 1];
  if (
    a0 === null ||
    a0 === undefined ||
    b0 === null ||
    b0 === undefined ||
    a1 === null ||
    a1 === undefined ||
    b1 === null ||
    b1 === undefined
  ) {
    return false;
  }
  return a1 <= b1 && a0 > b0;
}

export function crossedBelow(
  a: (number | null)[],
  b: (number | null)[],
  i: number,
): boolean {
  if (i < 1) {
    return false;
  }
  const a0 = a[i];
  const b0 = b[i];
  const a1 = a[i - 1];
  const b1 = b[i - 1];
  if (
    a0 === null ||
    a0 === undefined ||
    b0 === null ||
    b0 === undefined ||
    a1 === null ||
    a1 === undefined ||
    b1 === null ||
    b1 === undefined
  ) {
    return false;
  }
  return a1 >= b1 && a0 < b0;
}

/** Maior máxima dos `lookback` candles anteriores ao índice `from` (exclusive). */
export function highestHigh(
  candles: Candle[],
  lookback: number,
  fromIndex: number,
): number | null {
  const start = fromIndex - lookback;
  let max: number | null = null;
  for (let i = start; i < fromIndex; i++) {
    const c = candles[i];
    if (!c) {
      continue;
    }
    if (max === null || c.high > max) {
      max = c.high;
    }
  }
  return max;
}

/** Menor mínima dos `lookback` candles anteriores ao índice `from` (exclusive). */
export function lowestLow(
  candles: Candle[],
  lookback: number,
  fromIndex: number,
): number | null {
  const start = fromIndex - lookback;
  let min: number | null = null;
  for (let i = start; i < fromIndex; i++) {
    const c = candles[i];
    if (!c) {
      continue;
    }
    if (min === null || c.low < min) {
      min = c.low;
    }
  }
  return min;
}

/** Último valor não-nulo da série. */
export function last(v: (number | null)[]): number | null {
  return lastValue(v);
}

/**
 * Agrega candles em um timeframe superior (agrupa `factor` candles em um).
 * Usado para confirmação de tendência em múltiplos timeframes a partir de uma
 * única série de candles (aproximação local, sem acesso a um segundo feed).
 */
export function aggregateHigherTimeframe(candles: Candle[], factor: number): Candle[] {
  if (factor <= 1) {
    return candles;
  }
  const out: Candle[] = [];
  for (let i = 0; i < candles.length; i += factor) {
    const slice = candles.slice(i, i + factor);
    const first = slice[0];
    if (!first) {
      continue;
    }
    let high = first.high;
    let low = first.low;
    let close = first.close;
    for (const c of slice) {
      if (c.high > high) {
        high = c.high;
      }
      if (c.low < low) {
        low = c.low;
      }
      close = c.close;
    }
    out.push({ time: first.time, open: first.open, high, low, close });
  }
  return out;
}

export function num(
  params: Record<string, number | boolean | string>,
  key: string,
  fallback: number,
): number {
  const v = params[key];
  return typeof v === "number" && Number.isFinite(v) ? v : fallback;
}

export function bool(
  params: Record<string, number | boolean | string>,
  key: string,
  fallback: boolean,
): boolean {
  const v = params[key];
  return typeof v === "boolean" ? v : fallback;
}

export {
  emaSeries,
  rsiSeries,
  adxSeries,
  atrSeries,
  bollingerBands,
};
