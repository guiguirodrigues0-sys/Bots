import type { Candle, IndicatorSnapshot } from "../types.js";

export function emaSeries(values: number[], period: number): (number | null)[] {
  const out: (number | null)[] = new Array(values.length).fill(null);
  if (values.length < period) {
    return out;
  }
  const alpha = 2 / (period + 1);
  let sum = 0;
  for (let i = 0; i < period; i++) {
    sum += values[i] ?? 0;
  }
  let ema = sum / period;
  out[period - 1] = ema;
  for (let i = period; i < values.length; i++) {
    ema = alpha * (values[i] ?? 0) + (1 - alpha) * ema;
    out[i] = ema;
  }
  return out;
}

export function smaSeries(values: number[], period: number): (number | null)[] {
  const out: (number | null)[] = new Array(values.length).fill(null);
  let sum = 0;
  for (let i = 0; i < values.length; i++) {
    sum += values[i] ?? 0;
    if (i >= period) {
      sum -= values[i - period] ?? 0;
    }
    if (i >= period - 1) {
      out[i] = sum / period;
    }
  }
  return out;
}

function rsiFromAvg(avgGain: number, avgLoss: number): number {
  if (avgLoss === 0) {
    return avgGain === 0 ? 50 : 100;
  }
  if (avgGain === 0) {
    return 0;
  }
  const rs = avgGain / avgLoss;
  return 100 - 100 / (1 + rs);
}

export function rsiSeries(values: number[], period = 14): (number | null)[] {
  const out: (number | null)[] = new Array(values.length).fill(null);
  if (values.length <= period) {
    return out;
  }
  let gain = 0;
  let loss = 0;
  for (let i = 1; i <= period; i++) {
    const diff = (values[i] ?? 0) - (values[i - 1] ?? 0);
    if (diff >= 0) {
      gain += diff;
    } else {
      loss -= diff;
    }
  }
  let avgGain = gain / period;
  let avgLoss = loss / period;
  out[period] = rsiFromAvg(avgGain, avgLoss);
  for (let i = period + 1; i < values.length; i++) {
    const diff = (values[i] ?? 0) - (values[i - 1] ?? 0);
    const g = diff > 0 ? diff : 0;
    const l = diff < 0 ? -diff : 0;
    avgGain = (avgGain * (period - 1) + g) / period;
    avgLoss = (avgLoss * (period - 1) + l) / period;
    out[i] = rsiFromAvg(avgGain, avgLoss);
  }
  return out;
}

export function wilderSmooth(series: (number | null)[], period: number): (number | null)[] {
  const values: number[] = [];
  const indices: number[] = [];
  for (let i = 0; i < series.length; i++) {
    const v = series[i];
    if (v !== null && v !== undefined) {
      values.push(v);
      indices.push(i);
    }
  }
  const out: (number | null)[] = new Array(series.length).fill(null);
  if (values.length < period) {
    return out;
  }
  let avg = 0;
  for (let i = 0; i < period; i++) {
    avg += values[i] ?? 0;
  }
  avg /= period;
  out[indices[period - 1] ?? 0] = avg;
  for (let i = period; i < values.length; i++) {
    avg = (avg * (period - 1) + (values[i] ?? 0)) / period;
    out[indices[i] ?? 0] = avg;
  }
  return out;
}

function trueRangeSeries(candles: Candle[]): (number | null)[] {
  const out: (number | null)[] = new Array(candles.length).fill(null);
  for (let i = 1; i < candles.length; i++) {
    const c = candles[i];
    const prev = candles[i - 1];
    if (!c || !prev) {
      continue;
    }
    out[i] = Math.max(
      c.high - c.low,
      Math.abs(c.high - prev.close),
      Math.abs(c.low - prev.close),
    );
  }
  return out;
}

export function atrSeries(candles: Candle[], period = 14): (number | null)[] {
  return wilderSmooth(trueRangeSeries(candles), period);
}

export function adxSeries(candles: Candle[], period = 14): (number | null)[] {
  const n = candles.length;
  const tr: (number | null)[] = new Array(n).fill(null);
  const plusDm: (number | null)[] = new Array(n).fill(null);
  const minusDm: (number | null)[] = new Array(n).fill(null);
  for (let i = 1; i < n; i++) {
    const c = candles[i];
    const prev = candles[i - 1];
    if (!c || !prev) {
      continue;
    }
    tr[i] = Math.max(
      c.high - c.low,
      Math.abs(c.high - prev.close),
      Math.abs(c.low - prev.close),
    );
    const up = c.high - prev.high;
    const down = prev.low - c.low;
    plusDm[i] = up > down && up > 0 ? up : 0;
    minusDm[i] = down > up && down > 0 ? down : 0;
  }
  const atr = wilderSmooth(tr, period);
  const pdiSm = wilderSmooth(plusDm, period);
  const mdiSm = wilderSmooth(minusDm, period);
  const dx: (number | null)[] = new Array(n).fill(null);
  for (let i = 0; i < n; i++) {
    const a = atr[i];
    const p = pdiSm[i];
    const m = mdiSm[i];
    if (a === null || a === undefined || p === null || p === undefined || m === null || m === undefined || a === 0) {
      continue;
    }
    const pdi = (100 * p) / a;
    const mdi = (100 * m) / a;
    const denom = pdi + mdi;
    dx[i] = denom === 0 ? 0 : (100 * Math.abs(pdi - mdi)) / denom;
  }
  return wilderSmooth(dx, period);
}

export function bollingerBands(
  values: number[],
  period = 20,
  mult = 2,
): {
  upper: (number | null)[];
  middle: (number | null)[];
  lower: (number | null)[];
} {
  const middle = smaSeries(values, period);
  const upper: (number | null)[] = new Array(values.length).fill(null);
  const lower: (number | null)[] = new Array(values.length).fill(null);
  for (let i = period - 1; i < values.length; i++) {
    const m = middle[i];
    if (m === null || m === undefined) {
      continue;
    }
    let sumSq = 0;
    for (let j = i - period + 1; j <= i; j++) {
      const diff = (values[j] ?? 0) - m;
      sumSq += diff * diff;
    }
    const std = Math.sqrt(sumSq / period);
    upper[i] = m + mult * std;
    lower[i] = m - mult * std;
  }
  return { upper, middle, lower };
}

export function computeIndicators(candles: Candle[]): IndicatorSnapshot {
  const closes = candles.map((c) => c.close);
  const ema20 = emaSeries(closes, 20).at(-1) ?? null;
  const ema50 = emaSeries(closes, 50).at(-1) ?? null;
  const ema200 = emaSeries(closes, 200).at(-1) ?? null;
  const rsi14 = rsiSeries(closes, 14).at(-1) ?? null;
  const adx = lastValue(adxSeries(candles, 14));
  const atr = lastValue(atrSeries(candles, 14));
  const bb = bollingerBands(closes, 20, 2);
  return {
    ema20,
    ema50,
    ema200,
    rsi14,
    adx,
    atr,
    bollingerUpper: lastValue(bb.upper),
    bollingerMiddle: lastValue(bb.middle),
    bollingerLower: lastValue(bb.lower),
  };
}

export function lastValue(series: (number | null)[]): number | null {
  for (let i = series.length - 1; i >= 0; i--) {
    const v = series[i];
    if (v !== null && v !== undefined) {
      return v;
    }
  }
  return null;
}
