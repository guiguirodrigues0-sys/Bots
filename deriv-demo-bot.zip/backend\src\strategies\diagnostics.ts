import type { Candle } from "../types.js";
import type { StrategyConfig, StrategyId } from "./types.js";
import { STRATEGY_IDS, STRATEGY_METADATA, defaultConfig } from "./definitions.js";
import { createStrategy } from "./registry.js";

export type StrategyDiagnosticStatus =
  | "OK"
  | "SEM_SINAL"
  | "DADOS_INSUFICIENTES"
  | "ERRO";

export interface StrategyDiagnosticEntry {
  strategyId: StrategyId;
  name: string;
  evaluations: number;
  buy: number;
  sell: number;
  wait: number;
  /** Avaliações bloqueadas por falta de dados/indicador inválido. */
  insufficient: number;
  /** Avaliações normais sem sinal (critérios não atendidos). */
  noSignal: number;
  /** Exceções lançadas durante a avaliação (falha técnica). */
  errors: number;
  lastError: string | null;
  status: StrategyDiagnosticStatus;
  /** Quantas vezes cada condição (label) falhou nas avaliações sem sinal. */
  conditionFailures: Record<string, number>;
}

export interface StrategiesDiagnostic {
  symbol: string;
  granularity: number;
  totalCandles: number;
  results: StrategyDiagnosticEntry[];
}

/**
 * Executa cada estratégia isoladamente sobre a mesma série de candles (sem
 * enviar ordens) e conta avaliações, sinais e falhas técnicas. Distingue
 * ausência legítima de oportunidades (NO_SIGNAL) de falhas (erros/exceções) e
 * de histórico insuficiente.
 */
export function diagnoseStrategiesOnCandles(
  candles: Candle[],
  symbol: string,
  granularity: number,
): StrategiesDiagnostic {
  const results: StrategyDiagnosticEntry[] = STRATEGY_IDS.map((id) => {
    const config: StrategyConfig = {
      ...defaultConfig(id),
      symbol,
      granularity,
    };
    const strategy = createStrategy(id);
    strategy.initialize();

    let evaluations = 0;
    let buy = 0;
    let sell = 0;
    let wait = 0;
    let insufficient = 0;
    let noSignal = 0;
    let errors = 0;
    let lastError: string | null = null;
    const conditionFailures: Record<string, number> = {};

    for (let i = 0; i < candles.length; i++) {
      const candle = candles[i];
      if (!candle) {
        continue;
      }
      evaluations += 1;
      try {
        strategy.onCandle(candle);
        const signal = strategy.evaluateSignal(candles.slice(0, i + 1), config);
        if (signal.direction === "BUY") {
          buy += 1;
        } else if (signal.direction === "SELL") {
          sell += 1;
        } else {
          wait += 1;
          if (
            signal.reasonCode === "INSUFFICIENT_CANDLES" ||
            signal.reasonCode === "INVALID_INDICATOR"
          ) {
            insufficient += 1;
          } else {
            noSignal += 1;
            for (const c of signal.conditions) {
              if (!c.passed) {
                conditionFailures[c.label] = (conditionFailures[c.label] ?? 0) + 1;
              }
            }
          }
        }
      } catch (err) {
        errors += 1;
        lastError = err instanceof Error ? err.message : String(err);
      }
    }

    strategy.dispose();

    let status: StrategyDiagnosticStatus;
    if (errors > 0) {
      status = "ERRO";
    } else if (buy + sell === 0) {
      status = insufficient >= evaluations ? "DADOS_INSUFICIENTES" : "SEM_SINAL";
    } else {
      status = "OK";
    }

    return {
      strategyId: id,
      name: STRATEGY_METADATA[id].name,
      evaluations,
      buy,
      sell,
      wait,
      insufficient,
      noSignal,
      errors,
      lastError,
      status,
      conditionFailures,
    };
  });

  return { symbol, granularity, totalCandles: candles.length, results };
}
