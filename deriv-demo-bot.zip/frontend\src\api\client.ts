export type EntryType = "INITIAL" | "ACTIVE";

export interface OpenTrade {
  contractId: string;
  proposalId: string;
  symbol: string;
  direction: "CALL" | "PUT";
  stake: number;
  entryTime: number;
  durationSeconds: number;
  durationUnit: string;
  askPrice: number;
  payout: number | null;
  entryType: EntryType;
  status: "OPEN" | "SETTLED";
  profit: number | null;
  settlementTime: number | null;
}

export type RapidPhase = "WAITING_SETUP" | "ACTIVE_MODE";

export interface RapidStats {
  trades: number;
  wins: number;
  losses: number;
  pnl: number;
  winRate: number;
}

export interface SplitStats {
  initial: RapidStats;
  active: RapidStats;
  total: RapidStats;
  consecutiveLosses: number;
  maxConsecutiveLosses: number;
  initialBalance: number;
  currentBalance: number;
  sessionPnL: number;
}

export interface HistoryRecord {
  id: string;
  timestamp: number;
  symbol: string;
  direction: "CALL" | "PUT";
  stake: number;
  entryPrice: number;
  score: number;
  result: "WIN" | "LOSS" | "PENDING" | "UNKNOWN";
  profitLoss: number | null;
  balanceAfter: number | null;
  entryType: EntryType;
}

export interface BotSnapshot {
  state: "STOPPED" | "RUNNING" | "PAUSED";
  mode: "SIGNAL_ONLY" | "DEMO_TRADE";
  symbol: string;
  label: string;
  contract: string;
  phase: RapidPhase;
  price: number | null;
  direction: "CALL" | "PUT" | "WAIT";
  score: number;
  confirmations: number | null;
  confirmationsTotal: number | null;
  momentum: number | null;
  rsi: number | null;
  fastEma: number | null;
  slowEma: number | null;
  volatilityPct: number | null;
  signalReason: string | null;
  openTrades: OpenTrade[];
  exposurePct: number;
  lastEntryTime: number | null;
  nextEntryAllowedAt: number | null;
  balance: number | null;
  currency: string | null;
  lastEvent: string | null;
  lastError: string | null;
  decisionBlockReason: string | null;
  stats: SplitStats;
  history: HistoryRecord[];
}

export interface PublicSession {
  status: "DISCONNECTED" | "CONNECTING" | "CONNECTED" | "ERROR";
  connected: boolean;
  accountId: string | null;
  accountType: string | null;
  currency: string | null;
  virtualBalance: number | null;
  appId: string | null;
  tokenMasked: string | null;
  error: string | null;
}

export async function getSession(): Promise<PublicSession> {
  const res = await fetch("/api/deriv/session");
  if (!res.ok) {
    throw new Error(`Falha ao buscar sessão: ${res.status}`);
  }
  const body = (await res.json()) as { session: PublicSession };
  return body.session;
}

export async function connectDeriv(appId: string, token: string): Promise<PublicSession> {
  const res = await fetch("/api/deriv/connect", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ appId, token }),
  });
  const body = (await res.json().catch(() => null)) as
    | { session?: PublicSession; error?: string }
    | null;
  if (!res.ok) {
    throw new Error(body?.error ?? `Falha ao conectar: ${res.status}`);
  }
  return body?.session as PublicSession;
}

export async function disconnectDeriv(): Promise<void> {
  const res = await fetch("/api/deriv/disconnect", { method: "POST" });
  if (!res.ok) {
    const body = (await res.json().catch(() => null)) as { error?: string } | null;
    throw new Error(body?.error ?? `Falha ao desconectar: ${res.status}`);
  }
}

export async function getHealth(): Promise<{ status: string; environment: string }> {
  const res = await fetch("/api/health");
  if (!res.ok) {
    throw new Error(`Health check falhou: ${res.status}`);
  }
  return res.json();
}

export async function getState(): Promise<BotSnapshot> {
  const res = await fetch("/api/bot/state");
  if (!res.ok) {
    throw new Error(`Falha ao buscar estado: ${res.status}`);
  }
  return res.json();
}

export async function startBot(): Promise<void> {
  const res = await fetch("/api/bot/start", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ mode: "DEMO_TRADE" }),
  });
  if (!res.ok) {
    const body = (await res.json().catch(() => null)) as { error?: string } | null;
    throw new Error(body?.error ?? `Falha ao iniciar: ${res.status}`);
  }
}

export async function stopBot(): Promise<void> {
  const res = await fetch("/api/bot/stop", { method: "POST" });
  if (!res.ok) {
    throw new Error(`Falha ao parar: ${res.status}`);
  }
}

export async function pauseBot(): Promise<void> {
  const res = await fetch("/api/bot/pause", { method: "POST" });
  if (!res.ok) {
    throw new Error(`Falha ao pausar: ${res.status}`);
  }
}

export async function resumeBot(): Promise<void> {
  const res = await fetch("/api/bot/resume", { method: "POST" });
  if (!res.ok) {
    throw new Error(`Falha ao retomar: ${res.status}`);
  }
}

// ---------------------------------------------------------------- Estratégias

export type StrategyId =
  | "CONFLUENCIA"
  | "SCALPING"
  | "TENDENCIA"
  | "REVERSAO_MEDIA"
  | "ROMPIMENTO"
  | "MACD_ADX"
  | "ADAPTATIVA"
  | "PRECISAO_EXTREMA";

export const STRATEGY_OPTIONS: Array<{ id: StrategyId; name: string }> = [
  { id: "CONFLUENCIA", name: "Confluência Inteligente" },
  { id: "SCALPING", name: "Scalping EMA + RSI" },
  { id: "TENDENCIA", name: "Seguidor de Tendência" },
  { id: "REVERSAO_MEDIA", name: "Reversão à Média" },
  { id: "ROMPIMENTO", name: "Rompimento de Volatilidade" },
  { id: "MACD_ADX", name: "MACD + ADX" },
  { id: "ADAPTATIVA", name: "Adaptativa" },
  { id: "PRECISAO_EXTREMA", name: "Precisão Extrema (Experimental)" },
];

/** Valores de granularity aceitos pela Deriv (em segundos). */
export const ALLOWED_GRANULARITIES = [
  60, 120, 180, 300, 600, 900, 1800, 3600, 7200, 14400, 28800, 86400,
] as const;

export const GRANULARITY_LABELS: Record<number, string> = {
  60: "1 minuto",
  120: "2 minutos",
  180: "3 minutos",
  300: "5 minutos",
  600: "10 minutos",
  900: "15 minutos",
  1800: "30 minutos",
  3600: "1 hora",
  7200: "2 horas",
  14400: "4 horas",
  28800: "8 horas",
  86400: "1 dia",
};

/** Rótulo curto de duração ("30 SEG", "5 MIN", "15 MIN"). */
export function durationLabel(d: number, u: string): string {
  if (u === "s") return `${d} SEG`;
  if (u === "m") return `${d} MIN`;
  if (u === "h") return `${d} H`;
  if (u === "t") return `${d} TICKS`;
  return `${d}${u}`;
}

export type StrategyProfile = "CONSERVADOR" | "MODERADO" | "AGRESSIVO";
export type SignalFrequency = "BAIXA" | "MEDIA" | "ALTA";

export interface StrategyConfig {
  symbol: string;
  contractType: "callput";
  granularity: number;
  duration: number;
  durationUnit: "s" | "m" | "h" | "t";
  fixedStake: number | null;
  stakePercent: number | null;
  stakeMode: "PERCENT" | "FIXED";
  maxTrades: number;
  cooldownSeconds: number;
  params: Record<string, number | boolean | string>;
}

export interface StrategyMetadata {
  id: StrategyId;
  name: string;
  description: string;
  indicators: string[];
  profile: StrategyProfile;
  frequency: SignalFrequency;
  markets: string[];
  winRate: number | null;
  netResult: number | null;
}

export interface StrategyLiveResult {
  trades: number;
  wins: number;
  losses: number;
  winRate: number;
  pnl: number;
}

export interface StrategyView {
  metadata: StrategyMetadata;
  config: StrategyConfig;
  status: { active: boolean; candleCount: number; lastDirection: string; lastSignalAt: number | null; reason: string | null; error: string | null };
  active: boolean;
  live: StrategyLiveResult | null;
}

export interface StrategyRiskConfig {
  stakeMode: "PERCENT" | "FIXED";
  stakePercent: number;
  fixedStake: number;
  dailyStopPct: number;
  dailyTargetPct: number | null;
  maxExposurePct: number;
  maxOpenTrades: number;
  cooldownSeconds: number;
  maxConsecutiveLosses: number | null;
}

export interface StrategiesResponse {
  ok: boolean;
  activeId: StrategyId | null;
  riskConfig: StrategyRiskConfig;
  strategies: StrategyView[];
}

export interface StrategySignal {
  strategyId: StrategyId;
  direction: "BUY" | "SELL" | "WAIT";
  reasonCode: string | null;
  reason: string;
  timestamp: number;
  price: number | null;
  conditions: Array<{ label: string; passed: boolean }>;
  indicators: Record<string, number | null>;
  regime: string | null;
}

export interface StrategyRuntimeSnapshot {
  state: "STOPPED" | "RUNNING" | "PAUSED";
  activeId: StrategyId | null;
  symbol: string;
  granularity: number;
  contract: string;
  duration: number;
  durationUnit: string;
  durationLabel: string;
  price: number | null;
  lastSignal: StrategySignal | null;
  openTrades: Array<{
    contractId: string;
    strategyId: StrategyId;
    direction: "CALL" | "PUT";
    stake: number;
    buyPrice: number | null;
    entryTime: number;
    duration: number;
    durationSeconds: number;
    durationUnit: string;
    granularity: number;
    profit: number | null;
    status: "OPEN" | "SETTLED";
    symbol: string;
  }>;
  exposurePct: number;
  balance: number | null;
  currency: string | null;
  lastEvent: string | null;
  lastError: string | null;
  decisionBlockReason: string | null;
  lastProposal: {
    timestamp: number;
    direction: "CALL" | "PUT";
    stake: number;
    accepted: boolean;
    detail: string;
  } | null;
  stats: {
    trades: number;
    wins: number;
    losses: number;
    pnl: number;
    winRate: number;
    consecutiveLosses: number;
    maxConsecutiveLosses: number;
    initialBalance: number;
    currentBalance: number;
    sessionPnL: number;
  };
  history: Array<{
    id: string;
    timestamp: number;
    symbol: string;
    direction: "CALL" | "PUT";
    strategyId: StrategyId;
    stake: number;
    entryPrice: number;
    result: "WIN" | "LOSS" | "PENDING" | "UNKNOWN";
    profitLoss: number | null;
  }>;
  /** Timestamp do último tick recebido (epoch ms). */
  lastTickAt: number | null;
  /** Timestamp do último candle fechado processado (epoch ms). */
  lastCandleAt: number | null;
  /** Timestamp da última avaliação da estratégia (epoch ms). */
  lastEvaluationAt: number | null;
  /** Estado detalhado da conexão WebSocket. */
  connectionState: "CONNECTED" | "RECONNECTING" | "DISCONNECTED" | "ERROR";
}

export interface StrategyStateResponse {
  ok: boolean;
  manager: {
    activeId: StrategyId | null;
    strategies: StrategyView[];
    signalHistory: StrategySignal[];
    rejectedSignals: Array<{ timestamp: number; strategyId: StrategyId; direction: string; reason: string; reasonCode: string }>;
    switchLog: Array<{ timestamp: number; from: StrategyId | null; to: StrategyId; reason: string }>;
    regime: string | null;
    regimeSwitchLog: Array<{ timestamp: number; from: string; to: string }>;
    candleCount: number;
    lastCandleTime: number | null;
  };
  runtime: StrategyRuntimeSnapshot;
}

export interface BacktestMetrics {
  trades: number;
  wins: number;
  losses: number;
  winRate: number;
  grossProfit: number;
  grossLoss: number;
  netPnl: number;
  profitFactor: number;
  maxDrawdown: number;
  maxDrawdownPct: number;
  expectancy: number;
  maxConsecutiveLosses: number;
  winRateCI: { low: number; high: number } | null;
}

export interface BacktestResult {
  strategyId: StrategyId;
  symbol: string;
  granularity: number;
  duration: number;
  durationUnit: string;
  payout: number;
  avgPayout: number;
  breakEvenWinRate: number;
  isEstimate: boolean;
  totalCandles: number;
  segments: Array<{
    label: string;
    candles: number;
    signals: { buy: number; sell: number; wait: number };
    metrics: BacktestMetrics;
    isEstimate: boolean;
  }>;
  aggregate: BacktestMetrics;
  note: string;
}

export async function getStrategies(): Promise<StrategiesResponse> {
  const res = await fetch("/api/strategies");
  if (!res.ok) throw new Error(`Falha ao buscar estratégias: ${res.status}`);
  return res.json();
}

export async function getStrategyState(): Promise<StrategyStateResponse> {
  const res = await fetch("/api/strategies/state");
  if (!res.ok) throw new Error(`Falha ao buscar estado das estratégias: ${res.status}`);
  return res.json();
}

export async function selectStrategy(id: StrategyId): Promise<void> {
  const res = await fetch("/api/strategies/select", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ id }),
  });
  if (!res.ok) {
    const body = (await res.json().catch(() => null)) as { error?: string } | null;
    throw new Error(body?.error ?? `Falha ao selecionar: ${res.status}`);
  }
}

export async function saveStrategyConfig(id: StrategyId, config: Partial<StrategyConfig>): Promise<void> {
  const res = await fetch("/api/strategies/config", {
    method: "PUT",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ id, config }),
  });
  if (!res.ok) {
    const body = (await res.json().catch(() => null)) as { error?: string } | null;
    throw new Error(body?.error ?? `Falha ao salvar config: ${res.status}`);
  }
}

export async function resetStrategyConfig(id: StrategyId): Promise<void> {
  const res = await fetch("/api/strategies/config/reset", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ id }),
  });
  if (!res.ok) throw new Error(`Falha ao restaurar padrões: ${res.status}`);
}

export async function saveStrategyRisk(risk: Partial<StrategyRiskConfig>): Promise<void> {
  const res = await fetch("/api/strategies/risk", {
    method: "PUT",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ risk }),
  });
  if (!res.ok) throw new Error(`Falha ao salvar risco: ${res.status}`);
}

export async function startStrategy(): Promise<void> {
  const res = await fetch("/api/strategies/start", { method: "POST" });
  if (!res.ok) {
    const body = (await res.json().catch(() => null)) as { error?: string } | null;
    throw new Error(body?.error ?? `Falha ao iniciar estratégia: ${res.status}`);
  }
}

export async function stopStrategy(): Promise<void> {
  const res = await fetch("/api/strategies/stop", { method: "POST" });
  if (!res.ok) throw new Error(`Falha ao parar estratégia: ${res.status}`);
}

export async function pauseStrategy(): Promise<void> {
  const res = await fetch("/api/strategies/pause", { method: "POST" });
  if (!res.ok) throw new Error(`Falha ao pausar estratégia: ${res.status}`);
}

export async function resumeStrategy(): Promise<void> {
  const res = await fetch("/api/strategies/resume", { method: "POST" });
  if (!res.ok) throw new Error(`Falha ao retomar estratégia: ${res.status}`);
}

export async function runStrategyBacktest(id: StrategyId): Promise<BacktestResult> {
  const res = await fetch("/api/strategies/backtest", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ id }),
  });
  if (!res.ok) {
    const body = (await res.json().catch(() => null)) as { error?: string } | null;
    throw new Error(body?.error ?? `Falha no backtest: ${res.status}`);
  }
  const body = (await res.json()) as { result: BacktestResult };
  return body.result;
}

export async function getStrategyBacktests(): Promise<{ ok: boolean; results: BacktestResult[] }> {
  const res = await fetch("/api/strategies/backtest");
  if (!res.ok) throw new Error(`Falha ao buscar backtests: ${res.status}`);
  return res.json();
}

// ------------------------------------------------------------ Mercados e testes

export interface ForexAssetInfo {
  assetId: string;
  label: string;
  symbol: string;
  available: boolean;
  contractTypes: string[];
  minDuration: string | null;
  maxDuration: string | null;
  minStake: number | null;
  maxStake: number | null;
}

export interface SyntheticIndexInfo {
  symbol: string;
  label: string;
  available: boolean;
  contractTypes: string[];
  minDuration: string | null;
  maxDuration: string | null;
  minStake: number | null;
  maxStake: number | null;
}

export interface MarketsResponse {
  ok: boolean;
  forex: ForexAssetInfo[];
  synthetic: SyntheticIndexInfo[];
}

export interface BatchStrategyResult {
  strategyId: StrategyId;
  name: string;
  signals: { buy: number; sell: number; wait: number };
  metrics: BacktestMetrics;
  noSignals: boolean;
}

export interface BatchTestResult {
  symbol: string;
  granularity: number;
  duration: number;
  durationUnit: string;
  contractAvailable: boolean;
  contractReason: string | null;
  isEstimate: boolean;
  totalCandles: number;
  results: BatchStrategyResult[];
  note: string;
  payout: number;
  breakEvenWinRate: number;
}

export async function getMarkets(): Promise<MarketsResponse> {
  const res = await fetch("/api/deriv/markets");
  if (!res.ok) throw new Error(`Falha ao buscar mercados: ${res.status}`);
  return res.json();
}

export interface ContractDurationOption {
  duration: number;
  unit: "s" | "m";
  label: string;
  available: boolean;
}

export interface ContractDurationsResponse {
  ok: boolean;
  symbol: string;
  contractCategory: string;
  minDuration: string | null;
  maxDuration: string | null;
  options: ContractDurationOption[];
  error?: string;
}

export async function getContractDurations(
  symbol: string,
  contractType = "callput",
): Promise<ContractDurationsResponse> {
  const params = new URLSearchParams({ symbol, contractType });
  const res = await fetch(`/api/deriv/contract-durations?${params.toString()}`);
  if (!res.ok) {
    const body = (await res.json().catch(() => null)) as { error?: string } | null;
    throw new Error(body?.error ?? `Falha ao consultar durações: ${res.status}`);
  }
  return res.json();
}

export async function testAllStrategies(req: {
  symbol: string;
  granularity: number;
  duration: number;
  durationUnit: string;
  count?: number;
  payout?: number;
}): Promise<BatchTestResult> {
  const res = await fetch("/api/strategies/test-all", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(req),
  });
  if (!res.ok) {
    const body = (await res.json().catch(() => null)) as { error?: string } | null;
    throw new Error(body?.error ?? `Falha no teste: ${res.status}`);
  }
  const body = (await res.json()) as { result: BatchTestResult };
  return body.result;
}

// ------------------------------------------------------------ Diagnóstico

export type StrategyDiagnosticStatus =
  | "OK"
  | "SEM_SINAL"
  | "DADOS_INSUFICIENTES"
  | "ERRO";

export interface StrategyDiagnosticEntry {
  strategyId: StrategyId;
  name: string;
  evaluations: number;
  buy: number;
  sell: number;
  wait: number;
  insufficient: number;
  noSignal: number;
  errors: number;
  lastError: string | null;
  status: StrategyDiagnosticStatus;
  conditionFailures: Record<string, number>;
}

export interface StrategiesDiagnostic {
  symbol: string;
  granularity: number;
  totalCandles: number;
  results: StrategyDiagnosticEntry[];
}

export async function diagnoseAllStrategies(req: {
  symbol: string;
  granularity: number;
  count?: number;
}): Promise<StrategiesDiagnostic> {
  const res = await fetch("/api/strategies/diagnose", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(req),
  });
  if (!res.ok) {
    const body = (await res.json().catch(() => null)) as { error?: string } | null;
    throw new Error(body?.error ?? `Falha no diagnóstico: ${res.status}`);
  }
  const body = (await res.json()) as { result: StrategiesDiagnostic };
  return body.result;
}

// ------------------------------------------------------------ Histórico

export interface PersistedTrade {
  id: string;
  timestamp: number;
  settlementTime: number | null;
  symbol: string;
  direction: "CALL" | "PUT";
  strategy: string;
  contractType: "callput";
  duration: number;
  durationUnit: string;
  granularity: number | null;
  stake: number;
  buyPrice: number | null;
  entryPrice: number;
  payout: number | null;
  result: "WIN" | "LOSS" | "PENDING" | "UNKNOWN";
  profitLoss: number | null;
  balanceAfter: number | null;
  entryType: "INITIAL" | "ACTIVE" | null;
  reason: string | null;
}

export async function getTrades(): Promise<PersistedTrade[]> {
  const res = await fetch("/api/trades");
  if (!res.ok) throw new Error(`Falha ao buscar histórico: ${res.status}`);
  const body = (await res.json()) as { trades: PersistedTrade[] };
  return body.trades;
}
