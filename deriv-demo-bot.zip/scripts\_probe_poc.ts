import { DerivApiClient } from "../backend/src/deriv/apiClient.js";
import { WebSocketManager } from "../backend/src/deriv/wsManager.js";

process.env.LOG_LEVEL = "error";

async function main() {
  const client = new DerivApiClient();
  const url = await client.getDemoWebSocketUrl();
  const ws = new WebSocketManager();
  await ws.connect(url);

  // Captura mensagens proposal_open_contract (streaming).
  ws.onMessage((msg) => {
    if (msg.msg_type === "proposal_open_contract" && msg.proposal_open_contract) {
      const p = msg.proposal_open_contract as Record<string, unknown>;
      console.log(
        `STREAM contract_id=${p.contract_id} status=${p.status} is_sold=${p.is_sold} is_expired=${p.is_expired} profit=${p.profit} sell_price=${p.sell_price} buy_price=${p.buy_price}`,
      );
    }
  });

  // Assina o contrato que já venceu (16846724179).
  try {
    const r = await ws.request({
      proposal_open_contract: 1,
      contract_id: 16846724179,
      subscribe: 1,
    });
    const p = (r as { proposal_open_contract?: Record<string, unknown> }).proposal_open_contract;
    console.log(
      `RESPOSTA INICIAL: status=${p?.status} is_sold=${p?.is_sold} is_expired=${p?.is_expired} profit=${p?.profit} sell_price=${p?.sell_price}`,
    );
  } catch (e) {
    console.log("proposal_open_contract ERRO:", e instanceof Error ? e.message : String(e));
  }

  // Aguarda um pouco para capturar streaming.
  await new Promise((r) => setTimeout(r, 3000));
  await ws.close();
}

main().catch((e) => {
  console.error("FALHA:", e instanceof Error ? e.message : String(e));
  process.exit(1);
});
