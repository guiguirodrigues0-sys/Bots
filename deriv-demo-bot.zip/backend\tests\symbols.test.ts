import { test } from "node:test";
import assert from "node:assert/strict";
import {
  durationToSeconds,
  parseDuration,
  checkContractAvailability,
  resolveAssets,
  resolveContractDurations,
  durationLabel,
  CONTRACT_DURATION_OPTIONS,
} from "../src/deriv/symbols.js";
import type { WebSocketManager } from "../src/deriv/wsManager.js";

process.env.LOG_LEVEL = "error";

test("durationToSeconds converte s/m/h/d corretamente", () => {
  assert.equal(durationToSeconds("15s"), 15);
  assert.equal(durationToSeconds("30s"), 30);
  assert.equal(durationToSeconds("5m"), 300);
  assert.equal(durationToSeconds("1h"), 3600);
  assert.equal(durationToSeconds("1d"), 86400);
});

test("durationToSeconds não converte ticks para segundos", () => {
  assert.ok(Number.isNaN(durationToSeconds("1t")));
  assert.ok(Number.isNaN(durationToSeconds("10t")));
});

test("parseDuration identifica unidade t", () => {
  assert.deepEqual(parseDuration("5t"), { n: 5, unit: "t" });
  assert.deepEqual(parseDuration("30s"), { n: 30, unit: "s" });
  assert.deepEqual(parseDuration("15m"), { n: 15, unit: "m" });
});

test("parseDuration rejeita formato inválido", () => {
  assert.equal(parseDuration("abc"), null);
  assert.equal(parseDuration("15"), null);
});

function wsWith(available: Array<Record<string, string>>) {
  return {
    request: async () => ({ contracts_for: { available } }),
  } as unknown as WebSocketManager;
}

test("checkContractAvailability aceita R_100 30s", async () => {
  const ws = wsWith([
    { contract_category: "callput", min_contract_duration: "15s", max_contract_duration: "1d" },
    { contract_category: "callput", min_contract_duration: "1t", max_contract_duration: "10t" },
  ]);
  const r = await checkContractAvailability(ws, "R_100", "callput", 30, "s");
  assert.equal(r.ok, true);
});

test("checkContractAvailability aceita ticks (1t a 10t)", async () => {
  const ws = wsWith([
    { contract_category: "callput", min_contract_duration: "1t", max_contract_duration: "10t" },
  ]);
  const r = await checkContractAvailability(ws, "R_100", "callput", 5, "t");
  assert.equal(r.ok, true);
});

test("checkContractAvailability rejeita 11t (fora de 1-10)", async () => {
  const ws = wsWith([
    { contract_category: "callput", min_contract_duration: "1t", max_contract_duration: "10t" },
  ]);
  const r = await checkContractAvailability(ws, "R_100", "callput", 11, "t");
  assert.equal(r.ok, false);
});

test("checkContractAvailability rejeita Forex 30s (mínimo 15m)", async () => {
  const ws = wsWith([
    { contract_category: "callput", min_contract_duration: "15m", max_contract_duration: "1d" },
  ]);
  const r = await checkContractAvailability(ws, "frxEURUSD", "callput", 30, "s");
  assert.equal(r.ok, false);
});

test("checkContractAvailability rejeita categoria ausente", async () => {
  const ws = wsWith([]);
  const r = await checkContractAvailability(ws, "BOOM1000", "callput", 30, "s");
  assert.equal(r.ok, false);
});

test("resolveAssets retorna Forex com duração mínima/máxima (15m a 365d)", async () => {
  const ws = {
    request: async (payload: Record<string, unknown>) => {
      if (payload.active_symbols !== undefined) {
        return {
          active_symbols: [
            { underlying_symbol: "frxEURUSD" },
            { underlying_symbol: "frxGBPUSD" },
          ],
        };
      }
      if (payload.contracts_for !== undefined) {
        return {
          contracts_for: {
            available: [
              { contract_category: "callput", min_contract_duration: "1d", max_contract_duration: "365d" },
              { contract_category: "callput", min_contract_duration: "15m", max_contract_duration: "1d" },
            ],
          },
        };
      }
      return {};
    },
  } as unknown as WebSocketManager;

  const resolved = await resolveAssets(ws);
  assert.equal(resolved.EURUSD?.symbol, "frxEURUSD");
  assert.equal(resolved.EURUSD?.available, true);
  assert.equal(resolved.EURUSD?.minDuration, "15m");
  assert.equal(resolved.EURUSD?.maxDuration, "365d");
  assert.equal(resolved.GBPUSD?.symbol, "frxGBPUSD");
  assert.equal(resolved.GBPUSD?.minDuration, "15m");
});

// ------------------------------------------------------------ Durações configuráveis

test("durationLabel formata segundos e minutos", () => {
  assert.equal(durationLabel(30, "s"), "30 SEG");
  assert.equal(durationLabel(1, "m"), "1 MIN");
  assert.equal(durationLabel(5, "m"), "5 MIN");
  assert.equal(durationLabel(15, "m"), "15 MIN");
  assert.equal(durationLabel(2, "h"), "2 H");
  assert.equal(durationLabel(5, "t"), "5 TICKS");
});

test("CONTRACT_DURATION_OPTIONS contém as 7 durações desejadas", () => {
  assert.deepEqual(
    CONTRACT_DURATION_OPTIONS.map((o) => `${o.duration}${o.unit}`),
    ["30s", "1m", "2m", "3m", "5m", "10m", "15m"],
  );
});

test("resolveContractDurations habilita todas as opções para R_100 (15s–1d)", async () => {
  const ws = wsWith([
    { contract_category: "callput", min_contract_duration: "15s", max_contract_duration: "1d" },
    { contract_category: "callput", min_contract_duration: "1t", max_contract_duration: "10t" },
  ]);
  const r = await resolveContractDurations(ws, "R_100", "callput");
  assert.equal(r.options.length, 7);
  assert.ok(r.options.every((o) => o.available), "todas as durações deveriam estar disponíveis");
});

test("resolveContractDurations habilita SOMENTE 15m para Forex (mínimo 15m)", async () => {
  const ws = wsWith([
    { contract_category: "callput", min_contract_duration: "15m", max_contract_duration: "1d" },
  ]);
  const r = await resolveContractDurations(ws, "frxEURUSD", "callput");

  const byLabel = Object.fromEntries(r.options.map((o) => [`${o.duration}${o.unit}`, o.available]));
  // 30s, 1m, 2m, 3m, 5m, 10m indisponíveis; apenas 15m disponível.
  assert.equal(byLabel["30s"], false);
  assert.equal(byLabel["1m"], false);
  assert.equal(byLabel["2m"], false);
  assert.equal(byLabel["3m"], false);
  assert.equal(byLabel["5m"], false);
  assert.equal(byLabel["10m"], false);
  assert.equal(byLabel["15m"], true);
});

test("resolveContractDurations retorna intervalo para exibição (15m–1d)", async () => {
  const ws = wsWith([
    { contract_category: "callput", min_contract_duration: "15m", max_contract_duration: "1d" },
  ]);
  const r = await resolveContractDurations(ws, "frxEURUSD", "callput");
  assert.equal(r.minDuration, "15m");
  assert.equal(r.maxDuration, "1d");
});
