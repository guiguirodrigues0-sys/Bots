import fs from "node:fs";
import path from "node:path";
import type {
  StrategyConfig,
  StrategyId,
} from "./types.js";
import { STRATEGY_IDS, defaultConfig } from "./definitions.js";
import { DEFAULT_STRATEGY_RISK_CONFIG, type StrategyRiskConfig } from "../services/riskManager.js";
import { isValidGranularity } from "../services/marketDataService.js";
import { logger } from "../logger/index.js";

export interface PersistedState {
  activeId: StrategyId | null;
  configs: Record<StrategyId, StrategyConfig>;
  riskConfig: StrategyRiskConfig;
}

function configPath(): string {
  const dbPath = process.env.DB_PATH || "./data/deriv-demo-bot.db";
  const dir = path.dirname(dbPath);
  if (!fs.existsSync(dir)) {
    fs.mkdirSync(dir, { recursive: true });
  }
  const base = path.basename(dbPath).replace(/\.db$/i, "");
  return path.join(dir, `${base}-strategies.json`);
}

export class StrategyStore {
  private path = configPath();
  private state: PersistedState = this.empty();

  private empty(): PersistedState {
    const configs = {} as Record<StrategyId, StrategyConfig>;
    for (const id of STRATEGY_IDS) {
      configs[id] = defaultConfig(id);
    }
    return {
      activeId: null,
      configs,
      riskConfig: { ...DEFAULT_STRATEGY_RISK_CONFIG },
    };
  }

  load(): PersistedState {
    try {
      if (!fs.existsSync(this.path)) {
        return this.state;
      }
      const raw = JSON.parse(fs.readFileSync(this.path, "utf8")) as Partial<PersistedState>;
      const next = this.empty();
      let sanitized = false;
      if (raw.activeId && STRATEGY_IDS.includes(raw.activeId)) {
        next.activeId = raw.activeId;
      }
      if (raw.configs) {
        for (const id of STRATEGY_IDS) {
          const c = raw.configs[id];
          if (c) {
            next.configs[id] = {
              ...next.configs[id],
              ...c,
              params: { ...next.configs[id].params, ...(c.params ?? {}) },
            };
            // Migração: configurações persistidas por versões antigas podiam
            // salvar granularity inválido (ex.: 1s). Restaura o padrão com aviso.
            if (!isValidGranularity(next.configs[id].granularity)) {
              logger.warn("Granularity persistido inválido; restaurando padrão", {
                strategyId: id,
                granularity: next.configs[id].granularity,
                padrao: defaultConfig(id).granularity,
              });
              next.configs[id].granularity = defaultConfig(id).granularity;
              sanitized = true;
            }
          }
        }
      }
      if (raw.riskConfig) {
        next.riskConfig = { ...DEFAULT_STRATEGY_RISK_CONFIG, ...raw.riskConfig };
      }
      this.state = next;
      if (sanitized) {
        this.save();
      }
    } catch (err) {
      logger.warn("Falha ao carregar configurações de estratégias", {
        message: err instanceof Error ? err.message : String(err),
      });
    }
    return this.state;
  }

  save(): void {
    try {
      fs.writeFileSync(this.path, JSON.stringify(this.state, null, 2), "utf8");
    } catch (err) {
      logger.warn("Falha ao persistir configurações de estratégias", {
        message: err instanceof Error ? err.message : String(err),
      });
    }
  }

  get(): PersistedState {
    return this.state;
  }

  setActiveId(id: StrategyId | null): void {
    this.state.activeId = id;
    this.save();
  }

  setConfig(id: StrategyId, config: StrategyConfig): void {
    this.state.configs[id] = config;
    this.save();
  }

  resetConfig(id: StrategyId): void {
    this.state.configs[id] = defaultConfig(id);
    this.save();
  }

  setRiskConfig(risk: StrategyRiskConfig): void {
    this.state.riskConfig = { ...DEFAULT_STRATEGY_RISK_CONFIG, ...risk };
    this.save();
  }
}
