import WebSocket from "ws";
import { logger } from "../logger/index.js";

export type WsMessage = Record<string, any>;

interface PendingRequest {
  resolve: (value: WsMessage) => void;
  reject: (reason: Error) => void;
  timer: NodeJS.Timeout;
}

const PING_INTERVAL_MS = 30000;

export class WebSocketManager {
  private ws: WebSocket | null = null;
  private reqId = 0;
  private pending = new Map<number, PendingRequest>();
  private handlers = new Set<(msg: WsMessage) => void>();
  private closeHandlers = new Set<(code: number, reason: string) => void>();
  private pingTimer: NodeJS.Timeout | null = null;

  get isConnected(): boolean {
    return this.ws?.readyState === WebSocket.OPEN;
  }

  connect(url: string): Promise<void> {
    return new Promise((resolve, reject) => {
      let opened = false;
      const ws = new WebSocket(url);
      this.ws = ws;

      ws.on("open", () => {
        opened = true;
        this.startHeartbeat();
        logger.info("WebSocket conectado");
        resolve();
      });

      ws.on("error", (err) => {
        logger.warn("WebSocket error", { message: err.message });
      });

      ws.on("close", (code, reason) => {
        if (!opened) {
          reject(new Error(`WebSocket fechou antes de conectar (code=${code})`));
        }
        this.handleClose(code, reason);
      });

      ws.on("message", (data) => this.handleMessage(data));
    });
  }

  private handleMessage(data: WebSocket.RawData): void {
    let msg: WsMessage;
    try {
      msg = JSON.parse(data.toString()) as WsMessage;
    } catch {
      logger.warn("Mensagem WS inválida (não-JSON)");
      return;
    }

    if (msg.msg_type === "ping" && typeof msg.req_id !== "number") {
      this.send({ pong: 1 });
      return;
    }

    if (typeof msg.req_id === "number") {
      const pending = this.pending.get(msg.req_id);
      if (pending) {
        this.pending.delete(msg.req_id);
        clearTimeout(pending.timer);
        if (msg.error) {
          pending.reject(new Error(JSON.stringify(msg.error)));
        } else {
          pending.resolve(msg);
        }
      }
    }

    for (const h of this.handlers) {
      try {
        h(msg);
      } catch (e) {
        logger.error("Erro em handler de mensagem WS", e);
      }
    }
  }

  private startHeartbeat(): void {
    this.stopHeartbeat();
    this.pingTimer = setInterval(() => {
      if (this.isConnected) {
        this.send({ ping: 1 });
      }
    }, PING_INTERVAL_MS);
  }

  private stopHeartbeat(): void {
    if (this.pingTimer) {
      clearInterval(this.pingTimer);
      this.pingTimer = null;
    }
  }

  private handleClose(code: number, reason: Buffer): void {
    this.stopHeartbeat();
    for (const [, p] of this.pending) {
      clearTimeout(p.timer);
      p.reject(new Error("WebSocket fechado antes da resposta"));
    }
    this.pending.clear();
    logger.warn("WebSocket desconectado", { code, reason: reason.toString() });
    const reasonText = reason.toString();
    for (const h of this.closeHandlers) {
      try {
        h(code, reasonText);
      } catch (e) {
        logger.error("Erro em handler de close WS", e);
      }
    }
  }

  send(payload: Record<string, unknown>): void {
    if (!this.ws || this.ws.readyState !== WebSocket.OPEN) {
      throw new Error("WebSocket não conectado");
    }
    this.ws.send(JSON.stringify(payload));
  }

  request(payload: Record<string, unknown>, timeoutMs = 15000): Promise<WsMessage> {
    const reqId = ++this.reqId;
    return new Promise<WsMessage>((resolve, reject) => {
      const timer = setTimeout(() => {
        this.pending.delete(reqId);
        reject(new Error(`Timeout aguardando resposta req_id=${reqId}`));
      }, timeoutMs);
      this.pending.set(reqId, { resolve, reject, timer });
      try {
        this.send({ ...payload, req_id: reqId });
      } catch (e) {
        clearTimeout(timer);
        this.pending.delete(reqId);
        reject(e as Error);
      }
    });
  }

  onMessage(handler: (msg: WsMessage) => void): void {
    this.handlers.add(handler);
  }

  onClose(handler: (code: number, reason: string) => void): void {
    this.closeHandlers.add(handler);
  }

  async close(): Promise<void> {
    this.stopHeartbeat();
    if (this.ws) {
      this.ws.close();
      this.ws = null;
    }
  }
}
