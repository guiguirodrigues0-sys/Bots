const { app, BrowserWindow, dialog, utilityProcess } = require("electron");
const { autoUpdater } = require("electron-updater");
const updateConfig = require("./update-config.cjs");
const path = require("node:path");
const http = require("node:http");
const net = require("node:net");

const PORT_START = 47821;
const HEALTH_TIMEOUT_MS = 20000;

let backend = null;
let mainWindow = null;
let backendPort = null;

function findFreePort(start) {
  return new Promise((resolve) => {
    const attempt = (port) => {
      const server = net.createServer();
      server.once("error", () => attempt(port + 1));
      server.once("listening", () => {
        server.close(() => resolve(port));
      });
      server.listen(port, "127.0.0.1");
    };
    attempt(start);
  });
}

function waitForHealth(port) {
  return new Promise((resolve, reject) => {
    const deadline = Date.now() + HEALTH_TIMEOUT_MS;
    const attempt = () => {
      const req = http.get(
        { host: "127.0.0.1", port, path: "/api/health", timeout: 1500 },
        (res) => {
          if (res.statusCode === 200) {
            res.resume();
            resolve();
          } else {
            res.resume();
            retry();
          }
        },
      );
      req.on("error", retry);
      req.on("timeout", () => {
        req.destroy();
        retry();
      });
    };
    const retry = () => {
      if (Date.now() > deadline) {
        reject(new Error("Backend não respondeu em tempo hábil."));
        return;
      }
      setTimeout(attempt, 250);
    };
    attempt();
  });
}

async function startBackend() {
  backendPort = await findFreePort(PORT_START);

  const backendEntry = path.join(__dirname, "backend.cjs");
  const frontendDist = path.join(__dirname, "..", "frontend", "dist");

  process.env.DERIV_ENVIRONMENT = "demo";
  process.env.ALLOW_REAL_ACCOUNT = "false";
  process.env.HOST = "127.0.0.1";
  process.env.PORT = String(backendPort);
  process.env.DB_PATH = path.join(app.getPath("userData"), "deriv-demo-bot.db");
  process.env.FRONTEND_DIST = frontendDist;
  process.env.LOG_LEVEL = "info";

  backend = utilityProcess.fork(backendEntry, [], { stdio: "ignore" });
  backend.on("exit", () => {
    backend = null;
  });

  await waitForHealth(backendPort);
}

function createWindow() {
  mainWindow = new BrowserWindow({
    width: 1360,
    height: 900,
    minWidth: 1024,
    minHeight: 700,
    show: false,
    backgroundColor: "#0b0e13",
    autoHideMenuBar: true,
    title: "Deriv Auto Trader",
    webPreferences: {
      contextIsolation: true,
      nodeIntegration: false,
      sandbox: true,
      preload: path.join(__dirname, "preload.cjs"),
    },
  });

  mainWindow.once("ready-to-show", () => {
    mainWindow.show();
  });

  mainWindow.on("closed", () => {
    mainWindow = null;
  });

  mainWindow.webContents.setWindowOpenHandler(() => ({ action: "deny" }));

  mainWindow.webContents.on("will-navigate", (event, url) => {
    if (!url.startsWith(`http://127.0.0.1:${backendPort}`)) {
      event.preventDefault();
    }
  });

  mainWindow.loadURL(`http://127.0.0.1:${backendPort}`);
}

function stopBackend() {
  if (backend) {
    try {
      backend.kill();
    } catch {
      /* ignore */
    }
    backend = null;
  }
}

function setupAutoUpdater() {
  // Atualização automática só vale para o app empacotado (não em dev).
  if (!app.isPackaged) {
    return;
  }
  const { owner, repo } = updateConfig;
  if (!owner || !repo || owner.includes("SEU_") || repo.includes("SEU_")) {
    return;
  }
  try {
    autoUpdater.setFeedURL({ provider: "github", owner, repo });
    autoUpdater.autoDownload = true;
    autoUpdater.autoInstallOnAppQuit = true;
    autoUpdater.on("error", () => {
      /* falha silenciosa: tenta novamente no próximo intervalo */
    });
    // Checa ao abrir e depois a cada 1 hora.
    setTimeout(() => {
      autoUpdater.checkForUpdates().catch(() => {});
    }, 8000);
    setInterval(() => {
      autoUpdater.checkForUpdates().catch(() => {});
    }, 60 * 60 * 1000);
  } catch {
    /* ignore */
  }
}

const gotLock = app.requestSingleInstanceLock();

if (!gotLock) {
  app.quit();
} else {
  app.on("second-instance", () => {
    if (mainWindow) {
      if (mainWindow.isMinimized()) mainWindow.restore();
      mainWindow.focus();
    }
  });

  app.whenReady().then(async () => {
    try {
      await startBackend();
      createWindow();
      setupAutoUpdater();
    } catch (err) {
      dialog.showErrorBox(
        "Deriv Auto Trader",
        "Não foi possível iniciar o Deriv Auto Trader.",
      );
      app.quit();
    }
  });

  app.on("before-quit", () => {
    stopBackend();
  });

  app.on("window-all-closed", () => {
    app.quit();
  });

  app.on("activate", () => {
    if (BrowserWindow.getAllWindows().length === 0 && backendPort) {
      createWindow();
    }
  });
}
