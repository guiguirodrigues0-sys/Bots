import { useEffect, useState } from "react";
import {
  getStrategyState,
  selectStrategy,
  startStrategy,
  stopStrategy,
  pauseStrategy,
  resumeStrategy,
  saveStrategyConfig,
  getMarkets,
  durationLabel,
  type StrategyId,
  type StrategyRuntimeSnapshot,
  type MarketsResponse,
} from "../../api/client";

interface Props {
  strategyId: StrategyId;
  strategyName: string;
  connected: boolean;
}

const MARKET_LABELS: Record<string, string> = {
  frxEURUSD: "EUR/USD",
  frxGBPUSD: "GBP/USD",
  R_75: "Volatility 75",
  R_100: "Volatility 100",
  R_50: "Volatility 50",
  R_25: "Volatility 25",
  R_10: "Volatility 10",
};

function marketLabel(symbol: string): string {
  return MARKET_LABELS[symbol] ?? symbol;
}

/** Duração padrão compatível com o mercado (mínima de Rise/Fall). */
function defaultDurationFor(symbol: string): { duration: number; durationUnit: "s" | "m" } {
  if (symbol.startsWith("frx")) {
    return { duration: 15, durationUnit: "m" };
  }
  return { duration: 30, durationUnit: "s" };
}

function currencySymbol(cur: string | null): string {
  if (!cur) return "";
  if (cur === "USD") return "$";
  return `${cur} `;
}

function fmtMoney(v: number | null | undefined, cur: string | null): string {
  if (v === null || v === undefined) return "—";
  return `${currencySymbol(cur)}${v.toLocaleString("pt-BR", {
    minimumFractionDigits: 2,
    maximumFractionDigits: 2,
  })}`;
}

function fmtSignedMoney(v: number | null | undefined, cur: string | null): string {
  if (v === null || v === undefined) return "—";
  const sign = v > 0 ? "+" : v < 0 ? "-" : "";
  return `${sign}${currencySymbol(cur)}${Math.abs(v).toLocaleString("pt-BR", {
    minimumFractionDigits: 2,
    maximumFractionDigits: 2,
  })}`;
}

function fmtPrice(v: number | null | undefined): string {
  if (v === null || v === undefined) return "—";
  return v.toFixed(5);
}

function fmtPct(v: number | null | undefined, digits = 2): string {
  if (v === null || v === undefined) return "—";
  return `${v.toFixed(digits)}%`;
}

function fmtTime(epochMs: number | null | undefined): string {
  if (epochMs === null || epochMs === undefined) return "—";
  return new Date(epochMs).toLocaleTimeString("pt-BR");
}

function fmtRemaining(entryTime: number, durationSeconds: number): string {
  const ms = entryTime + durationSeconds * 1000 - Date.now();
  if (ms <= 0) return "00:00";
  const s = Math.max(0, Math.round(ms / 1000));
  const m = Math.floor(s / 60);
  const ss = s % 60;
  return `${String(m).padStart(2, "0")}:${String(ss).padStart(2, "0")}`;
}

function dirLabel(d: string): string {
  if (d === "BUY" || d === "CALL") return "ALTA";
  if (d === "SELL" || d === "PUT") return "BAIXA";
  return "AGUARDAR";
}

function dirClass(d: string): string {
  if (d === "BUY" || d === "CALL") return "signal-call";
  if (d === "SELL" || d === "PUT") return "signal-put";
  return "signal-aguardar";
}

export default function StrategyLiveView({ strategyId, strategyName, connected }: Props) {
  const [runtime, setRuntime] = useState<StrategyRuntimeSnapshot | null>(null);
  const [markets, setMarkets] = useState<MarketsResponse | null>(null);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    let alive = true;
    const tick = async () => {
      try {
        const st = await getStrategyState();
        if (alive) setRuntime(st.runtime);
      } catch {
        if (alive) setError("Não foi possível carregar o estado da estratégia.");
      }
    };
    void tick();
    const id = setInterval(tick, 1500);
    return () => {
      alive = false;
      clearInterval(id);
    };
  }, []);

  useEffect(() => {
    let alive = true;
    const load = async () => {
      try {
        const m = await getMarkets();
        if (alive) setMarkets(m);
      } catch {
        if (alive) setMarkets(null);
      }
    };
    void load();
    return () => {
      alive = false;
    };
  }, []);

  useEffect(() => {
    void selectStrategy(strategyId).catch((e) => {
      setError(e instanceof Error ? e.message : String(e));
    });
  }, [strategyId]);

  const run = async (fn: () => Promise<void>) => {
    setBusy(true);
    setError(null);
    try {
      await fn();
    } catch (e) {
      setError(e instanceof Error ? e.message : String(e));
    } finally {
      setBusy(false);
    }
  };

  const running = runtime?.state === "RUNNING";
  const paused = runtime?.state === "PAUSED";
  const stopped = runtime?.state === "STOPPED" || runtime?.state === undefined;
  const currency = runtime?.currency ?? null;
  const openTrades = (runtime?.openTrades ?? []).filter((t) => t.status === "OPEN");
  const allOpenTrades = (runtime?.openTrades ?? []).filter((t) => t.status === "OPEN"); // All symbols
  const stats = runtime?.stats;

  // Connection state label
  const connStateLabel = {
    CONNECTED: "Conectado",
    RECONNECTING: "Reconectando...",
    DISCONNECTED: "Desconectado",
    ERROR: "Erro",
  } as const;

  // Format timestamp helper
  const fmtDateTime = (ms: number | null | undefined): string => {
    if (!ms) return "—";
    return new Date(ms).toLocaleString("pt-BR", {
      hour: "2-digit",
      minute: "2-digit",
      second: "2-digit",
      day: "2-digit",
      month: "2-digit",
    });
  };

  // Check for old Volatility 100 contracts stuck at 00:00
  const stuckContracts = allOpenTrades.filter((t) => {
    const remaining = t.entryTime + t.durationSeconds * 1000 - Date.now();
    return remaining <= 0 && t.symbol.startsWith("R_");
  });

  // Lista plana de mercados (forex + sintéticos).
  const marketOptions = [
    ...(markets?.forex ?? []).map((m) => ({ symbol: m.symbol, label: m.label, available: m.available })),
    ...(markets?.synthetic ?? []).map((m) => ({ symbol: m.symbol, label: m.label, available: m.available })),
  ];

  const onMarketChange = async (symbol: string) => {
    setBusy(true);
    setError(null);
    const wasRunning = running;
    try {
      if (wasRunning || paused) {
        await stopStrategy();
      }
      const d = defaultDurationFor(symbol);
      await saveStrategyConfig(strategyId, {
        symbol,
        duration: d.duration,
        durationUnit: d.durationUnit,
      });
      await selectStrategy(strategyId);
      if (wasRunning) {
        await startStrategy();
      }
    } catch (e) {
      setError(e instanceof Error ? e.message : String(e));
    } finally {
      setBusy(false);
    }
  };

  return (
    <>
      <section className="summary">
        <div className="stat">
          <div className="stat-label">Estratégia</div>
          <div className="stat-value" style={{ fontSize: 16 }}>
            {strategyName}
            {runtime?.durationLabel ? ` — ${runtime.durationLabel}` : ""}
          </div>
          <div className="stat-sub muted">{runtime?.symbol ?? "—"}</div>
        </div>
        <div className="stat">
          <div className="stat-label">Saldo</div>
          <div className="stat-value">{fmtMoney(runtime?.balance ?? null, currency)}</div>
        </div>
        <div className="stat">
          <div className="stat-label">Resultado da sessão</div>
          <div className={`stat-value ${(stats?.pnl ?? 0) >= 0 ? "pos" : "neg"}`}>
            {fmtSignedMoney(stats?.pnl ?? null, currency)}
          </div>
        </div>
        <div className="stat">
          <div className="stat-label">Exposição</div>
          <div className="stat-value">{fmtPct(runtime?.exposurePct ?? 0)}</div>
        </div>
      </section>

      {error && (
        <div className="error-box">
          <p>{error}</p>
        </div>
      )}

      <div className="main">
        <div className="col-left">
          <section className="panel">
            <header className="panel-head">
              <h2>Estratégia (DEMO)</h2>
              <span className={`bot-status ${running ? "is-running" : paused ? "is-paused" : "is-stopped"}`}>
                <span className="status-dot" />
                {running ? "Ativo" : paused ? "Pausado" : "Parado"}
              </span>
            </header>
            <div className="bot-body">
              <div className="bot-asset">
                <label htmlFor="market-select" style={{ marginRight: 8 }}>
                  Mercado
                </label>
                <select
                  id="market-select"
                  value={runtime?.symbol ?? ""}
                  onChange={(e) => void onMarketChange(e.target.value)}
                  disabled={busy || openTrades.length > 0}
                >
                  {!marketOptions.some((m) => m.symbol === runtime?.symbol) && runtime?.symbol && (
                    <option value={runtime.symbol}>{marketLabel(runtime.symbol)}</option>
                  )}
                  {marketOptions.map((m) => (
                    <option key={m.symbol} value={m.symbol}>
                      {m.label} ({m.symbol}){m.available ? "" : " · indisponível"}
                    </option>
                  ))}
                </select>
              </div>
              <div className="bot-actions">
                <button
                  className="btn btn-primary"
                  disabled={busy || !stopped || !connected}
                  onClick={() => run(async () => {
                    await selectStrategy(strategyId);
                    await startStrategy();
                  })}
                >
                  Iniciar
                </button>
                {paused ? (
                  <button className="btn" disabled={busy} onClick={() => run(resumeStrategy)}>
                    Retomar
                  </button>
                ) : (
                  <button className="btn" disabled={busy || !running} onClick={() => run(pauseStrategy)}>
                    Pausar
                  </button>
                )}
                <button className="btn btn-danger" disabled={busy || stopped} onClick={() => run(stopStrategy)}>
                  Parar
                </button>
              </div>
              {!connected && (
                <p className="notice neg">Conecte-se à Deriv DEMO antes de iniciar.</p>
              )}
              {runtime?.lastEvent && (
                <p className={`notice ${/CONEXÃO EXPIRADA|BLOQUEADA|ERRO/.test(runtime.lastEvent) ? "neg" : ""}`}>
                  {runtime.lastEvent}
                </p>
              )}
              {runtime?.lastError && (
                <div className="error-box">
                  <p>{runtime.lastError.length > 300 ? `${runtime.lastError.slice(0, 300)}…` : runtime.lastError}</p>
                </div>
              )}
            </div>
          </section>

          <section className="panel">
            <header className="panel-head">
              <h2>Mercado</h2>
            </header>
            <div className="market">
              <div className="market-head">
                <span className="market-name">{runtime?.symbol ?? "—"}</span>
                <span className="market-price">{fmtPrice(runtime?.price)}</span>
              </div>
              <div className="market-primary">
                <div className="mp-item">
                  <span className="mp-label">Ativo</span>
                  <span className="mp-value">{runtime?.symbol ?? "—"}</span>
                </div>
                <div className="mp-item">
                  <span className="mp-label">Contrato</span>
                  <span className="mp-value">{runtime?.contract ?? "—"}</span>
                </div>
                <div className="mp-item">
                  <span className="mp-label">Timeframe</span>
                  <span className="mp-value">{runtime?.granularity ? `${runtime.granularity}s` : "—"}</span>
                </div>
                <div className="mp-item">
                  <span className="mp-label">Direção</span>
                  <span className={`signal-badge ${dirClass(runtime?.lastSignal?.direction ?? "WAIT")}`}>
                    {dirLabel(runtime?.lastSignal?.direction ?? "WAIT")}
                  </span>
                </div>
              </div>
              {runtime?.lastSignal?.reason && <p className="muted">{runtime.lastSignal.reason}</p>}
              {runtime?.decisionBlockReason && (
                <p className="notice neg">Último bloqueio: {runtime.decisionBlockReason}</p>
              )}
            </div>
          </section>

          <section className="panel">
            <header className="panel-head">
              <h2>Estatísticas</h2>
            </header>
            <div className="summary">
              <div className="stat">
                <div className="stat-label">Operações</div>
                <div className="stat-value">{stats?.trades ?? 0}</div>
              </div>
              <div className="stat">
                <div className="stat-label">Acertos</div>
                <div className="stat-value">{stats?.wins ?? 0}</div>
              </div>
              <div className="stat">
                <div className="stat-label">Erros</div>
                <div className="stat-value">{stats?.losses ?? 0}</div>
              </div>
              <div className="stat">
                <div className="stat-label">Acerto</div>
                <div className="stat-value">{fmtPct(stats?.winRate ?? null, 1)}</div>
              </div>
            </div>
          </section>

          {/* Nova seção: Estado da conexão e timestamps */}
          <section className="panel">
            <header className="panel-head">
              <h2>Estado da Conexão</h2>
            </header>
            <div className="market-primary">
              <div className="mp-item">
                <span className="mp-label">WebSocket</span>
                <span className={`mp-value ${runtime?.connectionState === "CONNECTED" ? "pos" : runtime?.connectionState === "RECONNECTING" ? "neg" : runtime?.connectionState === "ERROR" ? "neg" : ""}`}>
                  {runtime?.connectionState ? connStateLabel[runtime.connectionState] : "Desconhecido"}
                </span>
              </div>
              <div className="mp-item">
                <span className="mp-label">Último Tick</span>
                <span className="mp-value">{fmtDateTime(runtime?.lastTickAt)}</span>
              </div>
              <div className="mp-item">
                <span className="mp-label">Último Candle</span>
                <span className="mp-value">{fmtDateTime(runtime?.lastCandleAt)}</span>
              </div>
              <div className="mp-item">
                <span className="mp-label">Última Avaliação</span>
                <span className="mp-value">{fmtDateTime(runtime?.lastEvaluationAt)}</span>
              </div>
            </div>
            {stuckContracts.length > 0 && (
              <p className="notice neg">
                ⚠ {stuckContracts.length} contrato(s) Volatility 100 com tempo expirado (00:00) — verifique reconciliação.
              </p>
            )}
          </section>
        </div>

        <div className="col-right">
          <section className="panel">
            <header className="panel-head">
              <h2>Posições abertas</h2>
            </header>
            {openTrades.length === 0 && allOpenTrades.length === 0 ? (
              <div className="muted">Nenhuma posição em andamento.</div>
            ) : (
              <>
                <div className="notice muted" style={{ marginBottom: 8 }}>
                  {openTrades.length} posição(ões) no símbolo atual ({runtime?.symbol})
                  {allOpenTrades.length > openTrades.length && (
                    <span> · {allOpenTrades.length} total (inclui outros símbolos)</span>
                  )}
                </div>
                <table className="table">
                  <thead>
                    <tr>
                      <th>Símbolo</th>
                      <th>Direção</th>
                      <th>Stake</th>
                      <th>Duração</th>
                      <th>Entrada</th>
                      <th>Restante</th>
                    </tr>
                  </thead>
                  <tbody>
                    {allOpenTrades.map((t) => (
                      <tr key={t.contractId} style={{ opacity: t.symbol === runtime?.symbol ? 1 : 0.6 }}>
                        <td>{t.symbol}</td>
                        <td>
                          <span className={`signal-badge ${dirClass(t.direction)}`}>{dirLabel(t.direction)}</span>
                        </td>
                        <td>
                          {fmtMoney(t.buyPrice ?? t.stake, currency)}
                          {t.buyPrice !== null && t.buyPrice !== t.stake && (
                            <span className="muted" title="Valor efetivamente cobrado pela Deriv">
                              {" "}≠ {fmtMoney(t.stake, currency)}
                            </span>
                          )}
                        </td>
                        <td>{durationLabel(t.duration, t.durationUnit)}</td>
                        <td>{fmtTime(t.entryTime)}</td>
                        <td>{fmtRemaining(t.entryTime, t.durationSeconds)}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </>
            )}
          </section>

          <section className="panel">
            <header className="panel-head">
              <h2>Histórico</h2>
            </header>
            <table className="table">
              <thead>
                <tr>
                  <th>Horário</th>
                  <th>Direção</th>
                  <th>Resultado</th>
                  <th>P/L</th>
                </tr>
              </thead>
              <tbody>
                {(runtime?.history ?? []).length === 0 ? (
                  <tr className="empty">
                    <td colSpan={4}>Nenhuma operação nesta sessão.</td>
                  </tr>
                ) : (
                  (runtime?.history ?? [])
                    .slice()
                    .reverse()
                    .map((r) => (
                      <tr key={r.id}>
                        <td>{fmtTime(r.timestamp)}</td>
                        <td>
                          <span className={`signal-badge ${dirClass(r.direction)}`}>{dirLabel(r.direction)}</span>
                        </td>
                        <td className={r.result === "WIN" ? "pos" : r.result === "LOSS" ? "neg" : ""}>
                          {r.result}
                        </td>
                        <td className={(r.profitLoss ?? 0) >= 0 ? "pos" : "neg"}>
                          {fmtSignedMoney(r.profitLoss, currency)}
                        </td>
                      </tr>
                    ))
                )}
              </tbody>
            </table>
          </section>
        </div>
      </div>
    </>
  );
}
