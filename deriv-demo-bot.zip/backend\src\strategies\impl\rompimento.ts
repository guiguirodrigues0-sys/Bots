import type { Candle } from "../../types.js";
import { BaseStrategy, makeSignal, insufficientSignal } from "../base.js";
import type {
  StrategyConfig,
  StrategyId,
  StrategySignal,
  StrategyCondition,
} from "../types.js";
import { atrSeries, highestHigh, lowestLow, last, num } from "../indicators.js";

/**
 * Estratégia 5 — Rompimento de Volatilidade.
 * Detecta rompimentos de suporte/resistência (máx/mín 20 candles, ATR 14).
 * Volume só seria usado se estivesse disponível e confiável (não fornecido
 * pela Deriv para estes subjacentes).
 */
export class RompimentoStrategy extends BaseStrategy {
  readonly id: StrategyId = "ROMPIMENTO";

  evaluateSignal(candles: Candle[], config: StrategyConfig): StrategySignal {
    const price = candles.at(-1)?.close ?? null;
    if (price === null || candles.length < 2) {
      return insufficientSignal(this.id, price);
    }

    const lookback = num(config.params, "lookback", 20);
    const atrPeriod = num(config.params, "atrPeriod", 14);
    const atrMinMult = num(config.params, "atrMinMult", 1.0);
    const atrMaxMult = num(config.params, "atrMaxMult", 3.0);

    const atr = last(atrSeries(candles, atrPeriod));
    if (atr === null || atr <= 0) {
      return insufficientSignal(this.id, price);
    }

    const i = candles.length - 1;
    const candle = candles[i];
    if (!candle) {
      return insufficientSignal(this.id, price);
    }
    const prevHigh = highestHigh(candles, lookback, i);
    const prevLow = lowestLow(candles, lookback, i);
    if (prevHigh === null || prevLow === null) {
      return insufficientSignal(this.id, price);
    }

    const range = candle.high - candle.low;
    const rangeOk = range >= atr * atrMinMult;
    const breakoutUp = candle.close > prevHigh;
    const breakoutDown = candle.close < prevLow;
    // Rompimento não deve estar excessivamente estendido.
    const notExtendedUp = candle.close - prevHigh <= atr * atrMaxMult;
    const notExtendedDown = prevLow - candle.close <= atr * atrMaxMult;

    const buyConditions: StrategyCondition[] = [
      { label: "Fechamento acima da máxima dos 20 candles", passed: breakoutUp },
      { label: `Amplitude >= ${atrMinMult}x ATR`, passed: rangeOk },
      { label: "Sem retorno imediato para a faixa", passed: notExtendedUp },
    ];

    const sellConditions: StrategyCondition[] = [
      { label: "Fechamento abaixo da mínima dos 20 candles", passed: breakoutDown },
      { label: `Amplitude >= ${atrMinMult}x ATR`, passed: rangeOk },
      { label: "Sem retorno imediato para a faixa", passed: notExtendedDown },
    ];

    const indicators = { atr, prevHigh, prevLow, range };

    if (buyConditions.every((c) => c.passed)) {
      return makeSignal(
        this.id,
        "BUY",
        price,
        buyConditions,
        indicators,
        `SINAL BUY — rompimento de resistência (${candle.close.toFixed(5)} > ${prevHigh.toFixed(5)}, ATR ${atr.toFixed(5)}).`,
      );
    }
    if (sellConditions.every((c) => c.passed)) {
      return makeSignal(
        this.id,
        "SELL",
        price,
        sellConditions,
        indicators,
        `SINAL SELL — rompimento de suporte (${candle.close.toFixed(5)} < ${prevLow.toFixed(5)}, ATR ${atr.toFixed(5)}).`,
      );
    }

    const shown = candle.close >= prevHigh ? buyConditions : sellConditions;
    return makeSignal(
      this.id,
      "WAIT",
      price,
      shown,
      indicators,
      `AGUARDAR — sem rompimento válido (máx ${prevHigh.toFixed(5)}, mín ${prevLow.toFixed(5)}).`,
      null,
      "NO_SIGNAL",
    );
  }
}
