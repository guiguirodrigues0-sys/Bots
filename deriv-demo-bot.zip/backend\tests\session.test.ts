import { test, afterEach } from "node:test";
import assert from "node:assert/strict";
import {
  DerivSessionManager,
  ConnectionError,
  sanitizeSecrets,
} from "../src/deriv/sessionManager.js";
import { DemoAccountBlockedError } from "../src/deriv/apiClient.js";
import { getActiveCredentials, setActiveCredentials } from "../src/deriv/credentials.js";

process.env.LOG_LEVEL = "error";

afterEach(() => {
  setActiveCredentials(null);
});

function fakeWs() {
  const calls: Array<Record<string, unknown>> = [];
  return {
    calls,
    connect: async () => {},
    close: async () => {},
    request: async (payload: Record<string, unknown>) => {
      calls.push(payload);
      if (payload.balance !== undefined) {
        return { balance: { balance: 10000, currency: "USD" } };
      }
      if (payload.active_symbols !== undefined) {
        return {
          active_symbols: [
            { underlying_symbol: "frxEURUSD" },
            { underlying_symbol: "frxGBPUSD" },
          ],
        };
      }
      if (payload.contracts_for !== undefined) {
        return { contracts_for: { available: [{ contract_category: "callput" }] } };
      }
      return {};
    },
  };
}

interface ManagerOptions {
  accounts?: Array<Record<string, unknown>>;
  url?: () => Promise<string>;
}

function makeManager(opts: ManagerOptions = {}) {
  const accounts =
    opts.accounts ??
    ([{ account_id: "D1", account_type: "demo", currency: "USD", balance: "10000" }] as Array<Record<string, unknown>>);
  const urlFn = opts.url ?? (async () => "wss://example/ws/demo?token=abc");
  const ws = fakeWs();
  const sm = new DerivSessionManager({
    createClient: () =>
      ({
        listAccounts: async () => accounts,
        getDemoWebSocketUrl: urlFn,
      }) as never,
    createWs: () => ws as never,
  });
  return { sm, ws };
}

test("App ID vazio rejeita conexão", async () => {
  const { sm } = makeManager();
  await assert.rejects(() => sm.connect("", "token"), /App ID inválido/);
});

test("Token vazio rejeita conexão", async () => {
  const { sm } = makeManager();
  await assert.rejects(() => sm.connect("app", ""), /Token inválido/);
});

test("conta REAL é rejeitada na conexão", async () => {
  const { sm } = makeManager({
    accounts: [{ account_id: "R1", account_type: "real", currency: "USD", balance: "100" }],
  });
  await assert.rejects(
    () => sm.connect("app", "token"),
    /exclusivamente com contas DEMO/,
  );
});

test("conta DEMO é aceita e popula a sessão", async () => {
  const { sm } = makeManager();
  const pub = await sm.connect("app", "token");
  assert.equal(pub.connected, true);
  assert.equal(pub.accountType, "demo");
  assert.equal(pub.accountId, "D1");
  assert.equal(pub.currency, "USD");
  assert.equal(pub.virtualBalance, 10000);
});

test("token nunca é retornado pelo endpoint de sessão", async () => {
  const { sm } = makeManager();
  const pub = await sm.connect("app", "secret-token-abc");
  assert.ok(!("token" in pub));
  assert.ok(!("apiToken" in pub));
  assert.equal(pub.tokenMasked, "••••••••••••••••");
  assert.ok(!JSON.stringify(pub).includes("secret-token-abc"));
});

test("token não aparece após sanitização", () => {
  const out = sanitizeSecrets("erro com secret-token-abc no meio", ["secret-token-abc"]);
  assert.ok(!out.includes("secret-token-abc"));
  assert.ok(out.includes("[REDACTED]"));
});

test("sem sessão e sem credenciais .env, bot não pode iniciar", () => {
  const { sm } = makeManager();
  const prevApp = process.env.DERIV_APP_ID;
  const prevTok = process.env.DERIV_API_TOKEN;
  process.env.DERIV_APP_ID = "";
  process.env.DERIV_API_TOKEN = "";
  try {
    assert.equal(sm.hasCredentials(), false);
  } finally {
    process.env.DERIV_APP_ID = prevApp;
    process.env.DERIV_API_TOKEN = prevTok;
  }
});

test("desconectar remove credenciais da memória", async () => {
  const { sm } = makeManager();
  await sm.connect("app", "token");
  assert.equal(sm.isConnected, true);
  assert.notEqual(getActiveCredentials(), null);

  await sm.disconnect();
  assert.equal(sm.isConnected, false);
  assert.equal(getActiveCredentials(), null);

  const pub = sm.getPublic();
  assert.equal(pub.appId, null);
  assert.equal(pub.tokenMasked, null);
  assert.equal(pub.accountType, null);
});

test("troca de credenciais é bloqueada enquanto bot está ativo", () => {
  const { sm } = makeManager();
  assert.equal(sm.canConnect("RUNNING").ok, false);
  assert.equal(sm.canConnect("PAUSED").ok, false);
  assert.equal(sm.canConnect("STOPPED").ok, true);
});

test("endpoint REAL (DemoAccountBlockedError) continua bloqueando a conexão", async () => {
  const { sm } = makeManager({
    url: async () => {
      throw new DemoAccountBlockedError();
    },
  });
  await assert.rejects(() => sm.connect("app", "token"), ConnectionError);
});

test("disconnectIfSafe sem posição → permitido", async () => {
  const { sm } = makeManager();
  await sm.connect("app", "token");
  const result = await sm.disconnectIfSafe(false);
  assert.equal(result.ok, true);
  assert.equal(sm.isConnected, false);
});

test("disconnectIfSafe com posição aberta → bloqueado", async () => {
  const { sm } = makeManager();
  await sm.connect("app", "token");
  const result = await sm.disconnectIfSafe(true);
  assert.equal(result.ok, false);
  assert.equal(sm.isConnected, true);
});

test("credenciais permanecem em memória quando disconnect é bloqueado", async () => {
  const { sm } = makeManager();
  await sm.connect("app", "secret-token");
  const result = await sm.disconnectIfSafe(true);
  assert.equal(result.ok, false);
  assert.equal(sm.isConnected, true);
  assert.notEqual(getActiveCredentials(), null);
  assert.equal(getActiveCredentials()?.token, "secret-token");
});

test("após settlement, disconnect passa a ser permitido", async () => {
  const { sm } = makeManager();
  await sm.connect("app", "token");
  await sm.disconnectIfSafe(true);
  assert.equal(sm.isConnected, true);
  const result = await sm.disconnectIfSafe(false);
  assert.equal(result.ok, true);
  assert.equal(sm.isConnected, false);
});
