import { test, afterEach } from "node:test";
import assert from "node:assert/strict";
import { TradeExecutor } from "../src/services/tradeExecutor.js";
import {
  normalizeStake,
  computeEffectiveStrategyStake,
  DEFAULT_STRATEGY_RISK_CONFIG,
} from "../src/services/riskManager.js";
import { createStrategy } from "../src/strategies/registry.js";
import { defaultConfig } from "../src/strategies/definitions.js";
import type { WebSocketManager } from "../src/deriv/wsManager.js";
import type { Candle } from "../src/types.js";

process.env.LOG_LEVEL = "error";

const originalFetch = globalThis.fetch;

afterEach(() => {
  (globalThis as unknown as { fetch: unknown }).fetch = originalFetch;
});

function mockDemoAccount() {
  (globalThis as unknown as { fetch: unknown }).fetch = async () => ({
    ok: true,
    status: 200,
    json: async () => ({
      data: [{ account_id: "D1", account_type: "demo", currency: "USD", balance: "10000" }],
    }),
    text: async () =>
      JSON.stringify({
        data: [{ account_id: "D1", account_type: "demo", currency: "USD", balance: "10000" }],
      }),
    headers: { get: () => null },
  });
}

const CONTRACTS_30S = {
  available: [
    { contract_category: "callput", min_contract_duration: "15s", max_contract_duration: "1d" },
  ],
};

function scriptedWs() {
  const calls: Array<Record<string, unknown>> = [];
  const ws = {
    request: async (payload: Record<string, unknown>) => {
      calls.push(payload);
      if (payload.contracts_for !== undefined) {
        return { contracts_for: CONTRACTS_30S };
      }
      if (payload.buy !== undefined) {
        return { buy: { contract_id: 123, buy_price: 1 } };
      }
      throw new Error("requisição inesperada no mock");
    },
  };
  return { calls, ws: ws as unknown as WebSocketManager };
}

async function runStake(stake: number) {
  const { calls, ws } = scriptedWs();
  const executor = new TradeExecutor();
  await executor.execute(ws, "R_100", "CALL", stake, 30, "s", "USD");
  return calls.find((c) => c.buy !== undefined) as Record<string, unknown>;
}

function uptrend(n: number): Candle[] {
  const out: Candle[] = [];
  let close = 100;
  for (let i = 0; i < n; i++) {
    const open = close;
    close = open + 0.02 + (i % 4) * 0.005;
    out.push({ time: i * 60, open, high: close + 0.02, low: open - 0.02, close });
  }
  return out;
}

// ---------------------------------------------------------------- Stake

test("normalizeStake preserva 19 e 22 exatos (sem arredondamento surpresa)", () => {
  assert.equal(normalizeStake(19, "USD"), 19);
  assert.equal(normalizeStake(22, "USD"), 22);
  assert.equal(normalizeStake(19.999, "USD"), 19.99); // trunca, não arredonda para cima
});

test("stake fixa 19 e 22 são resolvidas respeitando o teto global", () => {
  const global = {
    ...DEFAULT_STRATEGY_RISK_CONFIG,
    stakeMode: "FIXED" as const,
    fixedStake: 100,
  };
  assert.equal(
    computeEffectiveStrategyStake(1000, { stakeMode: "FIXED", stakePercent: null, fixedStake: 19 }, global, "USD"),
    19,
  );
  assert.equal(
    computeEffectiveStrategyStake(1000, { stakeMode: "FIXED", stakePercent: null, fixedStake: 22 }, global, "USD"),
    22,
  );
});

test("mudar stake de 19 para 22 altera SOMENTE amount/price (não contrato/duração/símbolo)", async () => {
  mockDemoAccount();
  const a = await runStake(19);
  const b = await runStake(22);

  const pa = a.parameters as Record<string, unknown>;
  const pb = b.parameters as Record<string, unknown>;

  // O valor da stake aparece em `price` e em `parameters.amount`.
  assert.equal(a.price, 19);
  assert.equal(b.price, 22);
  assert.equal(pa.amount, 19);
  assert.equal(pb.amount, 22);
  assert.equal(pa.basis, "stake");
  assert.equal(pb.basis, "stake");

  // Todos os demais parâmetros do contrato devem ser idênticos.
  for (const key of [
    "basis",
    "contract_type",
    "duration",
    "duration_unit",
    "underlying_symbol",
    "currency",
  ]) {
    assert.deepEqual(
      pa[key],
      pb[key],
      `campo "${key}" divergiu entre stake 19 e 22 (${String(pa[key])} vs ${String(pb[key])})`,
    );
  }
});

test("sinal (direção/condições/indicadores) independe da stake configurada", () => {
  const candles = uptrend(300);
  const strategy = createStrategy("CONFLUENCIA");
  const base = defaultConfig("CONFLUENCIA");

  const a = strategy.evaluateSignal(
    candles,
    { ...base, stakeMode: "FIXED", stakePercent: null, fixedStake: 19 },
  );
  const b = strategy.evaluateSignal(
    candles,
    { ...base, stakeMode: "FIXED", stakePercent: null, fixedStake: 22 },
  );

  assert.equal(a.direction, b.direction);
  assert.deepEqual(a.conditions, b.conditions);
  assert.deepEqual(a.indicators, b.indicators);
  assert.equal(a.reasonCode, b.reasonCode);
});
