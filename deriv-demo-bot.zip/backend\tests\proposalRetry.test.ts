import { test } from "node:test";
import assert from "node:assert/strict";
import { TradeExecutor } from "../src/services/tradeExecutor.js";
import type { WebSocketManager } from "../src/deriv/wsManager.js";

process.env.LOG_LEVEL = "error";

const CONTRACTS_OK = {
  contracts_for: {
    available: [
      {
        contract_category: "callput",
        min_contract_duration: "15s",
        max_contract_duration: "1d",
      },
    ],
  },
};

function wsWith(buy: () => Record<string, unknown> | never) {
  const ws = {
    request: async (payload: Record<string, unknown>) => {
      if (payload.contracts_for !== undefined) {
        return CONTRACTS_OK;
      }
      if (payload.buy !== undefined) {
        return buy();
      }
      throw new Error("requisição inesperada no mock");
    },
  };
  return ws as unknown as WebSocketManager;
}

test("executor refaz a compra quando o buy retorna erro transitório", async () => {
  let buyCalls = 0;
  const ws = wsWith(() => {
    buyCalls += 1;
    if (buyCalls === 1) {
      throw new Error(
        JSON.stringify({ code: "PriceMoved", message: "price moved" }),
      );
    }
    return {
      buy: {
        contract_id: 12345,
        buy_price: 1,
        payout: "1.90",
        balance_after: 9999,
      },
    };
  });

  const executor = new TradeExecutor();
  const trade = await executor.execute(ws, "R_100", "CALL", 2, 30, "s", "USD");

  assert.equal(trade.contractId, "12345");
  assert.equal(buyCalls, 2);
});

test("executor NÃO refaz compra para erro não transitório", async () => {
  let buyCalls = 0;
  const ws = wsWith(() => {
    buyCalls += 1;
    throw new Error(JSON.stringify({ code: "SomeOtherError", message: "não transitório" }));
  });

  const executor = new TradeExecutor();
  await assert.rejects(() => executor.execute(ws, "R_100", "CALL", 2, 30, "s", "USD"));
  assert.equal(buyCalls, 1);
});
