import type { Strategy, StrategyId } from "./types.js";
import { ConfluenciaStrategy } from "./impl/confluencia.js";
import { ScalpingStrategy } from "./impl/scalping.js";
import { TendenciaStrategy } from "./impl/tendencia.js";
import { ReversaoMediaStrategy } from "./impl/reversaoMedia.js";
import { RompimentoStrategy } from "./impl/rompimento.js";
import { MacdAdxStrategy } from "./impl/macdAdx.js";
import { AdaptativaStrategy } from "./impl/adaptativa.js";
import { PrecisaoExtremaStrategy } from "./impl/precisaoExtrema.js";

export function createStrategy(id: StrategyId): Strategy {
  switch (id) {
    case "CONFLUENCIA":
      return new ConfluenciaStrategy();
    case "SCALPING":
      return new ScalpingStrategy();
    case "TENDENCIA":
      return new TendenciaStrategy();
    case "REVERSAO_MEDIA":
      return new ReversaoMediaStrategy();
    case "ROMPIMENTO":
      return new RompimentoStrategy();
    case "MACD_ADX":
      return new MacdAdxStrategy();
    case "ADAPTATIVA":
      return new AdaptativaStrategy();
    case "PRECISAO_EXTREMA":
      return new PrecisaoExtremaStrategy();
  }
}

export { AdaptativaStrategy } from "./impl/adaptativa.js";
export { PrecisaoExtremaStrategy } from "./impl/precisaoExtrema.js";
