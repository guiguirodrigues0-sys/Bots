@echo off
cd /d "%~dp0"

echo ============================================
echo   Deriv Demo Bot - Iniciando...
echo ============================================
echo.
echo Abrindo Backend (porta 3001)...
start "Deriv Bot - Backend" cmd /k npm run dev:backend

echo Abrindo Frontend (porta 5173)...
start "Deriv Bot - Frontend" cmd /k npm run dev:frontend

timeout /t 6 /nobreak >nul
start "" http://localhost:5173

echo.
echo Navegador aberto em http://localhost:5173
echo NAO feche as janelas "Deriv Bot - Backend" e "Deriv Bot - Frontend".
echo.
pause
