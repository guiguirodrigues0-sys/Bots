import type { Candle } from "../../types.js";
import { BaseStrategy, makeSignal, insufficientSignal } from "../base.js";
import type {
  StrategyConfig,
  StrategyId,
  StrategySignal,
  StrategyCondition,
} from "../types.js";
import { emaSeries, adxSeries, last, num } from "../indicators.js";

/**
 * Estratégia 3 — Seguidor de Tendência.
 * Opera a favor de movimentos direcionais (EMA 50/200, ADX 14).
 */
export class TendenciaStrategy extends BaseStrategy {
  readonly id: StrategyId = "TENDENCIA";

  evaluateSignal(candles: Candle[], config: StrategyConfig): StrategySignal {
    const closes = candles.map((c) => c.close);
    const price = closes.at(-1) ?? null;
    if (price === null) {
      return insufficientSignal(this.id, price);
    }

    const ema50 = last(emaSeries(closes, num(config.params, "emaFastPeriod", 50)));
    const ema200 = last(emaSeries(closes, num(config.params, "emaTrendPeriod", 200)));
    const adx = last(adxSeries(candles, num(config.params, "adxPeriod", 14)));

    if (ema50 === null || ema200 === null || adx === null) {
      return insufficientSignal(this.id, price);
    }

    const adxMin = num(config.params, "adxMin", 25);
    const pullbackPct = num(config.params, "pullbackTolerancePct", 0.1);

    const lastCandle = candles.at(-1);
    const candleUp = lastCandle ? lastCandle.close > lastCandle.open : false;
    const candleDown = lastCandle ? lastCandle.close < lastCandle.open : false;

    // "Recuo até a região da EMA 50": preço dentro de pullbackPct% da EMA 50.
    const nearEma50Above =
      Math.abs(price - ema50) / ema50 <= pullbackPct / 100 && price >= ema50;
    const nearEma50Below =
      Math.abs(price - ema50) / ema50 <= pullbackPct / 100 && price <= ema50;

    const buyConditions: StrategyCondition[] = [
      { label: "EMA 50 acima da EMA 200", passed: ema50 > ema200 },
      { label: `ADX acima de ${adxMin}`, passed: adx > adxMin },
      { label: "Recuo até a região da EMA 50", passed: nearEma50Above },
      { label: "Candle confirma retomada da alta", passed: candleUp },
    ];

    const sellConditions: StrategyCondition[] = [
      { label: "EMA 50 abaixo da EMA 200", passed: ema50 < ema200 },
      { label: `ADX acima de ${adxMin}`, passed: adx > adxMin },
      { label: "Recuo até a região da EMA 50", passed: nearEma50Below },
      { label: "Candle confirma retomada da baixa", passed: candleDown },
    ];

    const indicators = { ema50, ema200, adx };

    if (buyConditions.every((c) => c.passed)) {
      return makeSignal(
        this.id,
        "BUY",
        price,
        buyConditions,
        indicators,
        `SINAL BUY — retomada de alta sobre a EMA 50 (ADX ${adx.toFixed(1)}).`,
      );
    }
    if (sellConditions.every((c) => c.passed)) {
      return makeSignal(
        this.id,
        "SELL",
        price,
        sellConditions,
        indicators,
        `SINAL SELL — retomada de baixa sob a EMA 50 (ADX ${adx.toFixed(1)}).`,
      );
    }

    const shown = ema50 > ema200 ? buyConditions : sellConditions;
    return makeSignal(
      this.id,
      "WAIT",
      price,
      shown,
      indicators,
      `AGUARDAR — sem tendência ou recuo válido (EMA50 ${ema50.toFixed(5)}, EMA200 ${ema200.toFixed(5)}, ADX ${adx.toFixed(1)}).`,
      null,
      "NO_SIGNAL",
    );
  }
}
