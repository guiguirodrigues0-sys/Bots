$content = Get-Content "backend/src/strategies/runtime.ts" -Raw
$content = $content -replace 'this\.pendingReservations\.set\(trade\.contractId, \{', 'this.pendingReservations.set(contractId, {'
Set-Content "backend/src/strategies/runtime.ts" -Value $content