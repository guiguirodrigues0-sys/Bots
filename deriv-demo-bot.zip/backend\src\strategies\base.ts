import type { Candle } from "../types.js";
import {
  isValidGranularity,
  ALLOWED_GRANULARITIES,
} from "../services/marketDataService.js";
import type {
  Strategy,
  StrategyConfig,
  StrategyDirection,
  StrategyId,
  StrategySignal,
  StrategyStatus,
  StrategyReasonCode,
  MarketRegime,
} from "./types.js";

const VALID_DURATION_UNITS = new Set(["s", "m", "h", "t"]);

export function makeSignal(
  strategyId: StrategyId,
  direction: StrategyDirection,
  price: number | null,
  conditions: StrategySignal["conditions"],
  indicators: StrategySignal["indicators"],
  reason: string,
  regime: MarketRegime | null = null,
  reasonCode: StrategyReasonCode | null = null,
): StrategySignal {
  return {
    strategyId,
    direction,
    reasonCode,
    reason,
    timestamp: Date.now(),
    price,
    conditions,
    indicators,
    regime,
  };
}

export function insufficientSignal(
  strategyId: StrategyId,
  price: number | null,
  reason = "AGUARDANDO — dados insuficientes para calcular os indicadores.",
  reasonCode: StrategyReasonCode = "INSUFFICIENT_CANDLES",
): StrategySignal {
  return makeSignal(strategyId, "WAIT", price, [], {}, reason, null, reasonCode);
}

export function confirmationsPassed(
  conditions: StrategySignal["conditions"],
): number {
  return conditions.filter((c) => c.passed).length;
}

export function validateCommonConfig(
  config: StrategyConfig,
): { ok: boolean; errors: string[] } {
  const errors: string[] = [];
  if (!config.symbol || typeof config.symbol !== "string") {
    errors.push("Ativo (symbol) inválido.");
  }
  if (!isValidGranularity(config.granularity)) {
    errors.push(
      `Timeframe inválido (${config.granularity}s). Valores permitidos (segundos): ${ALLOWED_GRANULARITIES.join(", ")}.`,
    );
  }
  if (!Number.isInteger(config.duration) || config.duration <= 0) {
    errors.push("Duração do contrato inválida.");
  }
  if (!VALID_DURATION_UNITS.has(config.durationUnit)) {
    errors.push("Unidade de duração inválida.");
  }
  if (config.stakeMode === "FIXED") {
    if (config.fixedStake === null || config.fixedStake <= 0) {
      errors.push("Stake fixa deve ser maior que zero.");
    }
  } else if (config.stakeMode === "PERCENT") {
    if (config.stakePercent === null || config.stakePercent <= 0) {
      errors.push("Stake percentual deve ser maior que zero.");
    }
  } else {
    errors.push("stakeMode deve ser PERCENT ou FIXED.");
  }
  if (config.maxTrades < 0) {
    errors.push("maxTrades não pode ser negativo.");
  }
  if (config.cooldownSeconds < 0) {
    errors.push("cooldownSeconds não pode ser negativo.");
  }
  return { ok: errors.length === 0, errors };
}

/**
 * Base padronizada de estratégia. Estratégias concretas apenas implementam
 * `evaluateSignal` (cálculo puro sobre candles fechados) e, quando necessário,
 * `validateConfig`. O buffer de candles é mantido pelo StrategyManager/Runtime;
 * `onCandle` apenas contabiliza estado.
 */
export abstract class BaseStrategy implements Strategy {
  abstract readonly id: StrategyId;

  protected status: StrategyStatus = this.freshStatus();

  initialize(): void {
    this.reset();
  }

  onCandle(_candle: Candle): void {
    this.status.candleCount += 1;
  }

  abstract evaluateSignal(
    candles: Candle[],
    config: StrategyConfig,
  ): StrategySignal;

  validateConfig(config: StrategyConfig): { ok: boolean; errors: string[] } {
    return validateCommonConfig(config);
  }

  getStatus(): StrategyStatus {
    return { ...this.status };
  }

  reset(): void {
    this.status = this.freshStatus();
  }

  dispose(): void {
    this.reset();
  }

  private freshStatus(): StrategyStatus {
    return {
      active: false,
      candleCount: 0,
      lastDirection: "WAIT",
      lastSignalAt: null,
      reason: null,
      error: null,
    };
  }
}
