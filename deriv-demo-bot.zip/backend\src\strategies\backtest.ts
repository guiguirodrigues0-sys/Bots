import type { Candle } from "../types.js";
import type {
  StrategyConfig,
  StrategyId,
  StrategySignal,
} from "./types.js";
import { createStrategy } from "./registry.js";
import { durationToSeconds } from "../deriv/symbols.js";

export interface BacktestMetrics {
  trades: number;
  wins: number;
  losses: number;
  winRate: number;
  grossProfit: number;
  grossLoss: number;
  netPnl: number;
  profitFactor: number;
  maxDrawdown: number;
  maxDrawdownPct: number;
  expectancy: number;
  maxConsecutiveLosses: number;
  /** Intervalo de confiança de 95% (Wilson) da taxa de acerto, em %. */
  winRateCI: { low: number; high: number } | null;
}

export interface BacktestSegment {
  label: "DESENVOLVIMENTO" | "VALIDACAO" | "TESTE";
  candles: number;
  signals: { buy: number; sell: number; wait: number };
  metrics: BacktestMetrics;
  isEstimate: boolean;
}

export interface BacktestResult {
  strategyId: StrategyId;
  symbol: string;
  granularity: number;
  duration: number;
  durationUnit: StrategyConfig["durationUnit"];
  payout: number;
  avgPayout: number;
  /** Taxa mínima de acerto para o ponto de equilíbrio (%), dado o payout. */
  breakEvenWinRate: number;
  isEstimate: boolean;
  totalCandles: number;
  segments: BacktestSegment[];
  aggregate: BacktestMetrics;
  note: string;
}

export interface BacktestOptions {
  payout?: number;
  /** Divisão fora da amostra em [desenvolvimento, validação, teste]. */
  split?: [number, number, number];
}

const ESTIMATE_NOTE =
  "Resultado FINANCEIRO estimado: sem cotações tick-a-tick suficientes para reconstruir a liquidação exata do contrato Deriv, a liquidação é aproximada pelo fechamento do candle correspondente à duração (Rise: fechamento estritamente acima; Fall: estritamente abaixo). Não é um backtest financeiro fiel.";

function emptyMetrics(): BacktestMetrics {
  return {
    trades: 0,
    wins: 0,
    losses: 0,
    winRate: 0,
    grossProfit: 0,
    grossLoss: 0,
    netPnl: 0,
    profitFactor: 0,
    maxDrawdown: 0,
    maxDrawdownPct: 0,
    expectancy: 0,
    maxConsecutiveLosses: 0,
    winRateCI: null,
  };
}

/**
 * Intervalo de confiança de 95% (intervalo de Wilson) para a taxa de acerto,
 * em percentual. Retorna null quando não há operações.
 */
export function winRateConfidenceInterval(
  wins: number,
  trades: number,
): { low: number; high: number } | null {
  if (trades <= 0) {
    return null;
  }
  const z = 1.959964;
  const n = trades;
  const p = wins / n;
  const denom = 1 + (z * z) / n;
  const center = (p + (z * z) / (2 * n)) / denom;
  const half = (z * Math.sqrt((p * (1 - p)) / n + (z * z) / (4 * n * n))) / denom;
  return {
    low: Math.max(0, center - half) * 100,
    high: Math.min(1, center + half) * 100,
  };
}

function settleOffset(duration: number, unit: StrategyConfig["durationUnit"], granularity: number): number {
  if (unit === "t") {
    return 1;
  }
  const seconds = durationToSeconds(`${duration}${unit}`);
  if (!Number.isFinite(seconds)) {
    return 1;
  }
  return Math.max(1, Math.ceil(seconds / granularity));
}

interface SegmentEvaluation {
  signals: { buy: number; sell: number; wait: number };
  metrics: BacktestMetrics;
  isEstimate: boolean;
}

function evaluateSegment(
  strategyId: StrategyId,
  candles: Candle[],
  config: StrategyConfig,
  payout: number,
): SegmentEvaluation {
  const strategy = createStrategy(strategyId);
  strategy.initialize();
  const offset = settleOffset(config.duration, config.durationUnit, config.granularity);

  const signals = { buy: 0, sell: 0, wait: 0 };
  const metrics = emptyMetrics();
  let equity = 0;
  let peak = 0;
  let consecutiveLosses = 0;

  const generated: Array<{ signal: StrategySignal; index: number; price: number }> = [];

  // Geração de sinais SEM look-ahead: no candle i usa apenas candles[0..i].
  for (let i = 0; i < candles.length; i++) {
    const candle = candles[i];
    if (!candle) {
      continue;
    }
    strategy.onCandle(candle);
    const signal = strategy.evaluateSignal(candles.slice(0, i + 1), config);
    if (signal.direction === "BUY") {
      signals.buy += 1;
    } else if (signal.direction === "SELL") {
      signals.sell += 1;
    } else {
      signals.wait += 1;
    }
    if (signal.direction !== "WAIT" && signal.price !== null) {
      generated.push({ signal, index: i, price: signal.price });
    }
  }

  strategy.dispose();

  for (const entry of generated) {
    const settleIndex = entry.index + offset;
    const settleCandle = candles[settleIndex];
    if (!settleCandle) {
      // Sem cotações suficientes para reconstruir o contrato: não contabiliza
      // como operação concluída (resultado ficaria como estimativa incompleta).
      continue;
    }
    const entryPrice = entry.price;
    const exitPrice = settleCandle.close;

    let win = false;
    if (entry.signal.direction === "BUY") {
      win = exitPrice > entryPrice;
    } else {
      win = exitPrice < entryPrice;
    }

    // Modelo de contrato Rise/Fall: lucro = stake * (payout - 1), perda = -stake.
    const stake = 1;
    const pl = win ? stake * (payout - 1) : -stake;

    metrics.trades += 1;
    if (win) {
      metrics.wins += 1;
      metrics.grossProfit += pl;
      consecutiveLosses = 0;
    } else {
      metrics.losses += 1;
      metrics.grossLoss += Math.abs(pl);
      consecutiveLosses += 1;
      if (consecutiveLosses > metrics.maxConsecutiveLosses) {
        metrics.maxConsecutiveLosses = consecutiveLosses;
      }
    }

    equity += pl;
    if (equity > peak) {
      peak = equity;
    }
    const drawdown = peak - equity;
    if (drawdown > metrics.maxDrawdown) {
      metrics.maxDrawdown = drawdown;
    }
  }

  metrics.netPnl = equity;
  metrics.winRate = metrics.trades > 0 ? (metrics.wins / metrics.trades) * 100 : 0;
  metrics.winRateCI = winRateConfidenceInterval(metrics.wins, metrics.trades);
  metrics.profitFactor =
    metrics.grossLoss > 0 ? metrics.grossProfit / metrics.grossLoss : metrics.grossProfit > 0 ? Number.POSITIVE_INFINITY : 0;
  metrics.maxDrawdownPct = peak > 0 ? (metrics.maxDrawdown / peak) * 100 : 0;
  metrics.expectancy = metrics.trades > 0 ? metrics.netPnl / metrics.trades : 0;

  return { signals, metrics, isEstimate: metrics.trades > 0 };
}

export function runBacktest(
  strategyId: StrategyId,
  candles: Candle[],
  config: StrategyConfig,
  opts: BacktestOptions = {},
): BacktestResult {
  const payout = opts.payout ?? 1.9;
  const split = opts.split ?? [0.6, 0.2, 0.2];

  const total = candles.length;
  const devEnd = Math.floor(total * split[0]);
  const valEnd = Math.floor(total * (split[0] + split[1]));

  const labels: BacktestSegment["label"][] = ["DESENVOLVIMENTO", "VALIDACAO", "TESTE"];
  const slices: Candle[][] = [
    candles.slice(0, devEnd),
    candles.slice(devEnd, valEnd),
    candles.slice(valEnd),
  ];

  const segments: BacktestSegment[] = labels.map((label, i) => {
    const slice = slices[i] ?? [];
    const result = evaluateSegment(strategyId, slice, config, payout);
    return {
      label,
      candles: slice.length,
      signals: result.signals,
      metrics: result.metrics,
      isEstimate: result.isEstimate,
    };
  });

  // Agregado: métricas combinadas de todas as fatias.
  const aggregate = emptyMetrics();
  let peak = 0;
  let equity = 0;
  for (const m of segments) {
    aggregate.trades += m.metrics.trades;
    aggregate.wins += m.metrics.wins;
    aggregate.losses += m.metrics.losses;
    aggregate.grossProfit += m.metrics.grossProfit;
    aggregate.grossLoss += m.metrics.grossLoss;
    aggregate.maxConsecutiveLosses = Math.max(
      aggregate.maxConsecutiveLosses,
      m.metrics.maxConsecutiveLosses,
    );
    // Drawdown agregado aproximado (sequência dos segmentos, expectância média).
    const perTrade = m.metrics.trades > 0 ? m.metrics.netPnl / m.metrics.trades : 0;
    for (let k = 0; k < m.metrics.trades; k++) {
      equity += perTrade;
      if (equity > peak) {
        peak = equity;
      }
      if (peak - equity > aggregate.maxDrawdown) {
        aggregate.maxDrawdown = peak - equity;
      }
    }
  }
  aggregate.netPnl = aggregate.grossProfit - aggregate.grossLoss;
  aggregate.winRate = aggregate.trades > 0 ? (aggregate.wins / aggregate.trades) * 100 : 0;
  aggregate.winRateCI = winRateConfidenceInterval(aggregate.wins, aggregate.trades);
  aggregate.profitFactor =
    aggregate.grossLoss > 0 ? aggregate.grossProfit / aggregate.grossLoss : aggregate.grossProfit > 0 ? Number.POSITIVE_INFINITY : 0;
  aggregate.maxDrawdownPct = peak > 0 ? (aggregate.maxDrawdown / peak) * 100 : 0;
  aggregate.expectancy = aggregate.trades > 0 ? aggregate.netPnl / aggregate.trades : 0;

  return {
    strategyId,
    symbol: config.symbol,
    granularity: config.granularity,
    duration: config.duration,
    durationUnit: config.durationUnit,
    payout,
    avgPayout: payout,
    breakEvenWinRate: payout > 0 ? (1 / payout) * 100 : 0,
    isEstimate: segments.some((s) => s.isEstimate),
    totalCandles: total,
    segments,
    aggregate,
    note: ESTIMATE_NOTE,
  };
}

export function roundMetrics(m: BacktestMetrics): BacktestMetrics {
  const r = (n: number): number =>
    Number.isFinite(n) ? Math.round(n * 100) / 100 : n;
  return {
    trades: m.trades,
    wins: m.wins,
    losses: m.losses,
    winRate: r(m.winRate),
    grossProfit: r(m.grossProfit),
    grossLoss: r(m.grossLoss),
    netPnl: r(m.netPnl),
    profitFactor: r(m.profitFactor),
    maxDrawdown: r(m.maxDrawdown),
    maxDrawdownPct: r(m.maxDrawdownPct),
    expectancy: r(m.expectancy),
    maxConsecutiveLosses: m.maxConsecutiveLosses,
    winRateCI: m.winRateCI
      ? { low: r(m.winRateCI.low), high: r(m.winRateCI.high) }
      : null,
  };
}
