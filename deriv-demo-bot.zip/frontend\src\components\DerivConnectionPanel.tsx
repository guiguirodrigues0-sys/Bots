import { useState } from "react";
import type { PublicSession, OpenTrade } from "../api/client";

interface Props {
  session: PublicSession | null;
  botRunning: boolean;
  openTrades: OpenTrade[];
  onConnect: (appId: string, token: string) => Promise<void>;
  onDisconnect: () => Promise<void>;
}

function fmtBalance(v: number | null | undefined, currency: string | null): string {
  if (v === null || v === undefined) return "—";
  const sym = currency === "USD" ? "$" : currency ? `${currency} ` : "";
  return `${sym}${v.toLocaleString("pt-BR", { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`;
}

function fmtTime(epochMs: number): string {
  return new Date(epochMs).toLocaleTimeString("pt-BR");
}

function fmtRemaining(entryTime: number, durationSeconds: number): string {
  const ms = entryTime + durationSeconds * 1000 - Date.now();
  if (ms <= 0) return "00:00";
  const s = Math.max(0, Math.round(ms / 1000));
  const m = Math.floor(s / 60);
  const ss = s % 60;
  return `${String(m).padStart(2, "0")}:${String(ss).padStart(2, "0")}`;
}

export default function DerivConnectionPanel({
  session,
  botRunning,
  openTrades,
  onConnect,
  onDisconnect,
}: Props) {
  const [appId, setAppId] = useState("");
  const [token, setToken] = useState("");
  const [showToken, setShowToken] = useState(false);
  const [showSettings, setShowSettings] = useState(false);
  const [connecting, setConnecting] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const connected = session?.connected === true;
  const connectingState = session?.status === "CONNECTING" || connecting;
  const hasOpenTrade = openTrades.some((t) => t.status === "OPEN");

  const handleConnect = async () => {
    setError(null);
    setConnecting(true);
    try {
      await onConnect(appId, token);
      setToken("");
      setShowToken(false);
    } catch (e) {
      setError(e instanceof Error ? e.message : String(e));
    } finally {
      setConnecting(false);
    }
  };

  const handleDisconnect = async () => {
    setError(null);
    try {
      await onDisconnect();
      setShowSettings(false);
    } catch (e) {
      setError(e instanceof Error ? e.message : String(e));
    }
  };

  if (connected && session) {
    return (
      <section className="panel">
        <div className="conn-compact">
          <div className="conn-compact-info">
            <span className="status-dot" />
            <span>
              <strong>DERIV</strong> · Conectado ·{" "}
              {session.accountType === "demo" ? "DEMO" : session.accountType ?? "—"}
              {session.currency ? ` · ${session.currency}` : ""} ·{" "}
              <span className="muted">{fmtBalance(session.virtualBalance, session.currency)}</span>
            </span>
          </div>
          <button
            className="btn"
            onClick={() => setShowSettings((s) => !s)}
          >
            {showSettings ? "Fechar" : "Configurações"}
          </button>
        </div>

        {hasOpenTrade && (
          <div className="error-box">
            <p className="conn-warning">
              Existe {openTrades.filter((t) => t.status === "OPEN").length} operação(ões) DEMO em andamento. Aguarde a finalização antes de desconectar.
            </p>
            {openTrades.filter((t) => t.status === "OPEN").map((t) => (
              <dl className="op-grid" key={t.contractId}>
                <dt>Ativo</dt>
                <dd>VOLATILITY 100</dd>
                <dt>Direção</dt>
                <dd>{t.direction}</dd>
                <dt>Valor virtual</dt>
                <dd>{fmtBalance(t.stake, session.currency)}</dd>
                <dt>Entrada</dt>
                <dd>{fmtTime(t.entryTime)}</dd>
                <dt>Restante</dt>
                <dd>{fmtRemaining(t.entryTime, t.durationSeconds)}</dd>
              </dl>
            ))}
          </div>
        )}

        {showSettings && (
          <div className="conn-form">
            <div className="conn-field">
              <span className="field-label">App ID</span>
              <span>{session.appId ?? "—"}</span>
            </div>
            <div className="conn-field">
              <span className="field-label">Token</span>
              <span>{session.tokenMasked ?? "—"}</span>
            </div>
            <div className="conn-actions">
              <button
                className="btn btn-danger"
                onClick={handleDisconnect}
                disabled={connectingState || hasOpenTrade}
              >
                Desconectar
              </button>
              {hasOpenTrade && (
                <span className="muted">Desconexão bloqueada enquanto houver operação.</span>
              )}
            </div>
          </div>
        )}
      </section>
    );
  }

  return (
    <section className="panel">
      <div className="panel-head">
        <h2>Conexão Deriv</h2>
      </div>
      <div className="conn-form">
        <div className="conn-field">
          <label htmlFor="app-id">App ID</label>
          <input
            id="app-id"
            type="text"
            value={appId}
            disabled={connectingState || botRunning}
            onChange={(e) => setAppId(e.target.value)}
            placeholder="App ID"
            autoComplete="off"
          />
        </div>
        <div className="conn-field">
          <label htmlFor="api-token">Token</label>
          <input
            id="api-token"
            type={showToken ? "text" : "password"}
            value={token}
            disabled={connectingState || botRunning}
            onChange={(e) => setToken(e.target.value)}
            placeholder="Token"
            autoComplete="off"
          />
        </div>
        <div className="conn-actions">
          <button
            className="btn btn-primary"
            onClick={handleConnect}
            disabled={connectingState || botRunning || !appId.trim() || !token.trim()}
          >
            {connectingState ? "Conectando…" : "Testar e conectar"}
          </button>
          <button type="button" className="link-btn" onClick={() => setShowToken((s) => !s)}>
            {showToken ? "Ocultar token" : "Mostrar token"}
          </button>
        </div>
      </div>
      {botRunning && (
        <p className="notice">Pare o bot antes de trocar as credenciais.</p>
      )}
      <p className="notice">
        Este protótipo aceita exclusivamente contas DEMO e utiliza dinheiro virtual.
      </p>
      {error && <div className="error-box"><p>{error}</p></div>}
    </section>
  );
}
