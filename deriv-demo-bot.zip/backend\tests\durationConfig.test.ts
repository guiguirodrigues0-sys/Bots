import { test } from "node:test";
import assert from "node:assert/strict";
import { STRATEGY_IDS, defaultConfig } from "../src/strategies/definitions.js";
import { StrategyManager } from "../src/strategies/manager.js";
import { TradeExecutor } from "../src/services/tradeExecutor.js";
import type { WebSocketManager } from "../src/deriv/wsManager.js";

process.env.LOG_LEVEL = "error";

test("as 8 estratégias possuem duração e timeframe válidos e distintos", () => {
  assert.equal(STRATEGY_IDS.length, 8);
  for (const id of STRATEGY_IDS) {
    const cfg = defaultConfig(id);
    assert.ok(cfg.duration > 0, `${id}: duração deve ser positiva`);
    assert.ok(
      ["s", "m", "h", "t"].includes(cfg.durationUnit),
      `${id}: unidade de duração inválida (${cfg.durationUnit})`,
    );
    assert.ok(cfg.granularity > 0, `${id}: timeframe (granularity) deve ser positivo`);
    // Timeframe de análise (candles) é distinto da duração do contrato.
    assert.notEqual(
      cfg.granularity,
      cfg.duration,
      `${id}: granularity não deve ser confundida com a duração do contrato`,
    );
    assert.equal(cfg.contractType, "callput");
  }
});

test("cada estratégia salva sua própria duração, independentemente das demais", () => {
  const m = new StrategyManager();
  m.setConfig("SCALPING", { duration: 5, durationUnit: "m" });
  m.setConfig("MACD_ADX", { duration: 2, durationUnit: "m" });
  m.setConfig("PRECISAO_EXTREMA", { duration: 30, durationUnit: "s" });

  assert.equal(m.getConfig("SCALPING").duration, 5);
  assert.equal(m.getConfig("SCALPING").durationUnit, "m");
  assert.equal(m.getConfig("MACD_ADX").duration, 2);
  assert.equal(m.getConfig("PRECISAO_EXTREMA").duration, 30);
  assert.equal(m.getConfig("PRECISAO_EXTREMA").durationUnit, "s");
  // As demais permanecem com o padrão.
  assert.equal(m.getConfig("TENDENCIA").duration, defaultConfig("TENDENCIA").duration);
  assert.equal(m.getConfig("CONFLUENCIA").duration, defaultConfig("CONFLUENCIA").duration);
});

test("executor envia duration e duration_unit configurados à API (todas as unidades)", async () => {
  const cases: Array<{ duration: number; unit: "s" | "m" }> = [
    { duration: 30, unit: "s" },
    { duration: 5, unit: "m" },
    { duration: 15, unit: "m" },
  ];
  for (const { duration, unit } of cases) {
    const calls: Array<Record<string, unknown>> = [];
    const ws = {
      request: async (p: Record<string, unknown>) => {
        calls.push(p);
        if (p.buy !== undefined) {
          return { buy: { contract_id: 1, buy_price: 1 } };
        }
        return {};
      },
    } as unknown as WebSocketManager;

    const executor = new TradeExecutor();
    await executor.execute(ws, "R_100", "CALL", 10, duration, unit, "USD", {
      skipAvailabilityCheck: true,
    });

    const buy = calls.find((c) => c.buy !== undefined) as
      | { parameters?: Record<string, unknown> }
      | undefined;
    assert.ok(buy, `buy não enviado para ${duration}${unit}`);
    assert.equal(buy?.parameters?.duration, duration, `duration divergiu para ${duration}${unit}`);
    assert.equal(buy?.parameters?.duration_unit, unit, `duration_unit divergiu para ${duration}${unit}`);
  }
});
