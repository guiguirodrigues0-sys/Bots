# Deriv Demo Bot

Bot de trading totalmente automatizado para a **Deriv**, operando **exclusivamente em conta DEMO (dinheiro virtual)**.

> **AVISO:** este projeto é um **protótipo educacional e experimental**.
> Não promete rentabilidade, assertividade ou lucro. Não suporta dinheiro real.

## Stack

- **Frontend:** React + TypeScript (Vite)
- **Backend:** Node.js + TypeScript (Express + `ws`)
- **Banco:** SQLite (módulo nativo `node:sqlite`)
- **Estrutura:** monorepo com npm workspaces (`shared`, `backend`, `frontend`)

## Estrutura de módulos (backend)

| Diretório | Responsabilidade |
|-----------|------------------|
| `src/config` | Configuração / leitura de `.env` |
| `src/logger` | Logs estruturados (com mascaramento de token) |
| `src/deriv` | Deriv API client + WebSocket manager |
| `src/services` | Indicadores, estratégia, risk manager, executor, monitor |
| `src/storage` | SQLite (operações, resultados, configs, sessões, stats, logs) |
| `src/http` | Servidor HTTP/WS para o frontend |

## Como rodar (local, VS Code)

```bash
npm install
npm run dev:backend   # terminal 1
npm run dev:frontend  # terminal 2
```

## Segurança

- Funciona **somente** em conta DEMO. Conta REAL é bloqueada automaticamente.
- Credenciais ficam em `.env` (nunca no código).
- Token/PAT nunca é armazenado em texto puro no SQLite nem impresso nos logs.

Consulte a documentação oficial em https://developers.deriv.com/
