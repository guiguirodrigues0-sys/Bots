import path from "node:path";
import fs from "node:fs";
import { config as loadDotenv } from "dotenv";
import { z } from "zod";

function findDotEnv(): string | undefined {
  let dir = process.cwd();
  for (let i = 0; i < 6; i++) {
    const candidate = path.join(dir, ".env");
    if (fs.existsSync(candidate)) {
      return candidate;
    }
    const parent = path.dirname(dir);
    if (parent === dir) {
      break;
    }
    dir = parent;
  }
  return undefined;
}

const envFile = findDotEnv();
if (envFile) {
  loadDotenv({ path: envFile });
}

const EnvSchema = z.object({
  DERIV_APP_ID: z.string().default(""),
  DERIV_API_TOKEN: z.string().default(""),
  DERIV_ENVIRONMENT: z.literal("demo", {
    errorMap: () => ({ message: "DERIV_ENVIRONMENT deve ser 'demo'" }),
  }),
  DERIV_SYMBOL: z.string().default("frxEURUSD"),
  TRADE_DURATION: z.coerce.number().int().positive().default(15),
  TRADE_DURATION_UNIT: z.enum(["m", "h", "d", "s"]).default("m"),
  RAPID_SYMBOL: z.string().default("R_100"),
  RAPID_DURATION: z.coerce.number().int().positive().default(30),
  RAPID_DURATION_UNIT: z.enum(["s", "t"]).default("s"),
  INITIAL_THRESHOLD: z.coerce.number().int().min(0).max(100).default(80),
  ACTIVE_THRESHOLD: z.coerce.number().int().min(0).max(100).default(60),
  MIN_ENTRY_INTERVAL_SECONDS: z.coerce.number().positive().default(10),
  MAX_OPEN_TRADES: z.coerce.number().int().positive().default(3),
  MAX_TOTAL_EXPOSURE_PERCENT: z.coerce.number().positive().default(1.5),
  ACTIVE_RISK_PERCENT: z.coerce.number().positive().default(0.25),
  INITIAL_RISK_PERCENT: z.coerce.number().positive().default(0.5),
  BOT_MAX_CONSECUTIVE_LOSSES: z.coerce.number().int().positive().default(3),
  BOT_DAILY_STOP_PERCENT: z.coerce.number().positive().default(5),
  BOT_DAILY_TARGET_PERCENT: z.coerce.number().positive().default(5),
  PORT: z.coerce.number().int().positive().default(3001),
  HOST: z.string().default("127.0.0.1"),
  LOG_LEVEL: z.enum(["debug", "info", "warn", "error"]).default("debug"),
  DB_PATH: z.string().default("./data/deriv-demo-bot.db"),
  ALLOW_REAL_ACCOUNT: z
    .enum(["true", "false"])
    .default("false")
    .transform((v) => v === "true"),
});

export type Env = z.infer<typeof EnvSchema>;

let cached: Env | null = null;

export function loadEnv(): Env {
  const parsed = EnvSchema.safeParse(process.env);
  if (!parsed.success) {
    const issues = parsed.error.issues
      .map((i) => `${i.path.join(".")}: ${i.message}`)
      .join("\n");
    throw new Error(`Configuracao de ambiente invalida:\n${issues}`);
  }
  if (parsed.data.ALLOW_REAL_ACCOUNT) {
    throw new Error(
      "CONFIGURACAO INVALIDA: ALLOW_REAL_ACCOUNT deve permanecer 'false'. Este prototipo funciona somente em conta DEMO.",
    );
  }
  cached = parsed.data;
  return cached;
}

export function getEnv(): Env {
  if (!cached) {
    return loadEnv();
  }
  return cached;
}
