import { test } from "node:test";
import assert from "node:assert/strict";
import { Bot } from "../src/bot/bot.js";
import { AuthExpiredError } from "../src/deriv/apiClient.js";

process.env.LOG_LEVEL = "error";
process.env.DERIV_ENVIRONMENT = "demo";
process.env.ALLOW_REAL_ACCOUNT = "false";

interface Placed {
  direction: string;
}

function makeBot() {
  const bot = new Bot();
  const b = bot as unknown as Record<string, any>;
  b.state = "RUNNING";
  b.balance = 10000;
  b.currency = "USD";
  b.ws = { request: async () => ({}) };
  const placed: Placed[] = [];
  b.executor = {
    execute: async (
      _ws: unknown,
      _symbol: string,
      direction: string,
      _stake: number,
      _duration: number,
      _unit: string,
    ) => {
      const contractId = String(placed.length + 1);
      placed.push({ direction });
      return {
        contractId,
        proposalId: `prop-${contractId}`,
        direction,
        stake: 50,
        buyPrice: 1,
        askPrice: 1,
        payout: 1.9,
        balanceAfter: 9950,
      };
    },
  };
  b.latestSignal = { direction: "WAIT", score: 0 };
  return { bot, b, placed };
}

test("WAIT nunca gera operação", async () => {
  const { b, placed } = makeBot();
  b.latestSignal = { direction: "WAIT", score: 0 };
  await b.evaluateAndMaybeTrade();
  assert.deepEqual(placed, []);
});

test("WAITING_SETUP + score >= INITIAL_THRESHOLD gera CALL INITIAL e vira ACTIVE_MODE", async () => {
  const { b, placed } = makeBot();
  b.phase = "WAITING_SETUP";
  b.latestSignal = { direction: "CALL", score: 80 };
  await b.evaluateAndMaybeTrade();
  assert.equal(placed.length, 1);
  assert.equal(placed[0]?.direction, "CALL");
  assert.equal(b.phase, "ACTIVE_MODE");
  assert.equal(b.openTrades[0].entryType, "INITIAL");
});

test("BAIXA gera PUT", async () => {
  const { b, placed } = makeBot();
  b.phase = "WAITING_SETUP";
  b.latestSignal = { direction: "PUT", score: 100 };
  await b.evaluateAndMaybeTrade();
  assert.equal(placed[0]?.direction, "PUT");
});

test("WAITING_SETUP com score abaixo do INITIAL_THRESHOLD não opera", async () => {
  const { b, placed } = makeBot();
  b.phase = "WAITING_SETUP";
  b.latestSignal = { direction: "CALL", score: 60 };
  await b.evaluateAndMaybeTrade();
  assert.deepEqual(placed, []);
  assert.equal(b.phase, "WAITING_SETUP");
});

test("ACTIVE_MODE com score >= ACTIVE_THRESHOLD opera como ACTIVE", async () => {
  const { b, placed } = makeBot();
  b.phase = "ACTIVE_MODE";
  b.latestSignal = { direction: "CALL", score: 60 };
  await b.evaluateAndMaybeTrade();
  assert.equal(placed.length, 1);
  assert.equal(b.openTrades[0].entryType, "ACTIVE");
  assert.equal(b.phase, "ACTIVE_MODE");
});

test("ACTIVE_MODE com score abaixo do ACTIVE_THRESHOLD aguarda", async () => {
  const { b, placed } = makeBot();
  b.phase = "ACTIVE_MODE";
  b.latestSignal = { direction: "CALL", score: 40 };
  await b.evaluateAndMaybeTrade();
  assert.deepEqual(placed, []);
});

test("cooldown impede nova entrada em intervalo curto", async () => {
  const { b, placed } = makeBot();
  b.phase = "ACTIVE_MODE";
  b.latestSignal = { direction: "CALL", score: 80 };
  b.lastEntryTime = Date.now();
  await b.evaluateAndMaybeTrade();
  assert.deepEqual(placed, []);
});

test("máximo de posições simultâneas impede nova entrada", async () => {
  const { b, placed } = makeBot();
  b.phase = "ACTIVE_MODE";
  b.latestSignal = { direction: "CALL", score: 80 };
  for (let i = 0; i < 3; i++) {
    b.openTrades.push({
      contractId: `c${i}`,
      proposalId: `p${i}`,
      symbol: "R_100",
      direction: "CALL",
      stake: 25,
      entryTime: Date.now(),
      durationSeconds: 30,
      durationUnit: "s",
      askPrice: 1,
      payout: 1.9,
      entryType: "ACTIVE",
      status: "OPEN",
      profit: null,
      settlementTime: null,
    });
  }
  await b.evaluateAndMaybeTrade();
  assert.deepEqual(placed, []);
});

test("settlement simultâneo marca apenas o contrato correspondente", () => {
  const { b } = makeBot();
  for (let i = 1; i <= 3; i++) {
    b.openTrades.push({
      contractId: `c${i}`,
      proposalId: `p${i}`,
      symbol: "R_100",
      direction: "CALL",
      stake: 25,
      entryTime: Date.now(),
      durationSeconds: 30,
      durationUnit: "s",
      askPrice: 1,
      payout: 1.9,
      entryType: "ACTIVE",
      status: "OPEN",
      profit: null,
      settlementTime: null,
    });
  }
  b.handleSettled({ contractId: "c2", result: "WIN", profitLoss: 1.2, sellPrice: 2.2, status: "won" });
  assert.equal(b.openTrades.filter((t: any) => t.status === "OPEN").length, 2);
  assert.equal(b.openTrades.find((t: any) => t.contractId === "c2").status, "SETTLED");
  assert.equal(b.openTrades.find((t: any) => t.contractId === "c2").profit, 1.2);
});

test("saída do ACTIVE_MODE após ticks sem sinal suficiente", async () => {
  const { b } = makeBot();
  b.phase = "ACTIVE_MODE";
  b.latestSignal = { direction: "WAIT", score: 0 };
  for (let i = 0; i < 5; i++) {
    await b.evaluateAndMaybeTrade();
  }
  assert.equal(b.phase, "WAITING_SETUP");
});

test("settlement LOSS incrementa perdas consecutivas e atualiza stats por tipo", () => {
  const { b } = makeBot();
  b.openTrades.push({
    contractId: "c1",
    proposalId: "p1",
    symbol: "R_100",
    direction: "PUT",
    stake: 25,
    entryTime: Date.now(),
    durationSeconds: 30,
    durationUnit: "s",
    askPrice: 1,
    payout: 1.9,
    entryType: "ACTIVE",
    status: "OPEN",
    profit: null,
    settlementTime: null,
  });
  b.handleSettled({ contractId: "c1", result: "LOSS", profitLoss: -25, sellPrice: 0, status: "lost" });
  assert.equal(b.stats.active.losses, 1);
  assert.equal(b.stats.total.losses, 1);
  assert.equal(b.stats.consecutiveLosses, 1);
  assert.equal(b.stats.active.pnl, -25);
});

test("INITIAL e ACTIVE são contabilizados em buckets separados", () => {
  const { b } = makeBot();
  b.openTrades.push(
    {
      contractId: "i1",
      proposalId: "pi1",
      symbol: "R_100",
      direction: "CALL",
      stake: 50,
      entryTime: Date.now(),
      durationSeconds: 30,
      durationUnit: "s",
      askPrice: 1,
      payout: 1.9,
      entryType: "INITIAL",
      status: "OPEN",
      profit: null,
      settlementTime: null,
    },
    {
      contractId: "a1",
      proposalId: "pa1",
      symbol: "R_100",
      direction: "PUT",
      stake: 25,
      entryTime: Date.now(),
      durationSeconds: 30,
      durationUnit: "s",
      askPrice: 1,
      payout: 1.9,
      entryType: "ACTIVE",
      status: "OPEN",
      profit: null,
      settlementTime: null,
    },
  );
  b.handleSettled({ contractId: "i1", result: "WIN", profitLoss: 45, sellPrice: 3, status: "won" });
  b.handleSettled({ contractId: "a1", result: "LOSS", profitLoss: -25, sellPrice: 0, status: "lost" });
  assert.equal(b.stats.initial.trades, 1);
  assert.equal(b.stats.initial.wins, 1);
  assert.equal(b.stats.active.trades, 1);
  assert.equal(b.stats.active.losses, 1);
  assert.equal(b.stats.total.trades, 2);
});

test("5/5 (score 100) gera INITIAL e libera a entrada", async () => {
  const { b, placed } = makeBot();
  b.phase = "WAITING_SETUP";
  b.latestSignal = { direction: "CALL", score: 100, confirmations: 5, confirmationsTotal: 5 };
  await b.evaluateAndMaybeTrade();
  assert.equal(placed.length, 1);
  assert.equal(placed[0]?.direction, "CALL");
  assert.equal(b.openTrades[0].entryType, "INITIAL");
  assert.equal(b.phase, "ACTIVE_MODE");
  assert.equal(b.decisionBlockReason, null);
});

test("cooldown bloqueia e registra o motivo", async () => {
  const { b, placed } = makeBot();
  b.phase = "ACTIVE_MODE";
  b.latestSignal = { direction: "CALL", score: 100 };
  b.lastEntryTime = Date.now();
  await b.evaluateAndMaybeTrade();
  assert.deepEqual(placed, []);
  assert.ok(b.decisionBlockReason?.includes("Cooldown"));
});

test("auth expirado define CONEXÃO EXPIRADA", async () => {
  const { bot, b } = makeBot();
  b.state = "STOPPED";
  b.api = {
    getDemoWebSocketUrl: async () => {
      throw new AuthExpiredError();
    },
  };
  await bot.start("DEMO_TRADE");
  assert.equal(b.getSnapshot().state, "STOPPED");
  assert.equal(b.getSnapshot().lastEvent, "CONEXÃO EXPIRADA — RECONECTE SUA CONTA DEMO");
});

test("stake ACTIVE (0.25%) é normalizada para 2 casas antes do proposal", async () => {
  const { b, placed } = makeBot();
  b.balance = 9900.25;
  let sentStake: number | null = null;
  b.executor = {
    execute: async (_ws: unknown, _symbol: string, direction: string, stake: number) => {
      sentStake = stake;
      placed.push({ direction });
      return {
        contractId: "1",
        proposalId: "p1",
        direction,
        stake,
        buyPrice: 1,
        askPrice: 1,
        payout: 1.9,
        balanceAfter: 9900,
      };
    },
  };
  b.phase = "ACTIVE_MODE";
  b.latestSignal = { direction: "CALL", score: 100 };
  await b.evaluateAndMaybeTrade();
  assert.equal(sentStake, 24.75);
});

function openTrade(id: string, status = "OPEN", entryTime = Date.now()) {
  return {
    contractId: id,
    proposalId: `p${id}`,
    symbol: "R_100",
    direction: "CALL",
    stake: 25,
    entryTime,
    durationSeconds: 30,
    durationUnit: "s",
    askPrice: 1,
    payout: 1.9,
    entryType: "ACTIVE",
    status,
    profit: null,
    settlementTime: null,
  };
}

test("após reconectar, reassina apenas contratos OPEN", async () => {
  const { b } = makeBot();
  b.openTrades.push(openTrade("o1"), openTrade("s1", "SETTLED"));
  const requests: Record<string, any>[] = [];
  b.ws = { request: async (payload: Record<string, any>) => { requests.push(payload); return {}; } };
  await b.resubscribeOpenTrades(b.ws);
  assert.equal(requests.length, 1);
  assert.equal(requests[0].contract_id, "o1");
  assert.equal(requests[0].subscribe, 1);
});

test("falha ao assinar após compra mantém a operação OPEN para conferência", async () => {
  const { b } = makeBot();
  b.phase = "WAITING_SETUP";
  b.latestSignal = { direction: "CALL", score: 100 };
  b.ws = { request: async () => { throw new Error("timeout"); } };
  await b.evaluateAndMaybeTrade();
  assert.equal(b.openTrades.length, 1);
  assert.equal(b.openTrades[0].status, "OPEN");
  assert.notEqual(b.getSnapshot().lastEvent, "ERRO AO OPERAR");
});

test("conferência consulta apenas contratos vencidos e ainda abertos", async () => {
  const { b } = makeBot();
  const old = Date.now() - 60000;
  b.openTrades.push(openTrade("vencido", "OPEN", old), openTrade("recente", "OPEN"));
  const queried: string[] = [];
  b.ws = { isConnected: true, request: async (payload: Record<string, any>) => { queried.push(String(payload.contract_id)); return {}; } };
  await b.reconcileExpiredTrades();
  assert.deepEqual(queried, ["vencido"]);
});

test("stake INITIAL (0.5%) é normalizada para 2 casas antes do proposal", async () => {
  const { b, placed } = makeBot();
  b.balance = 9900.25;
  let sentStake: number | null = null;
  b.executor = {
    execute: async (_ws: unknown, _symbol: string, direction: string, stake: number) => {
      sentStake = stake;
      placed.push({ direction });
      return {
        contractId: "1",
        proposalId: "p1",
        direction,
        stake,
        buyPrice: 1,
        askPrice: 1,
        payout: 1.9,
        balanceAfter: 9900,
      };
    },
  };
  b.phase = "WAITING_SETUP";
  b.latestSignal = { direction: "CALL", score: 100 };
  await b.evaluateAndMaybeTrade();
  assert.equal(sentStake, 49.5);
});
