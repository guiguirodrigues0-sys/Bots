import { useState } from "react";
import {
  diagnoseAllStrategies,
  type StrategiesDiagnostic,
  type StrategyDiagnosticEntry,
  type StrategyRuntimeSnapshot,
  type StrategyStateResponse,
  type StrategyView,
} from "../../api/client";

interface Props {
  manager: StrategyStateResponse["manager"] | null;
  runtime: StrategyRuntimeSnapshot | null;
  strategies: StrategyView[];
  selectedSymbol: string;
  granularity: string;
}

const REASON_LABEL: Record<string, string> = {
  INSUFFICIENT_CANDLES: "Dados insuficientes",
  INVALID_INDICATOR: "Indicador inválido",
  NO_SIGNAL: "Sem sinal",
  WAITING_CANDLE_CLOSE: "Aguardando fechamento do candle",
  MARKET_CLOSED: "Mercado fechado",
  CONTRACT_UNAVAILABLE: "Contrato indisponível",
  INVALID_DURATION: "Duração inválida",
  INVALID_STAKE: "Stake inválida",
  RISK_BLOCKED: "Risco bloqueado",
  COOLDOWN_ACTIVE: "Cooldown ativo",
  POSITION_ALREADY_OPEN: "Posição já aberta",
  DERIV_API_ERROR: "Erro da API",
  CONNECTION_EXPIRED: "Conexão expirada",
  PROPOSAL_REJECTED: "Compra rejeitada",
};

const STATUS_LABEL: Record<string, string> = {
  OK: "OK",
  SEM_SINAL: "Sem sinais (legítimo)",
  DADOS_INSUFICIENTES: "Dados insuficientes",
  ERRO: "Falha técnica",
};

function fmtTime(ts: number | null | undefined): string {
  if (!ts) return "—";
  return new Date(ts).toLocaleTimeString("pt-BR");
}

function fmtNum(v: number | null | undefined): string {
  if (v === null || v === undefined) return "—";
  if (!Number.isFinite(v)) return "∞";
  return Number.isInteger(v) ? String(v) : v.toFixed(4);
}

function dirLabel(d: string | null | undefined): string {
  if (d === "BUY" || d === "CALL") return "ALTA";
  if (d === "SELL" || d === "PUT") return "BAIXA";
  return "AGUARDAR";
}

function dirClass(d: string | null | undefined): string {
  if (d === "BUY" || d === "CALL") return "signal-call";
  if (d === "SELL" || d === "PUT") return "signal-put";
  return "signal-aguardar";
}

export default function StrategyDiagnosticPanel({
  manager,
  runtime,
  strategies,
  selectedSymbol,
  granularity,
}: Props) {
  const [diag, setDiag] = useState<StrategiesDiagnostic | null>(null);
  const [count, setCount] = useState("600");
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const activeStrategy = strategies.find((s) => s.metadata.id === manager?.activeId);
  const lastSignal = runtime?.lastSignal ?? null;
  const indicators = lastSignal?.indicators ?? {};
  const conditions = lastSignal?.conditions ?? [];

  const runDiagnose = async () => {
    setBusy(true);
    setError(null);
    try {
      const r = await diagnoseAllStrategies({
        symbol: selectedSymbol,
        granularity: Number(granularity),
        count: Number(count) || 600,
      });
      setDiag(r);
    } catch (e) {
      setError(e instanceof Error ? e.message : String(e));
    } finally {
      setBusy(false);
    }
  };

  const topFailure = (r: StrategyDiagnosticEntry): string => {
    const entries = Object.entries(r.conditionFailures).sort((a, b) => b[1] - a[1]);
    const top = entries[0];
    if (!top) return "—";
    return `${top[0]} (${top[1]}×)`;
  };

  return (
    <section className="panel">
      <header className="panel-head">
        <h2>Diagnóstico das Estratégias</h2>
        <span className="muted">valores reais calculados pelo bot</span>
      </header>

      <div className="summary">
        <div className="stat">
          <div className="stat-label">Estratégia</div>
          <div className="stat-value" style={{ fontSize: 15 }}>
            {activeStrategy?.metadata.name ?? "Nenhuma"}
          </div>
        </div>
        <div className="stat">
          <div className="stat-label">Mercado</div>
          <div className="stat-value">{runtime?.symbol ?? "—"}</div>
        </div>
        <div className="stat">
          <div className="stat-label">Timeframe</div>
          <div className="stat-value">
            {runtime?.granularity ? `${runtime.granularity}s` : "—"}
          </div>
        </div>
        <div className="stat">
          <div className="stat-label">Candles carregados</div>
          <div className="stat-value">{manager?.candleCount ?? 0}</div>
        </div>
        <div className="stat">
          <div className="stat-label">Último candle</div>
          <div className="stat-value" style={{ fontSize: 13 }}>
            {fmtTime(
              manager?.lastCandleTime != null ? manager.lastCandleTime * 1000 : null,
            )}
          </div>
        </div>
      </div>

      {lastSignal && (
        <div className="diag-grid">
          <div>
            <h3 className="subhead">Indicadores atuais</h3>
            <table className="table">
              <tbody>
                {Object.entries(indicators).map(([k, v]) => (
                  <tr key={k}>
                    <td>{k}</td>
                    <td className="num">{fmtNum(v)}</td>
                  </tr>
                ))}
                {Object.keys(indicators).length === 0 && (
                  <tr className="empty">
                    <td colSpan={2}>Sem indicadores calculados ainda.</td>
                  </tr>
                )}
              </tbody>
            </table>
          </div>

          <div>
            <h3 className="subhead">Condições avaliadas</h3>
            <table className="table">
              <tbody>
                {conditions.map((c, i) => (
                  <tr key={i}>
                    <td>{c.label}</td>
                    <td className={c.passed ? "pos" : "neg"}>
                      {c.passed ? "SIM" : "NÃO"}
                    </td>
                  </tr>
                ))}
                {conditions.length === 0 && (
                  <tr className="empty">
                    <td colSpan={2}>Sem condições (aguardando dados).</td>
                  </tr>
                )}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {lastSignal && (
        <div className="diag-result">
          <span className={`signal-badge ${dirClass(lastSignal.direction)}`}>
            Resultado: {dirLabel(lastSignal.direction)}
          </span>
          {lastSignal.reasonCode && (
            <span className="muted">
              {" "}
              · Motivo: {REASON_LABEL[lastSignal.reasonCode] ?? lastSignal.reasonCode}
            </span>
          )}
          <p className="muted">{lastSignal.reason}</p>
        </div>
      )}

      <dl className="op-grid">
        <dt>Última avaliação</dt>
        <dd>{fmtTime(lastSignal?.timestamp)}</dd>
        <dt>Última compra</dt>
        <dd>
          {runtime?.lastProposal
            ? `${fmtTime(runtime.lastProposal.timestamp)} · ${dirLabel(
                runtime.lastProposal.direction,
              )} ${runtime.lastProposal.accepted ? "confirmada" : "rejeitada"}`
            : "—"}
        </dd>
        <dt>Último bloqueio</dt>
        <dd className={runtime?.decisionBlockReason ? "neg" : ""}>
          {runtime?.decisionBlockReason ?? "—"}
        </dd>
        <dt>Último erro da API</dt>
        <dd className={runtime?.lastError ? "neg" : ""}>{runtime?.lastError ?? "—"}</dd>
      </dl>

      <div className="diag-actions">
        <div className="conn-field">
          <label>Candles (período)</label>
          <input
            type="text"
            value={count}
            onChange={(e) => setCount(e.target.value)}
            style={{ width: 120 }}
          />
        </div>
        <button className="btn btn-primary" onClick={runDiagnose} disabled={busy}>
          Diagnosticar todas as estratégias
        </button>
      </div>

      {error && (
        <div className="error-box">
          <p>{error}</p>
        </div>
      )}

      {diag && (
        <div className="diag-all">
          <p className="muted">
            {diag.symbol} · {diag.granularity}s · {diag.totalCandles} candles · execução
            isolada (sem enviar ordens).
          </p>
          <table className="table">
            <thead>
              <tr>
                <th>Estratégia</th>
                <th>Avaliações</th>
                <th>BUY</th>
                <th>SELL</th>
                <th>Bloqueios</th>
                <th>Erros</th>
                <th>Maior bloqueio</th>
                <th>Status</th>
              </tr>
            </thead>
            <tbody>
              {diag.results.map((r) => (
                <tr key={r.strategyId}>
                  <td>{r.name}</td>
                  <td>{r.evaluations}</td>
                  <td className="pos">{r.buy}</td>
                  <td className="neg">{r.sell}</td>
                  <td>{r.insufficient}</td>
                  <td className={r.errors > 0 ? "neg" : ""}>{r.errors}</td>
                  <td className="muted">{topFailure(r)}</td>
                  <td>
                    <span
                      className={
                        r.status === "OK"
                          ? "pos"
                          : r.status === "ERRO"
                            ? "neg"
                            : "muted"
                      }
                    >
                      {STATUS_LABEL[r.status]}
                    </span>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
          <p className="notice muted">
            "Bloqueios" contam avaliações sem dados suficientes (histórico/indicador).
            Estratégias com zero sinais não são automaticamente defeituosas — o status
            distingue ausência legítima de oportunidades de falhas técnicas.
          </p>
        </div>
      )}
    </section>
  );
}
