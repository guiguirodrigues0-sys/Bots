import type {
  StrategyConfig,
  StrategyId,
  StrategyMetadata,
} from "./types.js";

export const STRATEGY_IDS: StrategyId[] = [
  "CONFLUENCIA",
  "SCALPING",
  "TENDENCIA",
  "REVERSAO_MEDIA",
  "ROMPIMENTO",
  "MACD_ADX",
  "ADAPTATIVA",
  "PRECISAO_EXTREMA",
];

export const STRATEGY_METADATA: Record<StrategyId, StrategyMetadata> = {
  CONFLUENCIA: {
    id: "CONFLUENCIA",
    name: "Confluência Inteligente",
    description:
      "Entradas seletivas com múltiplas confirmações (EMA 9/21/200, RSI 14, ADX 14). Prioriza qualidade sobre frequência.",
    indicators: ["EMA 9", "EMA 21", "EMA 200", "RSI 14", "ADX 14"],
    profile: "CONSERVADOR",
    frequency: "BAIXA",
    markets: ["EUR/USD", "GBP/USD", "R_100"],
    winRate: null,
    netResult: null,
  },
  SCALPING: {
    id: "SCALPING",
    name: "Scalping EMA + RSI",
    description:
      "Oportunidades de curto prazo via cruzamento EMA 5/13 com filtro de RSI 7. Maior frequência potencial de sinais.",
    indicators: ["EMA 5", "EMA 13", "RSI 7"],
    profile: "AGRESSIVO",
    frequency: "ALTA",
    markets: ["EUR/USD", "GBP/USD", "R_100"],
    winRate: null,
    netResult: null,
  },
  TENDENCIA: {
    id: "TENDENCIA",
    name: "Seguidor de Tendência",
    description:
      "Opera a favor de movimentos direcionais (EMA 50/200 + ADX 14) após recuo à EMA 50.",
    indicators: ["EMA 50", "EMA 200", "ADX 14"],
    profile: "MODERADO",
    frequency: "BAIXA",
    markets: ["EUR/USD", "GBP/USD", "R_100"],
    winRate: null,
    netResult: null,
  },
  REVERSAO_MEDIA: {
    id: "REVERSAO_MEDIA",
    name: "Reversão à Média",
    description:
      "Identifica preços excessivamente afastados da média (BB 20/2 + RSI 14) em baixa tendência (ADX < 20).",
    indicators: ["Bandas de Bollinger (20,2)", "RSI 14", "ADX 14"],
    profile: "MODERADO",
    frequency: "MEDIA",
    markets: ["EUR/USD", "GBP/USD", "R_100"],
    winRate: null,
    netResult: null,
  },
  ROMPIMENTO: {
    id: "ROMPIMENTO",
    name: "Rompimento de Volatilidade",
    description:
      "Detecta rompimentos de suporte/resistência (máx/mín 20 candles) validados por ATR 14.",
    indicators: ["Máx/Mín 20 candles", "ATR 14", "Volume (se disponível)"],
    profile: "AGRESSIVO",
    frequency: "BAIXA",
    markets: ["EUR/USD", "GBP/USD", "R_100"],
    winRate: null,
    netResult: null,
  },
  MACD_ADX: {
    id: "MACD_ADX",
    name: "MACD + ADX",
    description:
      "Momentum (MACD 12/26/9) confirmado por força (ADX 14) e tendência (EMA 50).",
    indicators: ["MACD 12/26/9", "ADX 14", "EMA 50"],
    profile: "MODERADO",
    frequency: "MEDIA",
    markets: ["EUR/USD", "GBP/USD", "R_100"],
    winRate: null,
    netResult: null,
  },
  ADAPTATIVA: {
    id: "ADAPTATIVA",
    name: "Adaptativa",
    description:
      "Seleciona automaticamente uma estratégia compatível com o regime de mercado (ADX). Alterna entre Seguidor de Tendência e Reversão à Média.",
    indicators: ["ADX 14", "EMA 50/200", "RSI 14", "Bandas de Bollinger"],
    profile: "MODERADO",
    frequency: "MEDIA",
    markets: ["EUR/USD", "GBP/USD", "R_100"],
    winRate: null,
    netResult: null,
  },
  PRECISAO_EXTREMA: {
    id: "PRECISAO_EXTREMA",
    name: "Precisão Extrema — Experimental",
    description:
      "Estratégia de múltiplas confirmações que prioriza a qualidade dos sinais e reduz a frequência de entradas. A meta de 98% é experimental e não garantida.",
    indicators: [
      "EMA 9/21/50/200",
      "RSI 14",
      "ADX 14",
      "MACD 12/26/9",
      "ATR 14",
      "Suporte/Resistência",
      "Multi-timeframe",
    ],
    profile: "CONSERVADOR",
    frequency: "BAIXA",
    markets: ["EUR/USD", "GBP/USD", "R_100"],
    winRate: null,
    netResult: null,
  },
};

function baseConfig(symbol: string, granularity: number, duration: number, durationUnit: StrategyConfig["durationUnit"]): StrategyConfig {
  return {
    symbol,
    contractType: "callput",
    granularity,
    duration,
    durationUnit,
    fixedStake: null,
    stakePercent: 0.5,
    stakeMode: "PERCENT",
    maxTrades: 0,
    cooldownSeconds: 0,
    params: {},
  };
}

function syntheticBaseConfig(symbol: string, granularity: number, duration: number, durationUnit: StrategyConfig["durationUnit"]): StrategyConfig {
  // Índices sintéticos permitem durações curtas (15s a 15m)
  return baseConfig(symbol, granularity, duration, durationUnit);
}

export function defaultConfig(id: StrategyId): StrategyConfig {
  // EUR/USD: contrato Rise/Fall mínimo de 15 minutos.
  const base = baseConfig("frxEURUSD", 60, 15, "m");
  
  // Para índices sintéticos, usar duração de 1 minuto por padrão
  const syntheticBase1m = syntheticBaseConfig("R_100", 60, 1, "m");
  const syntheticBase3m = syntheticBaseConfig("R_100", 60, 3, "m");
  const syntheticBase5m = syntheticBaseConfig("R_100", 60, 5, "m");
  const syntheticBase15m = syntheticBaseConfig("R_100", 60, 15, "m");
  
  switch (id) {
    case "CONFLUENCIA":
      base.params = {
        emaFastPeriod: 9,
        emaSlowPeriod: 21,
        emaTrendPeriod: 200,
        rsiPeriod: 14,
        adxPeriod: 14,
        rsiBuyMin: 52,
        rsiBuyMax: 68,
        rsiSellMin: 32,
        rsiSellMax: 48,
        adxMin: 25,
      };
      break;
    case "SCALPING":
      // Scalping funciona melhor em índices sintéticos com duração curta
      syntheticBase1m.params = {
        emaFastPeriod: 5,
        emaSlowPeriod: 13,
        rsiPeriod: 7,
        rsiBuyMin: 50,
        rsiBuyMax: 75,
        rsiSellMin: 25,
        rsiSellMax: 50,
      };
      return syntheticBase1m;
    case "TENDENCIA":
      base.params = {
        emaFastPeriod: 50,
        emaTrendPeriod: 200,
        adxPeriod: 14,
        adxMin: 25,
        pullbackTolerancePct: 0.1,
      };
      break;
    case "REVERSAO_MEDIA":
      base.params = {
        bbPeriod: 20,
        bbMult: 2,
        rsiPeriod: 14,
        adxPeriod: 14,
        // Limiares de RSI alinhados ao regime lateral (ADX < 20): em mercado
        // lateral o RSI oscila em torno de 45–55; 30/70 exigiria uma tendência
        // forte, o que contradiz o filtro de ADX < 20 (condição inalcançável).
        rsiOversold: 45,
        rsiOverbought: 55,
        adxMax: 20,
      };
      break;
    case "ROMPIMENTO":
      base.params = {
        lookback: 20,
        atrPeriod: 14,
        atrMinMult: 1.0,
        atrMaxMult: 3.0,
      };
      break;
    case "MACD_ADX":
      base.params = {
        macdFast: 12,
        macdSlow: 26,
        macdSignal: 9,
        adxPeriod: 14,
        adxMin: 25,
        emaPeriod: 50,
      };
      break;
    case "ADAPTATIVA":
      base.params = {
        adxPeriod: 14,
        adxTrendMin: 25,
        adxRangeMax: 20,
        confirmCandles: 3,
        minSwitchIntervalMs: 300000,
        autoAdapt: true,
        fixedRegime: "INDEFINIDO",
      };
      break;
    case "PRECISAO_EXTREMA":
      base.params = {
        emaFastPeriod: 9,
        emaMidPeriod: 21,
        emaSlowPeriod: 50,
        emaTrendPeriod: 200,
        rsiPeriod: 14,
        rsiBuyMin: 55,
        rsiBuyMax: 65,
        rsiSellMin: 35,
        rsiSellMax: 45,
        adxPeriod: 14,
        adxMin: 30,
        macdFast: 12,
        macdSlow: 26,
        macdSignal: 9,
        atrPeriod: 14,
        volatilityMinPct: 0.005,
        volatilityMaxPct: 0.5,
        htfFactor: 4,
        htfEmaFast: 9,
        htfEmaSlow: 21,
        srLookback: 50,
        srBufferAtr: 0.5,
      };
      break;
  }
  return base;
}
