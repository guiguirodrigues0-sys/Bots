import { Router } from "express";
import { runConnectionTest } from "../deriv/connectionTest.js";
import { runMarketPreview } from "../deriv/marketPreview.js";
import { discoverAssets, discoverSyntheticIndices, discoverContractDurations } from "../deriv/symbols.js";
import { derivSession } from "../deriv/sessionManager.js";
import { getEnv } from "../config/env.js";
import { bot } from "../bot/index.js";
import type { BotMode } from "../bot/bot.js";
import { DerivApiClient } from "../deriv/apiClient.js";
import { WebSocketManager } from "../deriv/wsManager.js";
import { fetchCandles, isValidGranularity, ALLOWED_GRANULARITIES } from "../services/marketDataService.js";
import {
  strategyManager,
  strategyRuntime,
  strategyStore,
} from "../strategies/index.js";
import { runBacktest, roundMetrics, type BacktestResult } from "../strategies/backtest.js";
import { runBatchTest } from "../strategies/batchTest.js";
import { diagnoseStrategiesOnCandles } from "../strategies/diagnostics.js";
import { tradeHistoryStore } from "../storage/tradeHistory.js";
import type { StrategyId } from "../strategies/types.js";
import { STRATEGY_IDS } from "../strategies/definitions.js";
import type { StrategyRiskConfig } from "../services/riskManager.js";

export const apiRouter = Router();

const backtestCache = new Map<string, BacktestResult>();

apiRouter.get("/health", (_req, res) => {
  res.json({ status: "ok", environment: getEnv().DERIV_ENVIRONMENT });
});

// ------------------------------------------------------------ Histórico

/** Lista o histórico persistido de operações (somente leitura, sem tokens). */
apiRouter.get("/trades", (_req, res) => {
  res.json({ ok: true, trades: tradeHistoryStore.list() });
});

apiRouter.post("/deriv/connect", async (req, res) => {
  const guard = derivSession.canConnect(bot.getState());
  if (!guard.ok) {
    res.status(409).json({ ok: false, error: guard.reason });
    return;
  }
  try {
    const session = await derivSession.connect(req.body?.appId, req.body?.token);
    res.json({ ok: true, session });
  } catch (err) {
    res.status(400).json({
      ok: false,
      error: err instanceof Error ? err.message : String(err),
    });
  }
});

apiRouter.get("/deriv/session", (_req, res) => {
  res.json({ ok: true, session: derivSession.getPublic() });
});

apiRouter.post("/deriv/disconnect", async (_req, res) => {
  const snapshot = bot.getSnapshot();
  const hasOpenTrade = snapshot.openTrades.some((t) => t.status === "OPEN");
  if (!hasOpenTrade && bot.getState() !== "STOPPED") {
    await bot.stop();
  }
  const result = await derivSession.disconnectIfSafe(hasOpenTrade);
  if (!result.ok) {
    res.status(409).json({ ok: false, error: result.reason });
    return;
  }
  res.json({ ok: true, session: derivSession.getPublic() });
});

apiRouter.post("/deriv/test-connection", async (_req, res) => {
  try {
    const result = await runConnectionTest();
    res.json(result);
  } catch (err) {
    res.status(500).json({
      ok: false,
      error: err instanceof Error ? err.message : String(err),
    });
  }
});

apiRouter.get("/deriv/symbols", async (_req, res) => {
  try {
    const assets = await discoverAssets();
    res.json({ ok: true, assets });
  } catch (err) {
    res.status(500).json({
      ok: false,
      error: err instanceof Error ? err.message : String(err),
    });
  }
});

apiRouter.get("/deriv/markets", async (_req, res) => {
  try {
    const [forex, synthetic] = await Promise.all([
      discoverAssets(),
      discoverSyntheticIndices(),
    ]);
    res.json({ ok: true, forex, synthetic });
  } catch (err) {
    res.status(500).json({
      ok: false,
      error: err instanceof Error ? err.message : String(err),
    });
  }
});

apiRouter.get("/deriv/contract-durations", async (req, res) => {
  const symbol = String(req.query.symbol ?? "R_100");
  const contractCategory = String(req.query.contractType ?? "callput");
  try {
    const result = await discoverContractDurations(symbol, contractCategory);
    res.json({ ok: true, ...result });
  } catch (err) {
    res.status(500).json({
      ok: false,
      error: err instanceof Error ? err.message : String(err),
    });
  }
});

apiRouter.post("/deriv/market-preview", async (req, res) => {
  try {
    const granularity = Number(req.body?.granularity ?? 900);
    if (!isValidGranularity(granularity)) {
      res.status(400).json({
        ok: false,
        error: `granularity inválido: ${granularity}. Valores permitidos (segundos): ${ALLOWED_GRANULARITIES.join(", ")}.`,
      });
      return;
    }
    const result = await runMarketPreview(granularity);
    res.json(result);
  } catch (err) {
    res.status(500).json({
      ok: false,
      error: err instanceof Error ? err.message : String(err),
    });
  }
});

apiRouter.post("/bot/start", async (req, res) => {
  if (!derivSession.hasCredentials()) {
    res.status(403).json({
      ok: false,
      error: "Conecte-se à Deriv DEMO antes de iniciar o bot.",
    });
    return;
  }
  try {
    const requested = req.body?.mode;
    const mode: BotMode =
      requested === "SIGNAL_ONLY" ? "SIGNAL_ONLY" : "DEMO_TRADE";
    await bot.start(mode);
    res.json({ ok: true, state: bot.getState(), mode: bot.getMode() });
  } catch (err) {
    res.status(500).json({
      ok: false,
      error: err instanceof Error ? err.message : String(err),
    });
  }
});

apiRouter.post("/bot/pause", (_req, res) => {
  bot.pause();
  res.json({ ok: true, state: bot.getState() });
});

apiRouter.post("/bot/resume", (_req, res) => {
  bot.resume();
  res.json({ ok: true, state: bot.getState() });
});

apiRouter.post("/bot/stop", async (_req, res) => {
  await bot.stop();
  res.json({ ok: true, state: bot.getState() });
});

apiRouter.get("/bot/state", (_req, res) => {
  res.json(bot.getSnapshot());
});

// ---------------------------------------------------------------- Estratégias

function isStrategyId(value: unknown): value is StrategyId {
  return typeof value === "string" && (STRATEGY_IDS as string[]).includes(value);
}

function liveResults() {
  const out: Record<
    string,
    { trades: number; wins: number; losses: number; winRate: number; pnl: number }
  > = {};
  const snap = strategyRuntime.getSnapshot();
  for (const h of snap.history) {
    const entry =
      out[h.strategyId] ??
      { trades: 0, wins: 0, losses: 0, winRate: 0, pnl: 0 };
    entry.trades += 1;
    if (h.result === "WIN") {
      entry.wins += 1;
    } else if (h.result === "LOSS") {
      entry.losses += 1;
    }
    entry.pnl += h.profitLoss ?? 0;
    out[h.strategyId] = entry;
  }
  for (const key of Object.keys(out)) {
    const e = out[key];
    if (e) {
      e.winRate = e.trades > 0 ? (e.wins / e.trades) * 100 : 0;
    }
  }
  return out;
}

apiRouter.get("/strategies", (_req, res) => {
  const snapshot = strategyManager.getSnapshot();
  const live = liveResults();
  const strategies = snapshot.strategies.map((s) => ({
    metadata: s.metadata,
    config: s.config,
    status: s.status,
    active: s.metadata.id === snapshot.activeId,
    live: live[s.metadata.id] ?? null,
  }));
  res.json({
    ok: true,
    activeId: snapshot.activeId,
    riskConfig: strategyRuntime.getRiskConfig(),
    strategies,
  });
});

apiRouter.get("/strategies/state", (_req, res) => {
  res.json({
    ok: true,
    manager: strategyManager.getSnapshot(),
    runtime: strategyRuntime.getSnapshot(),
  });
});

apiRouter.post("/strategies/select", async (req, res) => {
  const id = req.body?.id;
  if (!isStrategyId(id)) {
    res.status(400).json({ ok: false, error: "Estratégia inválida." });
    return;
  }
  // Troca segura: suspende novas entradas, aplica a config, reinicia buffers.
  await strategyRuntime.stop();
  const result = strategyManager.select(id);
  if (!result.ok) {
    res.status(400).json({ ok: false, error: result.error });
    return;
  }
  strategyStore.setActiveId(id);
  res.json({ ok: true, activeId: strategyManager.getActiveId() });
});

apiRouter.put("/strategies/config", (req, res) => {
  const id = req.body?.id;
  const config = req.body?.config;
  if (!isStrategyId(id) || typeof config !== "object" || config === null) {
    res.status(400).json({ ok: false, error: "Payload inválido." });
    return;
  }
  const result = strategyManager.setConfig(id, config as Record<string, unknown>);
  if (!result.ok) {
    res.status(400).json({ ok: false, error: result.errors.join(" ") });
    return;
  }
  strategyStore.setConfig(id, strategyManager.getConfig(id));
  res.json({ ok: true, config: strategyManager.getConfig(id) });
});

apiRouter.post("/strategies/config/reset", (req, res) => {
  const id = req.body?.id;
  if (!isStrategyId(id)) {
    res.status(400).json({ ok: false, error: "Estratégia inválida." });
    return;
  }
  strategyManager.resetConfig(id);
  strategyStore.resetConfig(id);
  res.json({ ok: true, config: strategyManager.getConfig(id) });
});

apiRouter.put("/strategies/risk", (req, res) => {
  const risk = req.body?.risk;
  if (typeof risk !== "object" || risk === null) {
    res.status(400).json({ ok: false, error: "Payload inválido." });
    return;
  }
  strategyStore.setRiskConfig(risk as unknown as StrategyRiskConfig);
  res.json({ ok: true, riskConfig: strategyRuntime.getRiskConfig() });
});

apiRouter.post("/strategies/start", async (_req, res) => {
  const result = await strategyRuntime.start();
  if (!result.ok) {
    res.status(400).json({ ok: false, error: result.error });
    return;
  }
  res.json({ ok: true, state: strategyRuntime.getState() });
});

apiRouter.post("/strategies/pause", (_req, res) => {
  strategyRuntime.pause();
  res.json({ ok: true, state: strategyRuntime.getState() });
});

apiRouter.post("/strategies/resume", (_req, res) => {
  strategyRuntime.resume();
  res.json({ ok: true, state: strategyRuntime.getState() });
});

apiRouter.post("/strategies/stop", async (_req, res) => {
  await strategyRuntime.stop();
  res.json({ ok: true, state: strategyRuntime.getState() });
});

apiRouter.post("/strategies/backtest", async (req, res) => {
  const id = req.body?.id;
  if (!isStrategyId(id)) {
    res.status(400).json({ ok: false, error: "Estratégia inválida." });
    return;
  }
  const config = strategyManager.getConfig(id);
  const symbol = String(req.body?.symbol ?? config.symbol);
  const granularity = Number(req.body?.granularity ?? config.granularity);
  const count = Number(req.body?.count ?? 600);
  const payout = Number(req.body?.payout ?? 1.9);

  if (!isValidGranularity(granularity)) {
    res.status(400).json({
      ok: false,
      error: `granularity inválido: ${granularity}. Valores permitidos (segundos): ${ALLOWED_GRANULARITIES.join(", ")}.`,
    });
    return;
  }

  try {
    const client = new DerivApiClient();
    const url = await client.getDemoWebSocketUrl();
    const ws = new WebSocketManager();
    await ws.connect(url);
    let candles;
    try {
      candles = await fetchCandles(ws, symbol, granularity, count);
    } finally {
      await ws.close();
    }
    const result = runBacktest(id, candles, { ...config, symbol, granularity }, { payout });
    result.aggregate = roundMetrics(result.aggregate);
    result.segments = result.segments.map((s) => ({
      ...s,
      metrics: roundMetrics(s.metrics),
    }));
    backtestCache.set(id, result);
    res.json({ ok: true, result });
  } catch (err) {
    res.status(500).json({
      ok: false,
      error: err instanceof Error ? err.message : String(err),
    });
  }
});

apiRouter.get("/strategies/backtest", (_req, res) => {
  const results = STRATEGY_IDS.map((id) => backtestCache.get(id)).filter(
    (r): r is BacktestResult => Boolean(r),
  );
  res.json({ ok: true, results });
});

apiRouter.post("/strategies/test-all", async (req, res) => {
  const symbol = String(req.body?.symbol ?? "R_100");
  const granularity = Number(req.body?.granularity ?? 60);
  const duration = Number(req.body?.duration ?? 30);
  const durationUnit = String(req.body?.durationUnit ?? "s");
  if (
    !["s", "m", "h", "t"].includes(durationUnit) ||
    !isValidGranularity(granularity) ||
    !Number.isInteger(duration) ||
    duration <= 0
  ) {
    res.status(400).json({
      ok: false,
      error: `granularity inválido: ${granularity}. Valores permitidos (segundos): ${ALLOWED_GRANULARITIES.join(", ")}.`,
    });
    return;
  }
  try {
    const result = await runBatchTest({
      symbol,
      granularity,
      duration,
      durationUnit: durationUnit as "s" | "m" | "h" | "t",
      count: Number(req.body?.count ?? 600),
      payout: Number(req.body?.payout ?? 1.9),
    });
    res.json({ ok: true, result });
  } catch (err) {
    res.status(500).json({
      ok: false,
      error: err instanceof Error ? err.message : String(err),
    });
  }
});

apiRouter.get("/strategies/performance", (_req, res) => {
  res.json({
    ok: true,
    live: liveResults(),
    runtimeStats: strategyRuntime.getSnapshot().stats,
    backtests: STRATEGY_IDS.map((id) => backtestCache.get(id)).filter(
      (r): r is BacktestResult => Boolean(r),
    ),
  });
});

// ------------------------------------------------------------- Diagnóstico

/**
 * Executa as oito estratégias isoladamente sobre histórico válido e retorna
 * contagens reais de avaliações, sinais e falhas técnicas (sem enviar ordens).
 */
apiRouter.post("/strategies/diagnose", async (req, res) => {
  const symbol = String(req.body?.symbol ?? "R_100");
  const granularity = Number(req.body?.granularity ?? 60);
  const count = Number(req.body?.count ?? 600);

  if (!isValidGranularity(granularity)) {
    res.status(400).json({
      ok: false,
      error: `granularity inválido: ${granularity}. Valores permitidos (segundos): ${ALLOWED_GRANULARITIES.join(", ")}.`,
    });
    return;
  }

  try {
    const client = new DerivApiClient();
    const url = await client.getDemoWebSocketUrl();
    const ws = new WebSocketManager();
    await ws.connect(url);
    let candles;
    try {
      candles = await fetchCandles(ws, symbol, granularity, count);
    } finally {
      await ws.close();
    }
    const result = diagnoseStrategiesOnCandles(candles, symbol, granularity);
    res.json({ ok: true, result });
  } catch (err) {
    res.status(500).json({
      ok: false,
      error: err instanceof Error ? err.message : String(err),
    });
  }
});
