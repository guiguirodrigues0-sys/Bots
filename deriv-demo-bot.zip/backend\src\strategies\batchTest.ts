import type { Candle } from "../types.js";
import type { StrategyConfig, StrategyId, DurationUnit } from "./types.js";
import { STRATEGY_IDS, STRATEGY_METADATA, defaultConfig } from "./definitions.js";
import { runBacktest, roundMetrics, type BacktestMetrics } from "./backtest.js";
import { DerivApiClient } from "../deriv/apiClient.js";
import { WebSocketManager } from "../deriv/wsManager.js";
import { fetchCandles } from "../services/marketDataService.js";
import { checkContractAvailability } from "../deriv/symbols.js";

export interface BatchStrategyResult {
  strategyId: StrategyId;
  name: string;
  signals: { buy: number; sell: number; wait: number };
  metrics: BacktestMetrics;
  noSignals: boolean;
}

export interface BatchTestResult {
  symbol: string;
  granularity: number;
  duration: number;
  durationUnit: DurationUnit;
  contractAvailable: boolean;
  contractReason: string | null;
  isEstimate: boolean;
  totalCandles: number;
  results: BatchStrategyResult[];
  note: string;
  payout: number;
  breakEvenWinRate: number;
}

const BATCH_NOTE =
  "Backtest histórico (SIMULAÇÃO). Nenhuma ordem real é enviada. Para opções binárias, acertar a direção não equivale necessariamente a lucro — o resultado financeiro é estimado a partir do modelo Rise/Fall (payout fixo), não de cotações de contrato reais.";

/**
 * Executa as oito estratégias sobre os mesmos candles e agrega sinais e
 * métricas para comparação. Função pura (testável).
 */
export function runBatchTestOnCandles(
  candles: Candle[],
  symbol: string,
  granularity: number,
  duration: number,
  durationUnit: DurationUnit,
  payout: number,
  contractAvailable: boolean,
  contractReason: string | null,
): BatchTestResult {
  const results: BatchStrategyResult[] = STRATEGY_IDS.map((id) => {
    const config: StrategyConfig = {
      ...defaultConfig(id),
      symbol,
      granularity,
      duration,
      durationUnit,
    };
    // Uma única fatia contínua: [1, 0, 0] evita o "warm-up" entre segmentos.
    const bt = runBacktest(id, candles, config, { payout, split: [1, 0, 0] });
    const signals = bt.segments.reduce(
      (acc, s) => ({
        buy: acc.buy + s.signals.buy,
        sell: acc.sell + s.signals.sell,
        wait: acc.wait + s.signals.wait,
      }),
      { buy: 0, sell: 0, wait: 0 },
    );
    return {
      strategyId: id,
      name: STRATEGY_METADATA[id].name,
      signals,
      metrics: roundMetrics(bt.aggregate),
      noSignals: signals.buy + signals.sell === 0,
    };
  });

  return {
    symbol,
    granularity,
    duration,
    durationUnit,
    contractAvailable,
    contractReason,
    isEstimate: results.some((r) => r.metrics.trades > 0),
    totalCandles: candles.length,
    results,
    note: BATCH_NOTE,
    payout,
    breakEvenWinRate: payout > 0 ? (1 / payout) * 100 : 0,
  };
}

export interface BatchTestRequest {
  symbol: string;
  granularity: number;
  duration: number;
  durationUnit: DurationUnit;
  count?: number;
  payout?: number;
}

/**
 * Carrega o histórico do ativo, verifica a disponibilidade do contrato e
 * executa o teste comparativo das oito estratégias (sem enviar ordens).
 */
export async function runBatchTest(
  req: BatchTestRequest,
): Promise<BatchTestResult> {
  const count = req.count ?? 600;
  const payout = req.payout ?? 1.9;
  const client = new DerivApiClient();
  const url = await client.getDemoWebSocketUrl();
  const ws = new WebSocketManager();
  await ws.connect(url);
  try {
    const candles = await fetchCandles(ws, req.symbol, req.granularity, count);

    let contractAvailable = false;
    let contractReason = "Contrato não verificado.";
    try {
      const avail = await checkContractAvailability(
        ws,
        req.symbol,
        "callput",
        req.duration,
        req.durationUnit,
      );
      contractAvailable = avail.ok;
      contractReason = avail.reason;
    } catch (err) {
      contractReason = `Falha ao verificar contrato: ${(err as Error).message}`;
    }

    return runBatchTestOnCandles(
      candles,
      req.symbol,
      req.granularity,
      req.duration,
      req.durationUnit,
      payout,
      contractAvailable,
      contractReason,
    );
  } finally {
    await ws.close();
  }
}
