import { test } from "node:test";
import assert from "node:assert/strict";
import {
  evaluateStrategyRisk,
  computeStrategyStake,
  computeEffectiveStrategyStake,
  effectiveCooldownSeconds,
  DEFAULT_STRATEGY_RISK_CONFIG,
  type StrategyRiskConfig,
} from "../src/services/riskManager.js";

process.env.LOG_LEVEL = "error";

function input(overrides: Partial<Parameters<typeof evaluateStrategyRisk>[0]> = {}) {
  return {
    openCount: 0,
    exposurePct: 0,
    consecutiveLosses: 0,
    pnlPct: 0,
    lastEntryAt: null,
    now: Date.now(),
    ...overrides,
  };
}

test("bloqueia no limite de operações simultâneas", () => {
  const r = evaluateStrategyRisk(input({ openCount: 3 }));
  assert.equal(r.ok, false);
});

test("bloqueia no limite de exposição", () => {
  const r = evaluateStrategyRisk(input({ exposurePct: 5 }));
  assert.equal(r.ok, false);
});

test("bloqueia no limite de perdas consecutivas", () => {
  const r = evaluateStrategyRisk(input({ consecutiveLosses: 3 }));
  assert.equal(r.ok, false);
});

test("bloqueia no stop diário", () => {
  const r = evaluateStrategyRisk(input({ pnlPct: -5 }));
  assert.equal(r.ok, false);
});

test("bloqueia na meta diária", () => {
  const r = evaluateStrategyRisk(input({ pnlPct: 5 }));
  assert.equal(r.ok, false);
});

test("bloqueia durante cooldown", () => {
  const now = Date.now();
  const r = evaluateStrategyRisk(
    input({ lastEntryAt: now - 5000, now }),
    { ...DEFAULT_STRATEGY_RISK_CONFIG, cooldownSeconds: 30 },
  );
  assert.equal(r.ok, false);
});

test("permite entrada dentro dos limites", () => {
  const r = evaluateStrategyRisk(input());
  assert.equal(r.ok, true);
});

test("perdas consecutivas podem ser desativadas (null)", () => {
  const cfg: StrategyRiskConfig = { ...DEFAULT_STRATEGY_RISK_CONFIG, maxConsecutiveLosses: null };
  const r = evaluateStrategyRisk(input({ consecutiveLosses: 99 }), cfg);
  assert.equal(r.ok, true);
});

test("stake percentual é calculada e normalizada", () => {
  const cfg: StrategyRiskConfig = {
    ...DEFAULT_STRATEGY_RISK_CONFIG,
    stakeMode: "PERCENT",
    stakePercent: 0.5,
  };
  assert.equal(computeStrategyStake(9900.25, cfg, "USD"), 49.5);
});

test("stake fixa é normalizada para 2 casas", () => {
  const cfg: StrategyRiskConfig = {
    ...DEFAULT_STRATEGY_RISK_CONFIG,
    stakeMode: "FIXED",
    fixedStake: 24.759,
  };
  assert.equal(computeStrategyStake(10000, cfg, "USD"), 24.75);
});

test("sem Martingale: stake não aumenta após perda", () => {
  const cfg: StrategyRiskConfig = { ...DEFAULT_STRATEGY_RISK_CONFIG };
  const before = computeStrategyStake(10000, cfg, "USD");
  const after = computeStrategyStake(9950, cfg, "USD");
  assert.ok(after <= before);
});

test("stake inválida retorna 0", () => {
  const cfg: StrategyRiskConfig = {
    ...DEFAULT_STRATEGY_RISK_CONFIG,
    stakeMode: "FIXED",
    fixedStake: 0,
  };
  assert.equal(computeStrategyStake(10000, cfg, "USD"), 0);
});

// ------------------------------------------------------ Stake/cooldown efetivos

test("stake efetiva usa a individual, respeitando o teto global (percentual)", () => {
  const global: StrategyRiskConfig = {
    ...DEFAULT_STRATEGY_RISK_CONFIG,
    stakeMode: "PERCENT",
    stakePercent: 1.0, // teto global
  };
  // Individual mais conservadora que o teto → prevalece a individual.
  assert.equal(
    computeEffectiveStrategyStake(
      10000,
      { stakeMode: "PERCENT", stakePercent: 0.5, fixedStake: null },
      global,
      "USD",
    ),
    50,
  );
  // Individual mais agressiva que o teto → prevalece o teto global.
  assert.equal(
    computeEffectiveStrategyStake(
      10000,
      { stakeMode: "PERCENT", stakePercent: 3.0, fixedStake: null },
      global,
      "USD",
    ),
    100,
  );
});

test("stake efetiva nunca excede o teto global em modo fixo", () => {
  const global: StrategyRiskConfig = {
    ...DEFAULT_STRATEGY_RISK_CONFIG,
    stakeMode: "FIXED",
    fixedStake: 10,
  };
  assert.equal(
    computeEffectiveStrategyStake(
      10000,
      { stakeMode: "FIXED", stakePercent: null, fixedStake: 50 },
      global,
      "USD",
    ),
    10,
  );
});

test("cooldown efetivo é o mais restritivo (maior) entre global e individual", () => {
  const global: StrategyRiskConfig = {
    ...DEFAULT_STRATEGY_RISK_CONFIG,
    cooldownSeconds: 30,
  };
  assert.equal(effectiveCooldownSeconds(global, 0), 30);
  assert.equal(effectiveCooldownSeconds(global, 60), 60);
});
