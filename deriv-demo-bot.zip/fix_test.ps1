$content = Get-Content 'C:\Users\guigu\Downloads\Projetos\deriv-demo-bot\backend\tests\settlement.test.ts' -Raw
$content = $content -replace 'r\.restorePendingTrades\("frxEURUSD"\)', 'r.restorePendingTrades()'
$content = $content -replace 't\.status === "OPEN"\)\.length, 1\);', 't.status === "OPEN" || t.status === "PENDING").length, 1);'
$content = $content -replace 'const openCount = r\.openTrades\.filter\(\(t: \{ status: string \}\) => t\.status === "OPEN"\)\.length;', 'const openCount = r.openTrades.filter((t) => t.status === "OPEN" || t.status === "PENDING").length;'
$content = $content -replace '// O gerenciamento de risco conta a posição desconhecida como aberta\.', '// O gerenciamento de risco conta a posição desconhecida (PENDING) como aberta.'
Set-Content 'C:\Users\guigu\Downloads\Projetos\deriv-demo-bot\backend\tests\settlement.test.ts' -Value $content