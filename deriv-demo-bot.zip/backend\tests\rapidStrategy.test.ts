import { test } from "node:test";
import assert from "node:assert/strict";
import { computeRapidSignal } from "../src/services/rapidStrategy.js";

process.env.LOG_LEVEL = "error";

test("dados insuficientes retornam WAIT", () => {
  const s = computeRapidSignal([1, 2, 3]);
  assert.equal(s.direction, "WAIT");
  assert.equal(s.score, 0);
});

function uptrend(n: number): number[] {
  const out: number[] = [];
  let v = 100;
  for (let i = 0; i < n; i++) {
    v += 0.05 + (i % 3) * 0.005;
    out.push(v);
  }
  return out;
}

function downtrend(n: number): number[] {
  const out: number[] = [];
  let v = 100;
  for (let i = 0; i < n; i++) {
    v -= 0.05 + (i % 3) * 0.005;
    out.push(v);
  }
  return out;
}

test("tendência de alta gera CALL", () => {
  const s = computeRapidSignal(uptrend(60));
  assert.equal(s.direction, "CALL");
  assert.ok(s.score > 0);
});

test("tendência de baixa gera PUT", () => {
  const s = computeRapidSignal(downtrend(60));
  assert.equal(s.direction, "PUT");
  assert.ok(s.score > 0);
});

test("mercado lateral não gera CALL nem PUT", () => {
  const flat = new Array<number>(60).fill(100);
  const s = computeRapidSignal(flat);
  assert.equal(s.direction, "WAIT");
});

test("score é múltiplo de 20 (0-100) com 5 confirmações", () => {
  const s = computeRapidSignal(uptrend(60));
  assert.ok(s.score >= 0 && s.score <= 100);
  assert.equal(s.score % 20, 0);
  assert.equal(s.confirmationsTotal, 5);
});

test("volatilidade e EMAs são expostas", () => {
  const s = computeRapidSignal(uptrend(60));
  assert.notEqual(s.fastEma, null);
  assert.notEqual(s.slowEma, null);
  assert.notEqual(s.rsi, null);
  assert.notEqual(s.volatilityPct, null);
});
