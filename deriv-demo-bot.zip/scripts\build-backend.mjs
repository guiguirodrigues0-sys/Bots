import { build } from "esbuild";

await build({
  entryPoints: ["backend/src/index.ts"],
  bundle: true,
  platform: "node",
  format: "cjs",
  target: "node20",
  outfile: "electron/backend.cjs",
  sourcemap: false,
  external: ["bufferutil", "utf-8-validate"],
  logLevel: "info",
});
