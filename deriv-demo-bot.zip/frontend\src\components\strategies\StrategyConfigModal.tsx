import { useEffect, useState } from "react";
import {
  ALLOWED_GRANULARITIES,
  GRANULARITY_LABELS,
  durationLabel,
  getContractDurations,
  type ContractDurationOption,
  type ContractDurationsResponse,
  type StrategyConfig,
  type StrategyId,
} from "../../api/client";

interface Props {
  strategyId: StrategyId;
  name: string;
  config: StrategyConfig;
  onClose: () => void;
  onSave: (config: Partial<StrategyConfig>) => Promise<void>;
  onReset: () => Promise<void>;
  onBacktest: () => Promise<void>;
  onActivate: () => Promise<void>;
}

/** Opções de duração desejadas (fallback quando a API não responde). */
const DURATION_OPTIONS: ContractDurationOption[] = [
  { duration: 30, unit: "s", label: durationLabel(30, "s"), available: true },
  { duration: 1, unit: "m", label: durationLabel(1, "m"), available: true },
  { duration: 2, unit: "m", label: durationLabel(2, "m"), available: true },
  { duration: 3, unit: "m", label: durationLabel(3, "m"), available: true },
  { duration: 5, unit: "m", label: durationLabel(5, "m"), available: true },
  { duration: 10, unit: "m", label: durationLabel(10, "m"), available: true },
  { duration: 15, unit: "m", label: durationLabel(15, "m"), available: true },
];

function parseNum(v: string): number {
  const n = Number(v);
  return Number.isFinite(n) ? n : 0;
}

export default function StrategyConfigModal({
  strategyId,
  name,
  config,
  onClose,
  onSave,
  onReset,
  onBacktest,
  onActivate,
}: Props) {
  const [symbol, setSymbol] = useState(config.symbol);
  const [granularity, setGranularity] = useState(() =>
    (ALLOWED_GRANULARITIES as readonly number[]).includes(config.granularity)
      ? String(config.granularity)
      : "60",
  );
  const [duration, setDuration] = useState(String(config.duration));
  const [durationUnit, setDurationUnit] = useState<StrategyConfig["durationUnit"]>(config.durationUnit);
  const [isLoadingDurations, setIsLoadingDurations] = useState(false);
  const [stakeMode, setStakeMode] = useState<StrategyConfig["stakeMode"]>(config.stakeMode);
  const [stakePercent, setStakePercent] = useState(String(config.stakePercent ?? 0.5));
  const [fixedStake, setFixedStake] = useState(String(config.fixedStake ?? 1));
  const [maxTrades, setMaxTrades] = useState(String(config.maxTrades));
  const [cooldown, setCooldown] = useState(String(config.cooldownSeconds));
  const [params, setParams] = useState<Record<string, number | boolean | string>>({ ...config.params });
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [message, setMessage] = useState<string | null>(null);

  // Durações disponíveis (consultadas na API para o símbolo selecionado).
  const [durations, setDurations] = useState<ContractDurationsResponse | null>(null);
  const [durationsError, setDurationsError] = useState<string | null>(null);

  useEffect(() => {
    let alive = true;
    setDurations(null);
    setDurationsError(null);
    setIsLoadingDurations(true);
    // Reset duration when symbol changes - will be corrected by the validation effect
    setDuration("");
    setDurationUnit("m");
    getContractDurations(symbol)
      .then((d) => {
        if (alive) {
          setDurations(d);
          setIsLoadingDurations(false);
        }
      })
      .catch((e) => {
        if (alive) {
          setDurationsError(e instanceof Error ? e.message : String(e));
          setIsLoadingDurations(false);
        }
      });
    return () => {
      alive = false;
    };
  }, [symbol]);

  // Se a duração atual não estiver disponível para o símbolo, seleciona a
  // primeira disponível (nunca deixa uma seleção inválida).
  useEffect(() => {
    if (!durations) return;
    const avail = durations.options.filter((o) => o.available);
    if (avail.length === 0) return;
    const currentKey = `${duration}${durationUnit}`;
    if (!avail.some((o) => `${o.duration}${o.unit}` === currentKey)) {
      const first = avail[0]!;
      setDuration(String(first.duration));
      setDurationUnit(first.unit);
    }
  }, [durations, duration, durationUnit]);

  const paramKeys = Object.keys(params);

  const durationOptions = durations?.options ?? DURATION_OPTIONS;
  const availableDurations = durationOptions.filter((o) => o.available);
  const selectedDurationKey = `${duration}${durationUnit}`;

  // Show loading indicator in the duration select
  const isDurationLoading = isLoadingDurations || !durations;

  const buildConfig = (): Partial<StrategyConfig> => ({
    symbol,
    granularity: parseNum(granularity),
    duration: parseNum(duration),
    durationUnit,
    stakeMode,
    stakePercent: parseNum(stakePercent),
    fixedStake: parseNum(fixedStake),
    maxTrades: parseNum(maxTrades),
    cooldownSeconds: parseNum(cooldown),
    params,
  });

  const wrap = async (fn: () => Promise<void>, okMsg: string) => {
    setBusy(true);
    setError(null);
    setMessage(null);
    try {
      await fn();
      setMessage(okMsg);
    } catch (e) {
      setError(e instanceof Error ? e.message : String(e));
    } finally {
      setBusy(false);
    }
  };

  const renderParamInput = (key: string) => {
    const value = params[key];
    if (typeof value === "boolean") {
      return (
        <label className="cfg-check">
          <input
            type="checkbox"
            checked={value}
            onChange={(e) => setParams((p) => ({ ...p, [key]: e.target.checked }))}
          />
          <span>{key}</span>
        </label>
      );
    }
    return (
      <div className="conn-field" key={key}>
        <label>{key}</label>
        <input
          type="text"
          value={String(value)}
          onChange={(e) => {
            const v = typeof value === "number" ? parseNum(e.target.value) : e.target.value;
            setParams((p) => ({ ...p, [key]: v }));
          }}
        />
      </div>
    );
  };

  return (
    <div className="modal-overlay" onClick={onClose}>
      <div className="modal" onClick={(e) => e.stopPropagation()}>
        <header className="modal-head">
          <h2>Configurar — {name}</h2>
          <button className="link-btn" onClick={onClose}>Fechar</button>
        </header>

        <div className="modal-body">
          <div className="cfg-grid">
            <div className="conn-field">
              <label>Ativo</label>
              <select
                value={symbol}
                onChange={(e) => {
                  // A duração é revalidada/ajustada automaticamente pelo efeito
                  // que consulta as durações disponíveis para o novo símbolo.
                  setSymbol(e.target.value);
                }}
              >
                <optgroup label="Forex">
                  <option value="frxEURUSD">EUR/USD (frxEURUSD)</option>
                  <option value="frxGBPUSD">GBP/USD (frxGBPUSD)</option>
                </optgroup>
                <optgroup label="Índices sintéticos">
                  <option value="R_100">Volatility 100 (R_100)</option>
                  <option value="R_75">Volatility 75 (R_75)</option>
                  <option value="R_50">Volatility 50 (R_50)</option>
                  <option value="R_25">Volatility 25 (R_25)</option>
                  <option value="R_10">Volatility 10 (R_10)</option>
                </optgroup>
              </select>
            </div>
            <div className="conn-field">
              <label>Contrato</label>
              <input type="text" value="Rise/Fall (callput)" disabled />
            </div>
            <div className="conn-field">
              <label>Timeframe (candles)</label>
              <select value={granularity} onChange={(e) => setGranularity(e.target.value)}>
                {ALLOWED_GRANULARITIES.map((g) => (
                  <option key={g} value={g}>
                    {GRANULARITY_LABELS[g]} ({g}s)
                  </option>
                ))}
              </select>
            </div>
            <div className="conn-field">
              <label>Duração do contrato</label>
              <select
                value={selectedDurationKey || ""}
                onChange={(e) => {
                  const m = /^(\d+)([sm])$/.exec(e.target.value);
                  if (m) {
                    setDuration(m[1]!);
                    setDurationUnit(m[2] as StrategyConfig["durationUnit"]);
                  }
                }}
                disabled={isDurationLoading}
              >
                {isDurationLoading ? (
                  <option value="" disabled>
                    Carregando durações...
                  </option>
                ) : (
                  durationOptions.map((o) => (
                    <option
                      key={`${o.duration}${o.unit}`}
                      value={`${o.duration}${o.unit}`}
                      disabled={!o.available}
                    >
                      {o.label}{o.available ? "" : " — indisponível"}
                    </option>
                  ))
                )}
              </select>
            </div>
            {durations && (durations.minDuration || durations.maxDuration) && (
              <p className="notice muted" style={{ gridColumn: "1 / -1" }}>
                {symbol} · Rise/Fall: duração {durations.minDuration ?? "?"}–{durations.maxDuration ?? "?"}
                {" "}· opções indisponíveis aparecem desabilitadas.
              </p>
            )}
            {durationsError && (
              <p className="notice neg" style={{ gridColumn: "1 / -1" }}>
                Não foi possível validar as durações com a API ({durationsError}). A compra será
                bloqueada pelo backend se a duração não for aceita.
              </p>
            )}
            {availableDurations.length === 0 && !durationsError && (
              <p className="notice neg" style={{ gridColumn: "1 / -1" }}>
                Nenhuma duração Rise/Fall disponível para {symbol}. Selecione outro ativo.
              </p>
            )}
            <div className="conn-field">
              <label>Stake (modo)</label>
              <select value={stakeMode} onChange={(e) => setStakeMode(e.target.value as StrategyConfig["stakeMode"])}>
                <option value="PERCENT">Percentual do saldo</option>
                <option value="FIXED">Valor fixo</option>
              </select>
            </div>
            {stakeMode === "PERCENT" ? (
              <div className="conn-field">
                <label>Stake (%)</label>
                <input type="text" value={stakePercent} onChange={(e) => setStakePercent(e.target.value)} />
              </div>
            ) : (
              <div className="conn-field">
                <label>Stake (fixa)</label>
                <input type="text" value={fixedStake} onChange={(e) => setFixedStake(e.target.value)} />
              </div>
            )}
            <div className="conn-field">
              <label>Máximo de operações (0 = ilimitado)</label>
              <input type="text" value={maxTrades} onChange={(e) => setMaxTrades(e.target.value)} />
            </div>
            <div className="conn-field">
              <label>Cooldown (segundos)</label>
              <input type="text" value={cooldown} onChange={(e) => setCooldown(e.target.value)} />
            </div>
          </div>

          <div className="cfg-section">
            <h3>Indicadores e limites</h3>
            <div className="cfg-grid">
              {paramKeys.map((key) => renderParamInput(key))}
            </div>
          </div>

          {error && <div className="error-box"><p>{error}</p></div>}
          {message && <p className="notice pos">{message}</p>}
        </div>

        <footer className="modal-foot">
          <button className="btn" disabled={busy} onClick={() => wrap(() => onSave(buildConfig()), "Configuração salva.")}>
            Salvar configuração
          </button>
          <button className="btn" disabled={busy} onClick={() => wrap(onReset, "Padrões restaurados.")}>
            Restaurar padrões
          </button>
          <button className="btn" disabled={busy} onClick={() => wrap(onBacktest, "Teste em simulação concluído.")}>
            Testar em simulação
          </button>
          <button className="btn btn-primary" disabled={busy} onClick={() => wrap(onActivate, `Estratégia ${strategyId} ativada.`)}>
            Ativar estratégia
          </button>
        </footer>
      </div>
    </div>
  );
}
