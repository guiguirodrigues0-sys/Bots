import { test } from "node:test";
import assert from "node:assert/strict";
import {
  RiskManager,
  evaluateRapidRisk,
  normalizeStake,
  currencyDecimals,
} from "../src/services/riskManager.js";
import type { SessionStats } from "../src/types.js";

function stats(overrides: Partial<SessionStats> = {}): SessionStats {
  return {
    initialBalance: 10000,
    currentBalance: 10000,
    sessionPnL: 0,
    totalTrades: 0,
    wins: 0,
    losses: 0,
    winRate: 0,
    consecutiveLosses: 0,
    maxConsecutiveLosses: 0,
    ...overrides,
  };
}

test("posição já aberta impede nova operação", () => {
  const rm = new RiskManager();
  assert.equal(rm.canTrade(stats(), true).ok, false);
});

test("3 perdas consecutivas impedem nova entrada", () => {
  const rm = new RiskManager();
  assert.equal(rm.canTrade(stats({ consecutiveLosses: 3 }), false).ok, false);
});

test("stop diário impede entrada", () => {
  const rm = new RiskManager();
  assert.equal(rm.canTrade(stats({ initialBalance: 10000, sessionPnL: -500 }), false).ok, false);
});

test("meta diária impede entrada", () => {
  const rm = new RiskManager();
  assert.equal(rm.canTrade(stats({ initialBalance: 10000, sessionPnL: 500 }), false).ok, false);
});

test("stake padrão é 0.5% da banca virtual", () => {
  const rm = new RiskManager();
  assert.equal(rm.calculateStake(10000), 50);
});

test("stake nunca ultrapassa o limite configurado", () => {
  const rm = new RiskManager({
    defaultRiskPct: 5,
    maxRiskPct: 1,
    dailyStopPct: 5,
    dailyTargetPct: 5,
    maxConsecutiveLosses: 3,
  });
  assert.equal(rm.calculateStake(10000), 100);
});

test("nenhuma lógica aumenta stake automaticamente após LOSS", () => {
  const rm = new RiskManager();
  const antes = rm.calculateStake(10000);
  const depois = rm.calculateStake(10000);
  assert.equal(antes, depois);
});

test("stake rápido (ACTIVE_RISK) é fixo e não aumenta após LOSS", () => {
  const rm = new RiskManager();
  const a = rm.calculateStakeAt(10000, 0.25);
  const b = rm.calculateStakeAt(10000, 0.25);
  assert.equal(a, 25);
  assert.equal(a, b);
});

test("evaluateRapidRisk bloqueia no máximo de posições", () => {
  const r = evaluateRapidRisk({
    openCount: 3,
    exposurePct: 0.75,
    consecutiveLosses: 0,
    pnlPct: 0,
  });
  assert.equal(r.ok, false);
});

test("evaluateRapidRisk bloqueia no limite de exposição", () => {
  const r = evaluateRapidRisk({
    openCount: 1,
    exposurePct: 1.5,
    consecutiveLosses: 0,
    pnlPct: 0,
  });
  assert.equal(r.ok, false);
});

test("evaluateRapidRisk permite entrada dentro dos limites", () => {
  const r = evaluateRapidRisk({
    openCount: 2,
    exposurePct: 0.5,
    consecutiveLosses: 0,
    pnlPct: 0,
  });
  assert.equal(r.ok, true);
});

test("evaluateRapidRisk bloqueia no limite de perdas consecutivas", () => {
  const r = evaluateRapidRisk({
    openCount: 0,
    exposurePct: 0,
    consecutiveLosses: 3,
    pnlPct: 0,
  });
  assert.equal(r.ok, false);
});

test("evaluateRapidRisk bloqueia no stop diário", () => {
  const r = evaluateRapidRisk({
    openCount: 0,
    exposurePct: 0,
    consecutiveLosses: 0,
    pnlPct: -5,
  });
  assert.equal(r.ok, false);
});

test("normalizeStake trunca 24.750625 para 24.75 (USD)", () => {
  assert.equal(normalizeStake(24.750625, "USD"), 24.75);
});

test("normalizeStake mantém 25.00 (USD)", () => {
  assert.equal(normalizeStake(25.0, "USD"), 25);
});

test("normalizeStake trunca 3.0864 para 3.08 (USD)", () => {
  assert.equal(normalizeStake(3.0864, "USD"), 3.08);
});

test("normalizeStake trunca (floor) e não arredonda para cima", () => {
  assert.equal(normalizeStake(24.759, "USD"), 24.75);
});

test("normalizeStake nunca produz mais de 2 casas para USD", () => {
  for (const v of [24.750625, 0.01, 0.005, 100.999, 1.999, 3.0864]) {
    const n = normalizeStake(v, "USD");
    const s = n.toString();
    const dot = s.indexOf(".");
    const dec = dot === -1 ? 0 : s.length - dot - 1;
    assert.ok(dec <= 2, `${n} tem ${dec} casas`);
  }
});

test("currencyDecimals: USD=2, JPY=0, desconhecida=2", () => {
  assert.equal(currencyDecimals("USD"), 2);
  assert.equal(currencyDecimals("JPY"), 0);
  assert.equal(currencyDecimals("XYZ"), 2);
});
