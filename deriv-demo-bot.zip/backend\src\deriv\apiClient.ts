import { getEnv } from "../config/env.js";
import { logger } from "../logger/index.js";
import { getActiveCredentials } from "./credentials.js";

const REST_BASE = "https://api.derivws.com";

export const BLOCKED_MESSAGE =
  "OPERAÇÃO BLOQUEADA: este protótipo funciona somente em conta DEMO.";

export class DemoAccountBlockedError extends Error {
  constructor(message = BLOCKED_MESSAGE) {
    super(message);
    this.name = "DemoAccountBlockedError";
  }
}

export const AUTH_EXPIRED_MESSAGE =
  "CONEXÃO EXPIRADA — RECONECTE SUA CONTA DEMO";

export class AuthExpiredError extends Error {
  constructor() {
    super(AUTH_EXPIRED_MESSAGE);
    this.name = "AuthExpiredError";
  }
}

export interface DerivAccount {
  account_id: string;
  balance: string;
  currency: string;
  group?: string;
  status?: string;
  account_type: string;
}

function maskUrl(url: string): string {
  try {
    const u = new URL(url);
    if (u.searchParams.has("otp")) {
      u.searchParams.set("otp", "[REDACTED]");
    }
    return u.toString();
  } catch {
    return "[url inválida]";
  }
}

/**
 * Lê o corpo como texto (para mensagens de erro), truncando respostas longas.
 */
async function safeBodyText(res: Response): Promise<string> {
  const text = await res.text();
  return text.length > 300 ? `${text.slice(0, 300)}…` : text;
}

/**
 * Parse seguro de JSON. Respostas não-JSON (ex.: HTML de gateway/proxy)
 * são convertidas em um erro claro em vez de "Unexpected token '<'".
 */
async function parseJsonResponse(res: Response): Promise<Record<string, unknown>> {
  const text = await res.text();
  try {
    const parsed: unknown = JSON.parse(text);
    if (parsed && typeof parsed === "object") {
      return parsed as Record<string, unknown>;
    }
    throw new Error("Resposta JSON inesperada (não é um objeto).");
  } catch (err) {
    if (err instanceof SyntaxError) {
      const ct = res.headers.get("content-type") ?? "desconhecido";
      throw new Error(
        `Resposta inesperada da API Deriv (status ${res.status}, content-type ${ct}). Resposta não-JSON: ${text.slice(0, 200)}`,
      );
    }
    throw err;
  }
}

export class DerivApiClient {
  private readonly appId?: string;
  private readonly token?: string;

  constructor(opts?: { appId?: string; token?: string }) {
    this.appId = opts?.appId;
    this.token = opts?.token;
  }

  private credentials(): { appId: string; token: string } {
    if (this.appId && this.token) {
      return { appId: this.appId, token: this.token };
    }
    const active = getActiveCredentials();
    if (active) {
      return active;
    }
    const env = getEnv();
    return { appId: env.DERIV_APP_ID, token: env.DERIV_API_TOKEN };
  }

  private headers(): Record<string, string> {
    const { appId, token } = this.credentials();
    return {
      Authorization: `Bearer ${token}`,
      "Deriv-App-ID": appId,
      "Content-Type": "application/json",
    };
  }

  async listAccounts(): Promise<DerivAccount[]> {
    const res = await fetch(`${REST_BASE}/trading/v1/options/accounts`, {
      method: "GET",
      headers: this.headers(),
    });
    if (!res.ok) {
      if (res.status === 401 || res.status === 403) {
        throw new AuthExpiredError();
      }
      throw new Error(
        `GET /accounts falhou (${res.status}): ${await safeBodyText(res)}`,
      );
    }
    const json = await parseJsonResponse(res);
    return (json.data as DerivAccount[]) ?? [];
  }

  async findDemoAccount(): Promise<DerivAccount> {
    const accounts = await this.listAccounts();
    const demo = accounts.filter((a) => a.account_type === "demo");
    if (demo.length === 0) {
      logger.error("Nenhuma conta DEMO encontrada", {
        accountTypes: accounts.map((a) => a.account_type),
      });
      throw new DemoAccountBlockedError();
    }
    const account = demo[0];
    if (!account) {
      throw new DemoAccountBlockedError();
    }
    return account;
  }

  /**
   * Obtém URL de WebSocket via OTP com retry para erros transientes (502, 503, 504).
   * A Deriv pode retornar 502/503 temporariamente; tentamos novamente com backoff.
   */
  private async getOtp(accountId: string): Promise<string> {
    const res = await fetch(
      `${REST_BASE}/trading/v1/options/accounts/${accountId}/otp`,
      {
        method: "POST",
        headers: this.headers(),
      },
    );
    if (!res.ok) {
      if (res.status === 401 || res.status === 403) {
        throw new AuthExpiredError();
      }
      throw new Error(
        `POST /otp falhou (${res.status}): ${await safeBodyText(res)}`,
      );
    }
    const json = await parseJsonResponse(res);
    const url = (json.data as { url?: string } | undefined)?.url;
    if (!url) {
      throw new Error(`POST /otp sem URL válida: ${JSON.stringify(json)}`);
    }
    return url;
  }

  /**
   * Obtém URL de WebSocket via OTP com retry para erros transientes (502, 503, 504).
   * A Deriv pode retornar 502/503 temporariamente; tentamos novamente com backoff.
   */
  private async getOtpWithRetry(accountId: string, maxAttempts = 3): Promise<string> {
    let lastError: Error | null = null;
    for (let attempt = 1; attempt <= maxAttempts; attempt++) {
      try {
        return await this.getOtp(accountId);
      } catch (err) {
        lastError = err instanceof Error ? err : new Error(String(err));
        const isTransient =
          /POST \/otp falhou \((502|503|504)\)/.test(lastError.message) ||
          /fetch failed/.test(lastError.message);
        if (!isTransient || attempt === maxAttempts) {
          throw lastError;
        }
        logger.warn("OTP falhou com erro transiente; retentando", {
          attempt,
          maxAttempts,
          error: lastError.message,
        });
        await new Promise((r) => setTimeout(r, 1000 * attempt));
      }
    }
    throw lastError!;
  }

  async getDemoWebSocketUrl(): Promise<string> {
    const account = await this.findDemoAccount();
    logger.info("Conta DEMO selecionada", {
      accountId: account.account_id,
      currency: account.currency,
    });
    const url = await this.getOtpWithRetry(account.account_id);
    this.assertDemoUrl(url);
    return url;
  }

  private assertDemoUrl(url: string): void {
    const isDemo = url.includes("/ws/demo");
    const isReal = url.includes("/ws/real");
    if (isReal) {
      logger.error("Endpoint REAL retornado. Bloqueando operações.", {
        url: maskUrl(url),
      });
      throw new DemoAccountBlockedError();
    }
    if (!isDemo) {
      logger.error("Não foi possível confirmar ambiente DEMO.", {
        url: maskUrl(url),
      });
      throw new DemoAccountBlockedError();
    }
  }
}
