/**
 * Validação de rentabilidade — forex (somente leitura).
 * Roda o backtest das 8 estratégias em dois contratos: 1d (@1h) e 15m (@5m),
 * com separação dev/validação/teste fora da amostra (sem look-ahead).
 */
import { DerivApiClient } from "../backend/src/deriv/apiClient.js";
import { WebSocketManager } from "../backend/src/deriv/wsManager.js";
import { fetchCandles } from "../backend/src/services/marketDataService.js";
import { runBacktest, roundMetrics } from "../backend/src/strategies/backtest.js";
import { defaultConfig, STRATEGY_IDS, STRATEGY_METADATA } from "../backend/src/strategies/definitions.js";

process.env.LOG_LEVEL = "error";

const FOREX: Array<{ label: string; symbol: string }> = [
  { label: "EUR/USD", symbol: "frxEURUSD" },
  { label: "GBP/USD", symbol: "frxGBPUSD" },
];

async function getPayout(
  ws: WebSocketManager,
  symbol: string,
  direction: "CALL" | "PUT",
  duration: number,
  unit: string,
): Promise<number | null> {
  try {
    const msg = await ws.request({
      proposal: 1,
      amount: 1,
      basis: "stake",
      contract_type: direction,
      currency: "USD",
      duration,
      duration_unit: unit,
      underlying_symbol: symbol,
    });
    const p = (msg.proposal as { payout?: number | string } | undefined)?.payout;
    return p != null ? Number(p) : null;
  } catch {
    return null;
  }
}

function fmtPf(n: number): string {
  return Number.isFinite(n) ? n.toFixed(2) : "∞";
}

async function runScenario(
  ws: WebSocketManager,
  symbol: string,
  duration: number,
  durationUnit: "m" | "d",
  granularity: number,
  payout: number,
): Promise<void> {
  const candles = await fetchCandles(ws, symbol, granularity, 5000);
  const breakEven = (1 / payout) * 100;
  console.log(
    `\n--- ${symbol} ${duration}${durationUnit} @ ${granularity}s | ${candles.length} candles | payout ${payout.toFixed(3)} | break-even ${breakEven.toFixed(1)}% ---`,
  );
  console.log(
    "  Estratégia              | TESTE ops | Acerto | NetPnL | PF    | Drawdown | Expect | IC95 acerto | BE margem",
  );
  for (const id of STRATEGY_IDS) {
    const cfg = {
      ...defaultConfig(id),
      symbol,
      granularity,
      duration,
      durationUnit,
    };
    const bt = runBacktest(id, candles, cfg, { payout });
    const test = bt.segments.find((s) => s.label === "TESTE");
    const t = test ? roundMetrics(test.metrics) : roundMetrics(bt.aggregate);
    const ci = t.winRateCI ? `${t.winRateCI.low.toFixed(0)}–${t.winRateCI.high.toFixed(0)}` : "—";
    const margin = t.trades > 0 ? (t.winRate - breakEven).toFixed(1) : "—";
    console.log(
      `  ${STRATEGY_METADATA[id].name.padEnd(22)} | ${String(t.trades).padStart(9)} | ${t.winRate.toFixed(1).padStart(5)}% | ${t.netPnl.toFixed(2).padStart(6)} | ${fmtPf(t.profitFactor).padStart(5)} | ${t.maxDrawdownPct.toFixed(1).padStart(7)}% | ${t.expectancy.toFixed(3).padStart(6)} | ${ci.padStart(10)} | ${margin}%`,
    );
  }
}

async function main(): Promise<void> {
  const client = new DerivApiClient();
  const url = await client.getDemoWebSocketUrl();
  const ws = new WebSocketManager();
  await ws.connect(url);

  for (const { label, symbol } of FOREX) {
    console.log(`\n================ ${label} (${symbol}) ================`);

    const payout1d = await getPayout(ws, symbol, "CALL", 1, "d");
    const payout15m = await getPayout(ws, symbol, "CALL", 15, "m");
    console.log(`  Payout real: 1d=${payout1d ?? "n/d"} | 15m=${payout15m ?? "n/d"}`);

    if (payout1d != null) {
      await runScenario(ws, symbol, 1, "d", 3600, payout1d);
    }
    if (payout15m != null) {
      await runScenario(ws, symbol, 15, "m", 300, payout15m);
    }
  }

  await ws.close();
  console.log("\nOK: concluído.");
}

main().catch((e) => {
  console.error("FALHA GERAL:", e instanceof Error ? e.message : String(e));
  process.exit(1);
});
