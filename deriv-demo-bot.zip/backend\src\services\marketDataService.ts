import type { Candle } from "../types.js";
import type { WebSocketManager, WsMessage } from "../deriv/wsManager.js";
import { logger } from "../logger/index.js";

export interface CandleHistoryResponse {
  candles: Candle[];
}

/**
 * Valores de `granularity` aceitos pela API da Deriv (em SEGUNDOS).
 * Qualquer outro valor gera `InputValidationFailed: granularity`.
 */
export const ALLOWED_GRANULARITIES: number[] = [
  60, 120, 180, 300, 600, 900, 1800, 3600, 7200, 14400, 28800, 86400,
];

export class GranularityValidationError extends Error {
  constructor(message: string) {
    super(message);
    this.name = "GranularityValidationError";
  }
}

export function isValidGranularity(value: number): boolean {
  return Number.isInteger(value) && ALLOWED_GRANULARITIES.includes(value);
}

export function assertGranularity(value: number): void {
  if (!isValidGranularity(value)) {
    throw new GranularityValidationError(
      `granularity inválido: ${value}. Valores permitidos (segundos): ${ALLOWED_GRANULARITIES.join(", ")}.`,
    );
  }
}

/**
 * Converte minutos em segundos para uso como granularity de candles.
 * ATENÇÃO: use apenas sobre valores em MINUTOS; nunca sobre valores que já
 * estejam em segundos (isso causaria conversão duplicada).
 */
export function minutesToSeconds(minutes: number): number {
  return minutes * 60;
}

export async function fetchCandles(
  ws: WebSocketManager,
  symbol: string,
  granularity: number,
  count: number,
): Promise<Candle[]> {
  assertGranularity(granularity);
  logger.info("Carregando candles históricos", { symbol, granularity, count });
  const msg = await ws.request({
    ticks_history: symbol,
    style: "candles",
    granularity,
    count,
    end: "latest",
  });
  const raw = (msg as WsMessage).candles as
    | Array<{ epoch: number; open: number; high: number; low: number; close: number }>
    | undefined;
  if (!raw) {
    return [];
  }
  return raw
    .map((c) => ({
      time: c.epoch,
      open: c.open,
      high: c.high,
      low: c.low,
      close: c.close,
    }))
    .sort((a, b) => a.time - b.time);
}

export class CandleAggregator {
  private current: Candle | null = null;
  private readonly granularity: number;
  private onCloseHandler: ((candle: Candle) => void) | null = null;

  constructor(granularity: number, initial?: Candle) {
    this.granularity = granularity;
    if (initial) {
      // Continua construindo o candle em andamento a partir do último candle
      // histórico, evitando duplicar a mesma janela de tempo.
      this.current = { ...initial };
    }
  }

  onCandleClose(handler: (candle: Candle) => void): void {
    this.onCloseHandler = handler;
  }

  onTick(epoch: number, price: number): void {
    const bucket = Math.floor(epoch / this.granularity) * this.granularity;
    if (!this.current || bucket !== this.current.time) {
      if (this.current && this.onCloseHandler) {
        this.onCloseHandler(this.current);
      }
      this.current = { time: bucket, open: price, high: price, low: price, close: price };
      return;
    }
    if (price > this.current.high) {
      this.current.high = price;
    }
    if (price < this.current.low) {
      this.current.low = price;
    }
    this.current.close = price;
  }

  get currentCandle(): Candle | null {
    return this.current;
  }
}

export interface TickPrice {
  epoch: number;
  quote: number;
}

export async function fetchTickPrices(
  ws: WebSocketManager,
  symbol: string,
  count: number,
): Promise<TickPrice[]> {
  const msg = await ws.request({
    ticks_history: symbol,
    style: "ticks",
    count,
    end: "latest",
  });
  const history = (msg as WsMessage).history as
    | { prices?: number[]; times?: number[] }
    | undefined;
  const prices = history?.prices ?? [];
  const times = history?.times ?? [];
  const out: TickPrice[] = [];
  const len = Math.min(prices.length, times.length);
  for (let i = 0; i < len; i++) {
    const p = prices[i];
    const t = times[i];
    if (typeof p === "number" && Number.isFinite(p) && typeof t === "number") {
      out.push({ epoch: t, quote: p });
    }
  }
  return out.sort((a, b) => a.epoch - b.epoch);
}
