import type {
  Candle,
  IndicatorSnapshot,
  StrategyResult,
  MarketCondition,
  StrategyType,
  Signal,
  Decision,
  ConfirmationDetail,
} from "../types.js";
import { computeIndicators } from "./indicatorService.js";

export type { StrategyResult, MarketCondition, StrategyType, Signal, Decision } from "../types.js";

const CONFIG = {
  adxTrendMin: 25,
  adxRangeMax: 20,
  atrHighVolPct: 0.5,
  rsiOversold: 30,
  rsiOverbought: 70,
  rsiTrendLow: 50,
  rsiTrendHigh: 70,
  trendMinConfirmations: 4,
  reversionMinConfirmations: 3,
  reversionDistanceStd: 1.5,
};

function fmt(n: number): string {
  return n.toFixed(2);
}

function scoreOf(confirmed: number, total: number): number {
  if (total === 0) {
    return 0;
  }
  return Math.round((confirmed / total) * 100);
}

function buildResult(opts: {
  marketCondition: MarketCondition;
  strategy: StrategyType;
  signal: Signal;
  decision: Decision;
  score: number;
  confirmations: number;
  confirmationsTotal: number;
  details: ConfirmationDetail[];
  reason: string;
  indicators: IndicatorSnapshot;
  price: number | null;
}): StrategyResult {
  return { ...opts, timestamp: Date.now() };
}

function insufficientData(
  indicators: IndicatorSnapshot,
  price: number | null,
): StrategyResult {
  return buildResult({
    marketCondition: "INDEFINIDO",
    strategy: "NENHUMA",
    signal: "AGUARDAR",
    decision: "NAO_OPERAR",
    score: 0,
    confirmations: 0,
    confirmationsTotal: 0,
    details: [],
    reason:
      "AGUARDANDO — dados insuficientes para calcular os indicadores (necessário histórico de candles).",
    indicators,
    price,
  });
}

function evaluateTrend(
  direction: "ALTA" | "BAIXA",
  indicators: IndicatorSnapshot,
  price: number,
): StrategyResult {
  const { ema20, ema50, ema200, rsi14, adx } = indicators;
  const e20 = ema20 ?? 0;
  const e50 = ema50 ?? 0;
  const e200 = ema200 ?? 0;
  const rsi = rsi14 ?? 50;
  const a = adx ?? 0;
  const bullish = direction === "ALTA";

  const details: ConfirmationDetail[] = bullish
    ? [
        { label: "Preço acima da EMA 20", passed: price > e20 },
        { label: "EMA 20 acima da EMA 50", passed: e20 > e50 },
        { label: "EMA 50 acima da EMA 200", passed: e50 > e200 },
        {
          label: `RSI entre ${CONFIG.rsiTrendLow} e ${CONFIG.rsiTrendHigh}`,
          passed: rsi >= CONFIG.rsiTrendLow && rsi <= CONFIG.rsiTrendHigh,
        },
        { label: `ADX >= ${CONFIG.adxTrendMin}`, passed: a >= CONFIG.adxTrendMin },
      ]
    : [
        { label: "Preço abaixo da EMA 20", passed: price < e20 },
        { label: "EMA 20 abaixo da EMA 50", passed: e20 < e50 },
        { label: "EMA 50 abaixo da EMA 200", passed: e50 < e200 },
        {
          label: `RSI entre ${CONFIG.rsiOversold} e ${CONFIG.rsiTrendLow}`,
          passed: rsi >= CONFIG.rsiOversold && rsi <= CONFIG.rsiTrendLow,
        },
        { label: `ADX >= ${CONFIG.adxTrendMin}`, passed: a >= CONFIG.adxTrendMin },
      ];

  const confirmed = details.filter((d) => d.passed).length;
  const total = details.length;
  const score = scoreOf(confirmed, total);
  const decision: Decision =
    confirmed >= CONFIG.trendMinConfirmations ? "ENTRAR" : "AGUARDAR";
  const label = bullish ? "ALTA" : "BAIXA";
  const reason =
    decision === "ENTRAR"
      ? `ENTRAR (${label}) — ${confirmed}/${total} confirmações alinhadas. EMA 20 ${fmt(e20)}, EMA 50 ${fmt(e50)}, EMA 200 ${fmt(e200)}, RSI ${fmt(rsi)}, ADX ${fmt(a)}.`
      : `AGUARDAR — tendência de ${label} com ${confirmed}/${total} confirmações (mínimo ${CONFIG.trendMinConfirmations}).`;

  return buildResult({
    marketCondition: bullish ? "TENDENCIA_ALTA" : "TENDENCIA_BAIXA",
    strategy: "TENDENCIA",
    signal: direction,
    decision,
    score,
    confirmations: confirmed,
    confirmationsTotal: total,
    details,
    reason,
    indicators,
    price,
  });
}

function evaluateMeanReversion(
  indicators: IndicatorSnapshot,
  price: number,
): StrategyResult {
  const { rsi14, bollingerUpper, bollingerMiddle, bollingerLower } = indicators;
  const rsi = rsi14 ?? 50;
  const upper = bollingerUpper ?? price;
  const middle = bollingerMiddle ?? price;
  const lower = bollingerLower ?? price;
  const std = Math.max(upper - middle, Number.EPSILON) / 2;
  const distFromMean = (price - middle) / std;

  const callDetails: ConfirmationDetail[] = [
    { label: "Preço na/abaixo da banda inferior", passed: price <= lower },
    {
      label: `RSI <= ${CONFIG.rsiOversold} (sobrevendido)`,
      passed: rsi <= CONFIG.rsiOversold,
    },
    { label: "Preço abaixo da média", passed: price < middle },
    {
      label: `Distância da média <= -${CONFIG.reversionDistanceStd} desvios`,
      passed: distFromMean <= -CONFIG.reversionDistanceStd,
    },
  ];

  const putDetails: ConfirmationDetail[] = [
    { label: "Preço na/acima da banda superior", passed: price >= upper },
    {
      label: `RSI >= ${CONFIG.rsiOverbought} (sobrecomprado)`,
      passed: rsi >= CONFIG.rsiOverbought,
    },
    { label: "Preço acima da média", passed: price > middle },
    {
      label: `Distância da média >= +${CONFIG.reversionDistanceStd} desvios`,
      passed: distFromMean >= CONFIG.reversionDistanceStd,
    },
  ];

  const callConfirmed = callDetails.filter((d) => d.passed).length;
  const putConfirmed = putDetails.filter((d) => d.passed).length;
  const useCall = callConfirmed >= putConfirmed && callConfirmed > 0;
  const details = useCall ? callDetails : putDetails;
  const confirmed = useCall ? callConfirmed : putConfirmed;
  const total = details.length;
  const score = scoreOf(confirmed, total);
  const signal: Signal = confirmed === 0 ? "AGUARDAR" : useCall ? "ALTA" : "BAIXA";
  const decision: Decision =
    confirmed >= CONFIG.reversionMinConfirmations ? "ENTRAR" : "AGUARDAR";

  const sideLabel = confirmed === 0 ? "sem sinal" : useCall ? "ALTA" : "BAIXA";
  const reason =
    decision === "ENTRAR"
      ? `ENTRAR (${sideLabel}) — reversão à média com ${confirmed}/${total} confirmações (preço ${fmt(price)}, média ${fmt(middle)}, RSI ${fmt(rsi)}).`
      : `AGUARDAR — mercado lateral, ${confirmed}/${total} confirmações de reversão (${sideLabel}).`;

  return buildResult({
    marketCondition: "LATERAL",
    strategy: "REVERSAO_MEDIA",
    signal,
    decision,
    score,
    confirmations: confirmed,
    confirmationsTotal: total,
    details,
    reason,
    indicators,
    price,
  });
}

export function evaluateStrategy(candles: Candle[]): StrategyResult {
  const indicators = computeIndicators(candles);
  const last = candles.at(-1);
  const price = last ? last.close : null;
  const { ema20, ema50, ema200, rsi14, adx, atr, bollingerUpper, bollingerMiddle, bollingerLower } =
    indicators;

  const missing =
    price === null ||
    ema20 === null ||
    ema50 === null ||
    ema200 === null ||
    rsi14 === null ||
    adx === null ||
    atr === null ||
    bollingerUpper === null ||
    bollingerMiddle === null ||
    bollingerLower === null;

  if (missing) {
    return insufficientData(indicators, price);
  }

  const atrPct = (atr / price) * 100;
  if (atrPct >= CONFIG.atrHighVolPct) {
    return buildResult({
      marketCondition: "ALTA_VOLATILIDADE",
      strategy: "NENHUMA",
      signal: "AGUARDAR",
      decision: "NAO_OPERAR",
      score: 0,
      confirmations: 0,
      confirmationsTotal: 0,
      details: [],
      reason: `AGUARDANDO — condições de mercado inadequadas (ATR ${fmt(atrPct)}% do preço indica volatilidade excessiva).`,
      indicators,
      price,
    });
  }

  const uptrend =
    price > ema200 && ema20 > ema50 && ema50 > ema200 && adx >= CONFIG.adxTrendMin;
  const downtrend =
    price < ema200 && ema20 < ema50 && ema50 < ema200 && adx >= CONFIG.adxTrendMin;

  if (uptrend) {
    return evaluateTrend("ALTA", indicators, price);
  }
  if (downtrend) {
    return evaluateTrend("BAIXA", indicators, price);
  }

  if (adx < CONFIG.adxRangeMax) {
    return evaluateMeanReversion(indicators, price);
  }

  return buildResult({
    marketCondition: "INDEFINIDO",
    strategy: "NENHUMA",
    signal: "AGUARDAR",
    decision: "NAO_OPERAR",
    score: 0,
    confirmations: 0,
    confirmationsTotal: 0,
    details: [],
    reason:
      "AGUARDANDO — condições de mercado inadequadas (indicadores contraditórios; sem tendência nem lateral definido).",
    indicators,
    price,
  });
}
