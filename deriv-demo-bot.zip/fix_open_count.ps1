$content = Get-Content 'C:\Users\guigu\Downloads\Projetos\deriv-demo-bot\backend\src\strategies\runtime.ts' -Raw
$content = $content -replace 't\.status === "OPEN"', 't.status === "OPEN" || t.status === "PENDING"'
Set-Content 'C:\Users\guigu\Downloads\Projetos\deriv-demo-bot\backend\src\strategies\runtime.ts' -Value $content