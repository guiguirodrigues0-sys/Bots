import type { Candle } from "../../types.js";
import { BaseStrategy, makeSignal, insufficientSignal } from "../base.js";
import type {
  StrategyConfig,
  StrategyId,
  StrategySignal,
  StrategyCondition,
} from "../types.js";
import { rsiSeries, adxSeries, bollingerBands, last, num } from "../indicators.js";

/**
 * Estratégia 4 — Reversão à Média.
 * Movimentos excessivamente afastados da média (BB 20/2, RSI 14, ADX 14).
 */
export class ReversaoMediaStrategy extends BaseStrategy {
  readonly id: StrategyId = "REVERSAO_MEDIA";

  evaluateSignal(candles: Candle[], config: StrategyConfig): StrategySignal {
    const closes = candles.map((c) => c.close);
    const price = closes.at(-1) ?? null;
    if (price === null || closes.length < 2) {
      return insufficientSignal(this.id, price);
    }

    const bbPeriod = num(config.params, "bbPeriod", 20);
    const bbMult = num(config.params, "bbMult", 2);
    const rsi = last(rsiSeries(closes, num(config.params, "rsiPeriod", 14)));
    const adx = last(adxSeries(candles, num(config.params, "adxPeriod", 14)));
    const bb = bollingerBands(closes, bbPeriod, bbMult);

    const i = closes.length - 1;
    if (
      rsi === null ||
      adx === null ||
      bb.upper[i] == null ||
      bb.lower[i] == null ||
      bb.upper[i - 1] == null ||
      bb.lower[i - 1] == null
    ) {
      return insufficientSignal(this.id, price);
    }

    const rsiOversold = num(config.params, "rsiOversold", 45);
    const rsiOverbought = num(config.params, "rsiOverbought", 55);
    const adxMax = num(config.params, "adxMax", 20);

    const prevClose = closes[i - 1] ?? price;

    // Candle fechado retorna para DENTRO das bandas após ultrapassá-las.
    const wasBelow = prevClose < (bb.lower[i - 1] ?? 0);
    const backInsideFromBelow = price >= (bb.lower[i] ?? 0);
    const wasAbove = prevClose > (bb.upper[i - 1] ?? 0);
    const backInsideFromAbove = price <= (bb.upper[i] ?? 0);

    const buyConditions: StrategyCondition[] = [
      { label: "Preço ultrapassou a banda inferior", passed: wasBelow },
      { label: `RSI abaixo de ${rsiOversold}`, passed: rsi < rsiOversold },
      { label: `ADX abaixo de ${adxMax}`, passed: adx < adxMax },
      {
        label: "Candle fechou de volta dentro das bandas",
        passed: backInsideFromBelow,
      },
    ];

    const sellConditions: StrategyCondition[] = [
      { label: "Preço ultrapassou a banda superior", passed: wasAbove },
      { label: `RSI acima de ${rsiOverbought}`, passed: rsi > rsiOverbought },
      { label: `ADX abaixo de ${adxMax}`, passed: adx < adxMax },
      {
        label: "Candle fechou de volta dentro das bandas",
        passed: backInsideFromAbove,
      },
    ];

    const indicators = {
      rsi,
      adx,
      bollingerUpper: bb.upper[i] ?? null,
      bollingerLower: bb.lower[i] ?? null,
      bollingerMiddle: bb.middle[i] ?? null,
    };

    if (buyConditions.every((c) => c.passed)) {
      return makeSignal(
        this.id,
        "BUY",
        price,
        buyConditions,
        indicators,
        `SINAL BUY — reversão à média (RSI ${rsi.toFixed(1)}, ADX ${adx.toFixed(1)}).`,
      );
    }
    if (sellConditions.every((c) => c.passed)) {
      return makeSignal(
        this.id,
        "SELL",
        price,
        sellConditions,
        indicators,
        `SINAL SELL — reversão à média (RSI ${rsi.toFixed(1)}, ADX ${adx.toFixed(1)}).`,
      );
    }

    const shown = price < (bb.middle[i] ?? price) ? buyConditions : sellConditions;
    return makeSignal(
      this.id,
      "WAIT",
      price,
      shown,
      indicators,
      `AGUARDAR — sem reversão confirmada (RSI ${rsi.toFixed(1)}, ADX ${adx.toFixed(1)}).`,
      null,
      "NO_SIGNAL",
    );
  }
}
