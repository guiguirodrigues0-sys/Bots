import type { Candle } from "../../types.js";
import { BaseStrategy, makeSignal, insufficientSignal } from "../base.js";
import type {
  StrategyConfig,
  StrategyId,
  StrategySignal,
  StrategyCondition,
} from "../types.js";
import {
  emaSeries,
  adxSeries,
  macdSeries,
  crossedAbove,
  crossedBelow,
  last,
  num,
} from "../indicators.js";

/**
 * Estratégia 6 — MACD + ADX.
 * Momentum (MACD 12/26/9) confirmado por força (ADX 14) e tendência (EMA 50).
 */
export class MacdAdxStrategy extends BaseStrategy {
  readonly id: StrategyId = "MACD_ADX";

  evaluateSignal(candles: Candle[], config: StrategyConfig): StrategySignal {
    const closes = candles.map((c) => c.close);
    const price = closes.at(-1) ?? null;
    if (price === null || closes.length < 2) {
      return insufficientSignal(this.id, price);
    }

    const i = closes.length - 1;
    const macd = macdSeries(
      closes,
      num(config.params, "macdFast", 12),
      num(config.params, "macdSlow", 26),
      num(config.params, "macdSignal", 9),
    );
    const adx = last(adxSeries(candles, num(config.params, "adxPeriod", 14)));
    const ema50 = last(emaSeries(closes, num(config.params, "emaPeriod", 50)));

    if (
      adx === null ||
      ema50 === null ||
      macd.macd[i] == null ||
      macd.signal[i] == null
    ) {
      return insufficientSignal(this.id, price);
    }

    const adxMin = num(config.params, "adxMin", 25);

    const buyConditions: StrategyCondition[] = [
      {
        label: "MACD cruza acima da linha de sinal",
        passed: crossedAbove(macd.macd, macd.signal, i),
      },
      { label: `ADX acima de ${adxMin}`, passed: adx > adxMin },
      { label: "Preço acima da EMA 50", passed: price > ema50 },
    ];

    const sellConditions: StrategyCondition[] = [
      {
        label: "MACD cruza abaixo da linha de sinal",
        passed: crossedBelow(macd.macd, macd.signal, i),
      },
      { label: `ADX acima de ${adxMin}`, passed: adx > adxMin },
      { label: "Preço abaixo da EMA 50", passed: price < ema50 },
    ];

    const indicators = {
      macd: macd.macd[i] ?? null,
      signal: macd.signal[i] ?? null,
      adx,
      ema50,
    };

    if (buyConditions.every((c) => c.passed)) {
      return makeSignal(
        this.id,
        "BUY",
        price,
        buyConditions,
        indicators,
        `SINAL BUY — cruzamento MACD de alta com ADX ${adx.toFixed(1)}.`,
      );
    }
    if (sellConditions.every((c) => c.passed)) {
      return makeSignal(
        this.id,
        "SELL",
        price,
        sellConditions,
        indicators,
        `SINAL SELL — cruzamento MACD de baixa com ADX ${adx.toFixed(1)}.`,
      );
    }

    const shown =
      (macd.macd[i] ?? 0) >= (macd.signal[i] ?? 0) ? buyConditions : sellConditions;
    return makeSignal(
      this.id,
      "WAIT",
      price,
      shown,
      indicators,
      `AGUARDAR — sem cruzamento MACD válido (ADX ${adx.toFixed(1)}).`,
      null,
      "NO_SIGNAL",
    );
  }
}
