const path = require("node:path");

const root = path.resolve(__dirname, "..");
const appDir =
  process.env.PROTECTED_APP_DIR || path.join(root, ".protected-build", "app");
const outputDir =
  process.env.PROTECTED_OUTPUT_DIR || path.join(root, "release-protected");

const updateConfig = require(path.join(root, "electron", "update-config.cjs"));

module.exports = {
  appId: "com.deriv.autotrader",
  productName: "Deriv Auto Trader",
  copyright: "Deriv Auto Trader",
  publish: [
    {
      provider: "github",
      owner: updateConfig.owner,
      repo: updateConfig.repo,
    },
  ],
  directories: {
    app: appDir,
    output: outputDir,
    buildResources: path.join(root, "build"),
  },
  files: [
    "electron/**/*",
    "!electron/backend.mjs",
    "frontend/dist/**/*",
    "package.json",
  ],
  asar: true,
  win: {
    icon: path.join(root, "build", "icon.ico"),
    target: [
      {
        target: "nsis",
        arch: ["x64"],
      },
    ],
  },
  nsis: {
    oneClick: false,
    allowToChangeInstallationDirectory: true,
    createDesktopShortcut: true,
    createStartMenuShortcut: true,
    shortcutName: "Deriv Auto Trader",
    artifactName:
      process.env.PROTECTED_ARTIFACT_NAME ||
      "DerivAutoTrader-Setup-Protected-${version}.${ext}",
  },
};
