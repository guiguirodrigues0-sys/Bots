import { build } from "esbuild";

await build({
  entryPoints: ["electron/main.src.cjs"],
  bundle: true,
  platform: "node",
  format: "cjs",
  target: "node20",
  outfile: "electron/main.cjs",
  sourcemap: false,
  external: ["electron"],
  logLevel: "info",
});
