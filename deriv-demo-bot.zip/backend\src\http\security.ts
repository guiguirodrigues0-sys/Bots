import type { NextFunction, Request, Response } from "express";

const LOCAL_HOSTNAMES = new Set(["localhost", "127.0.0.1"]);

export function isAllowedOrigin(origin: string | undefined): boolean {
  if (origin === undefined) {
    return true;
  }
  try {
    const url = new URL(origin);
    return (
      (url.protocol === "http:" || url.protocol === "https:") &&
      LOCAL_HOSTNAMES.has(url.hostname)
    );
  } catch {
    return false;
  }
}

export function localOriginGuard(req: Request, res: Response, next: NextFunction): void {
  if (!isAllowedOrigin(req.headers.origin) || !LOCAL_HOSTNAMES.has(req.hostname)) {
    res.status(403).json({ ok: false, error: "Origem não permitida." });
    return;
  }
  next();
}
