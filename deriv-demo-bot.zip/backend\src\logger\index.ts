type Level = "debug" | "info" | "warn" | "error";

const ORDER: Record<Level, number> = {
  debug: 10,
  info: 20,
  warn: 30,
  error: 40,
};

const TOKEN_MASK_PATTERN = /(token|passcode|api[_-]?token)(["']?\s*[:=]\s*["']?)([\w.-]{8,})/gi;

export function maskSecrets(value: string): string {
  return value.replace(TOKEN_MASK_PATTERN, "$1$2[REDACTED]");
}

function shouldLog(level: Level): boolean {
  const raw = process.env.LOG_LEVEL;
  const configured: Level = ORDER[raw as Level] !== undefined ? (raw as Level) : "debug";
  return ORDER[level] >= ORDER[configured];
}

function emit(level: Level, message: string, meta?: unknown): void {
  if (!shouldLog(level)) return;
  const entry = {
    ts: new Date().toISOString(),
    level,
    message,
    ...(meta !== undefined ? { meta } : {}),
  };
  const line = maskSecrets(JSON.stringify(entry));
  if (level === "error") {
    console.error(line);
  } else {
    console.log(line);
  }
}

export const logger = {
  debug: (message: string, meta?: unknown) => emit("debug", message, meta),
  info: (message: string, meta?: unknown) => emit("info", message, meta),
  warn: (message: string, meta?: unknown) => emit("warn", message, meta),
  error: (message: string, meta?: unknown) => emit("error", message, meta),
};
