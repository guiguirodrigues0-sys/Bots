/**
 * Reconstrução financeira (estimada) das 8 estratégias sobre dados reais.
 * SOMENTE LEITURA. Usa o modelo Rise/Fall (payout fixo) — NÃO é backtest
 * financeiro fiel; separa desenvolvimento/validação/teste fora da amostra.
 */
import { DerivApiClient } from "../backend/src/deriv/apiClient.js";
import { WebSocketManager } from "../backend/src/deriv/wsManager.js";
import { fetchCandles } from "../backend/src/services/marketDataService.js";
import { runBacktest, roundMetrics } from "../backend/src/strategies/backtest.js";
import { defaultConfig, STRATEGY_IDS, STRATEGY_METADATA } from "../backend/src/strategies/definitions.js";

process.env.LOG_LEVEL = "error";

const SCENARIOS = [
  { label: "Volatility 100 (R_100)", symbol: "R_100", granularity: 60, duration: 30, durationUnit: "s" as const, count: 600 },
  { label: "EUR/USD", symbol: "frxEURUSD", granularity: 300, duration: 15, durationUnit: "m" as const, count: 513 },
];

async function main(): Promise<void> {
  const client = new DerivApiClient();
  const url = await client.getDemoWebSocketUrl();
  const ws = new WebSocketManager();
  await ws.connect(url);

  for (const sc of SCENARIOS) {
    const candles = await fetchCandles(ws, sc.symbol, sc.granularity, sc.count);
    console.log(`\n=== ${sc.label} | tf=${sc.granularity}s | candles=${candles.length} | payout=1.9 ===`);
    console.log(
      "  Estratégia            | Ops(TESTE) | Acerto | NetPnL | ProfitFactor | Drawdown | Expectancy",
    );
    for (const id of STRATEGY_IDS) {
      const cfg = {
        ...defaultConfig(id),
        symbol: sc.symbol,
        granularity: sc.granularity,
        duration: sc.duration,
        durationUnit: sc.durationUnit,
      };
      const bt = runBacktest(id, candles, cfg, { payout: 1.9 });
      const test = bt.segments.find((s) => s.label === "TESTE");
      const agg = roundMetrics(bt.aggregate);
      const t = test ? roundMetrics(test.metrics) : agg;
      const pf = Number.isFinite(t.profitFactor) ? t.profitFactor.toFixed(2) : "∞";
      console.log(
        `  ${STRATEGY_METADATA[id].name.padEnd(21)} | ${String(t.trades).padStart(9)} | ${t.winRate.toFixed(1).padStart(5)}% | ${t.netPnl.toFixed(2).padStart(7)} | ${pf.padStart(12)} | ${t.maxDrawdownPct.toFixed(1).padStart(6)}% | ${t.expectancy.toFixed(3).padStart(9)}`,
      );
    }
  }

  await ws.close();
  console.log("\nOK: concluído.");
}

main().catch((e) => {
  console.error("FALHA GERAL:", e instanceof Error ? e.message : String(e));
  process.exit(1);
});
