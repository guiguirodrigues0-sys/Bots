import type { AssetId, AssetInfo } from "../types.js";
import { WebSocketManager } from "./wsManager.js";
import type { WsMessage } from "./wsManager.js";
import { DerivApiClient } from "./apiClient.js";
import { logger } from "../logger/index.js";

export const ASSET_ORDER: AssetId[] = [
  "EURUSD",
  "GBPUSD",
  "R_10",
  "R_25",
  "R_50",
  "R_75",
  "R_100",
];

export const ASSET_LABELS: Record<AssetId, string> = {
  EURUSD: "EUR/USD",
  GBPUSD: "GBP/USD",
  R_10: "Volatility 10 Index",
  R_25: "Volatility 25 Index",
  R_50: "Volatility 50 Index",
  R_75: "Volatility 75 Index",
  R_100: "Volatility 100 Index",
};

const FALLBACK_SYMBOLS: Record<AssetId, string> = {
  EURUSD: "frxEURUSD",
  GBPUSD: "frxGBPUSD",
  R_10: "R_10",
  R_25: "R_25",
  R_50: "R_50",
  R_75: "R_75",
  R_100: "R_100",
};

const REQUIRED_CONTRACT_TYPE = "callput";

export interface ResolvedAsset {
  assetId: AssetId;
  label: string;
  symbol: string;
  available: boolean;
  contractTypes: string[];
  minDuration: string | null;
  maxDuration: string | null;
  minStake: number | null;
  maxStake: number | null;
}

function findSymbol(list: Record<string, any>[], code: string): string | null {
  for (const s of list) {
    if (!s || typeof s !== "object") continue;
    const sym = s.underlying_symbol ?? s.symbol;
    if (typeof sym === "string" && sym.toLowerCase().includes(code)) {
      return sym;
    }
  }
  return null;
}

async function contractsFor(ws: WebSocketManager, symbol: string): Promise<string[]> {
  const msg = await ws.request({ contracts_for: symbol });
  const cf = (msg as WsMessage).contracts_for as
    | { available?: Array<{ contract_category?: string; contracts?: string[] }> }
    | undefined;
  const categories = (cf?.available ?? []).map((a) => a.contract_category ?? "");
  return Array.from(new Set(categories.filter(Boolean)));
}

/**
 * Resolve o intervalo de duração (mínima/máxima) do contrato Rise/Fall (callput)
 * para um símbolo, considerando todas as entradas callput disponíveis.
 */
async function resolveCallputRange(
  ws: WebSocketManager,
  symbol: string,
): Promise<{ min: string | null; max: string | null }> {
  try {
    const msg = await ws.request({ contracts_for: symbol });
    const cf = (msg as WsMessage).contracts_for as
      | {
          available?: Array<{
            contract_category?: string;
            min_contract_duration?: string;
            max_contract_duration?: string;
          }>;
        }
      | undefined;
    const callput = (cf?.available ?? []).filter(
      (a) => a.contract_category === "callput",
    );
    let min: string | null = null;
    let max: string | null = null;
    for (const e of callput) {
      const mn = e.min_contract_duration ?? null;
      const mx = e.max_contract_duration ?? null;
      if (mn && (!min || durationToSeconds(mn) < durationToSeconds(min))) {
        min = mn;
      }
      if (mx && (!max || durationToSeconds(mx) > durationToSeconds(max))) {
        max = mx;
      }
    }
    return { min, max };
  } catch {
    return { min: null, max: null };
  }
}

export interface ContractAvailability {
  ok: boolean;
  reason: string;
}

export type DurationUnit = "s" | "m" | "h" | "d" | "t";

export interface ParsedDuration {
  n: number;
  unit: DurationUnit;
}

export function parseDuration(value: string): ParsedDuration | null {
  const m = /^(\d+)([smhdt])$/.exec(value);
  if (!m) {
    return null;
  }
  return { n: Number(m[1]), unit: m[2] as DurationUnit };
}

export function durationToSeconds(value: string): number {
  const parsed = parseDuration(value);
  if (!parsed) {
    return Number.NaN;
  }
  switch (parsed.unit) {
    case "s":
      return parsed.n;
    case "m":
      return parsed.n * 60;
    case "h":
      return parsed.n * 3600;
    case "d":
      return parsed.n * 86400;
    case "t":
      return Number.NaN;
    default:
      return Number.NaN;
  }
}

/** Rótulo curto de duração ("30 SEG", "5 MIN", "15 MIN", "2 H", "5 TICKS"). */
export function durationLabel(duration: number, unit: string): string {
  if (unit === "s") {
    return `${duration} SEG`;
  }
  if (unit === "m") {
    return `${duration} MIN`;
  }
  if (unit === "h") {
    return `${duration} H`;
  }
  if (unit === "t") {
    return `${duration} TICKS`;
  }
  return `${duration}${unit}`;
}

interface ContractDurationEntry {
  contract_category?: string;
  min_contract_duration?: string;
  max_contract_duration?: string;
}

/** Verifica se uma duração cabe em um intervalo min/max de contrato. */
function durationFitsEntry(
  entry: ContractDurationEntry,
  duration: number,
  unit: DurationUnit,
): boolean {
  const minParsed = parseDuration(entry.min_contract_duration ?? "");
  const maxParsed = parseDuration(entry.max_contract_duration ?? "");
  if (!minParsed || !maxParsed) {
    return false;
  }
  if (unit === "t") {
    return (
      minParsed.unit === "t" &&
      maxParsed.unit === "t" &&
      duration >= minParsed.n &&
      duration <= maxParsed.n
    );
  }
  const min = durationToSeconds(entry.min_contract_duration ?? "");
  const max = durationToSeconds(entry.max_contract_duration ?? "");
  const targetSeconds = durationToSeconds(`${duration}${unit}`);
  if (!Number.isFinite(min) || !Number.isFinite(max)) {
    return false;
  }
  return (
    Number.isFinite(targetSeconds) && targetSeconds >= min && targetSeconds <= max
  );
}

export async function checkContractAvailability(
  ws: WebSocketManager,
  symbol: string,
  contractCategory: string,
  duration: number,
  unit: DurationUnit,
): Promise<ContractAvailability> {
  const msg = await ws.request({ contracts_for: symbol });
  const available = (msg as WsMessage).contracts_for as
    | {
        available?: Array<{
          contract_category?: string;
          min_contract_duration?: string;
          max_contract_duration?: string;
        }>;
      }
    | undefined;
  const entries = (available?.available ?? []).filter(
    (a) => a.contract_category === contractCategory,
  );
  if (entries.length === 0) {
    return {
      ok: false,
      reason: `Contrato ${contractCategory} indisponível para ${symbol}.`,
    };
  }

  const fits = entries.some((a) => durationFitsEntry(a, duration, unit));
  if (!fits) {
    return {
      ok: false,
      reason: `Duração indisponível para ${symbol} no contrato ${contractCategory}.`,
    };
  }
  return { ok: true, reason: "OK" };
}

export interface ContractDurationOption {
  duration: number;
  unit: "s" | "m";
  label: string;
  available: boolean;
}

export interface ContractDurations {
  symbol: string;
  contractCategory: string;
  minDuration: string | null;
  maxDuration: string | null;
  options: ContractDurationOption[];
}

/**
 * Opções de duração desejadas para o seletor de contrato das 8 estratégias.
 * A disponibilidade de cada opção é validada contra a API (contracts_for).
 */
export const CONTRACT_DURATION_OPTIONS: Array<{ duration: number; unit: "s" | "m" }> = [
  { duration: 30, unit: "s" },
  { duration: 1, unit: "m" },
  { duration: 2, unit: "m" },
  { duration: 3, unit: "m" },
  { duration: 5, unit: "m" },
  { duration: 10, unit: "m" },
  { duration: 15, unit: "m" },
];

/**
 * Resolve, via `contracts_for`, quais das durações desejadas são realmente
 * aceitas pela API para o símbolo/categoria informados (ex.: Forex Rise/Fall
 * exige no mínimo 15 minutos). Não presume disponibilidade.
 */
export async function resolveContractDurations(
  ws: WebSocketManager,
  symbol: string,
  contractCategory: string,
): Promise<ContractDurations> {
  let entries: ContractDurationEntry[] = [];
  try {
    const msg = await ws.request({ contracts_for: symbol });
    const cf = (msg as WsMessage).contracts_for as
      | { available?: ContractDurationEntry[] }
      | undefined;
    entries = (cf?.available ?? []).filter(
      (a) => a.contract_category === contractCategory,
    );
  } catch (err) {
    logger.warn("Falha ao consultar contratos para durações", {
      symbol,
      message: err instanceof Error ? err.message : String(err),
    });
  }

  // Intervalo global time-based (ignorando ticks) para exibição ao usuário.
  let minDuration: string | null = null;
  let maxDuration: string | null = null;
  for (const e of entries) {
    const mn = e.min_contract_duration ?? null;
    const mx = e.max_contract_duration ?? null;
    if (!mn || !mx || mn.endsWith("t")) {
      continue;
    }
    if (!minDuration || durationToSeconds(mn) < durationToSeconds(minDuration)) {
      minDuration = mn;
    }
    if (!maxDuration || durationToSeconds(mx) > durationToSeconds(maxDuration)) {
      maxDuration = mx;
    }
  }

  const options = CONTRACT_DURATION_OPTIONS.map(({ duration, unit }) => ({
    duration,
    unit,
    label: durationLabel(duration, unit),
    available: entries.some((e) => durationFitsEntry(e, duration, unit)),
  }));

  return { symbol, contractCategory, minDuration, maxDuration, options };
}

/** Abre uma conexão DEMO e resolve as durações disponíveis (sem enviar ordens). */
export async function discoverContractDurations(
  symbol: string,
  contractCategory = "callput",
): Promise<ContractDurations> {
  const client = new DerivApiClient();
  const url = await client.getDemoWebSocketUrl();
  const ws = new WebSocketManager();
  await ws.connect(url);
  try {
    return await resolveContractDurations(ws, symbol, contractCategory);
  } finally {
    await ws.close();
  }
}

export async function resolveAssets(
  ws: WebSocketManager,
): Promise<Record<AssetId, ResolvedAsset>> {
  const result = {} as Record<AssetId, ResolvedAsset>;

  let list: Record<string, any>[] = [];
  try {
    const msg = await ws.request({ active_symbols: "full" });
    list = ((msg as WsMessage).active_symbols as Record<string, any>[]) ?? [];
  } catch (err) {
    logger.warn("Falha ao consultar active_symbols; usando fallback", {
      message: (err as Error).message,
    });
  }

  for (const id of ASSET_ORDER) {
    const label = ASSET_LABELS[id];
    const symbol = FALLBACK_SYMBOLS[id];

    let contractTypes: string[] = [];
    let available = false;
    let minDuration: string | null = null;
    let maxDuration: string | null = null;
    let minStake: number | null = null;
    let maxStake: number | null = null;
    try {
      contractTypes = await contractsFor(ws, symbol);
      available = contractTypes.includes(REQUIRED_CONTRACT_TYPE);
      const range = await resolveCallputRange(ws, symbol);
      minDuration = range.min;
      maxDuration = range.max;
      
      // Get stake limits for synthetic indices
      const msg = await ws.request({ contracts_for: symbol });
      const cf = (msg as WsMessage).contracts_for as
        | { available?: Array<{
          contract_category?: string;
          min_stake?: string | number;
          max_stake?: string | number;
        }> }
        | undefined;
      const callput = (cf?.available ?? []).find(
        (a) => a.contract_category === REQUIRED_CONTRACT_TYPE,
      );
      if (callput) {
        minStake = callput.min_stake != null ? Number(callput.min_stake) : null;
        maxStake = callput.max_stake != null ? Number(callput.max_stake) : null;
      }
    } catch (err) {
      logger.warn("Falha ao consultar contracts_for", {
        symbol,
        message: (err as Error).message,
      });
    }

    result[id] = {
      assetId: id,
      label,
      symbol,
      available,
      contractTypes,
      minDuration,
      maxDuration,
      minStake,
      maxStake,
    };
  }

  return result;
}

function toAssetInfo(r: ResolvedAsset): AssetInfo {
  return {
    assetId: r.assetId,
    label: r.label,
    symbol: r.symbol,
    available: r.available,
    contractTypes: r.contractTypes,
    minDuration: r.minDuration,
    maxDuration: r.maxDuration,
    minStake: r.minStake,
    maxStake: r.maxStake,
  };
}

export async function discoverAssets(): Promise<AssetInfo[]> {
  const client = new DerivApiClient();
  const url = await client.getDemoWebSocketUrl();
  const ws = new WebSocketManager();
  await ws.connect(url);
  try {
    const resolved = await resolveAssets(ws);
    return ASSET_ORDER.map((id) => toAssetInfo(resolved[id]));
  } finally {
    await ws.close();
  }
}

export interface ContractConstraints {
  category: string;
  minDuration: string | null;
  maxDuration: string | null;
  minStake: number | null;
  maxStake: number | null;
}

export interface StrategyContractValidation {
  ok: boolean;
  reason: string;
  constraints: ContractConstraints | null;
}

/**
 * Valida a compatibilidade de uma estratégia com a Deriv antes de operar:
 * contrato disponível, duração dentro do intervalo, stake dentro dos limites
 * e precisão decimal. O token/sessão DEMO já é garantido por
 * getDemoWebSocketUrl() + assertDemoUrl().
 */
export async function validateStrategyContract(
  ws: WebSocketManager,
  symbol: string,
  category: string,
  duration: number,
  unit: DurationUnit,
  stake: number,
): Promise<StrategyContractValidation> {
  const availability = await checkContractAvailability(
    ws,
    symbol,
    category,
    duration,
    unit,
  );
  if (!availability.ok) {
    return { ok: false, reason: availability.reason, constraints: null };
  }

  let constraints: ContractConstraints | null = null;
  try {
    const msg = await ws.request({ contracts_for: symbol });
    const available = (msg as WsMessage).contracts_for as
      | {
          available?: Array<{
            contract_category?: string;
            min_contract_duration?: string;
            max_contract_duration?: string;
            min_stake?: string | number;
            max_stake?: string | number;
          }>;
        }
      | undefined;
    const entry = (available?.available ?? []).find(
      (a) => a.contract_category === category,
    );
    if (entry) {
      constraints = {
        category,
        minDuration: entry.min_contract_duration ?? null,
        maxDuration: entry.max_contract_duration ?? null,
        minStake: entry.min_stake != null ? Number(entry.min_stake) : null,
        maxStake: entry.max_stake != null ? Number(entry.max_stake) : null,
      };
      if (constraints.minStake !== null && stake < constraints.minStake) {
        return {
          ok: false,
          reason: `Stake ${stake} abaixo do mínimo (${constraints.minStake}).`,
          constraints,
        };
      }
      if (constraints.maxStake !== null && stake > constraints.maxStake) {
        return {
          ok: false,
          reason: `Stake ${stake} acima do máximo (${constraints.maxStake}).`,
          constraints,
        };
      }
    }
  } catch (err) {
    logger.warn("Falha ao consultar limites de contrato", {
      symbol,
      message: (err as Error).message,
    });
  }

  return { ok: true, reason: "OK", constraints };
}

export interface ResolvedRapidAsset {
  symbol: string;
  available: boolean;
  contractTypes: string[];
}

export async function resolveRapidAsset(
  ws: WebSocketManager,
  symbol: string,
): Promise<ResolvedRapidAsset> {
  let contractTypes: string[] = [];
  try {
    contractTypes = await contractsFor(ws, symbol);
  } catch (err) {
    logger.warn("Falha ao consultar contracts_for", {
      symbol,
      message: (err as Error).message,
    });
  }
  return {
    symbol,
    available: contractTypes.includes(REQUIRED_CONTRACT_TYPE),
    contractTypes,
  };
}

// ------------------------------------------------------------ Índices sintéticos

export interface SyntheticIndexInfo {
  symbol: string;
  label: string;
  available: boolean;
  contractTypes: string[];
  minDuration: string | null;
  maxDuration: string | null;
  minStake: number | null;
  maxStake: number | null;
}

export const SYNTHETIC_INDICES: Array<{ symbol: string; label: string }> = [
  { symbol: "R_75", label: "Volatility 75 Index" },
  { symbol: "R_100", label: "Volatility 100 Index" },
  { symbol: "R_50", label: "Volatility 50 Index" },
  { symbol: "R_25", label: "Volatility 25 Index" },
  { symbol: "R_10", label: "Volatility 10 Index" },
];

interface CallputEntry {
  contract_category?: string;
  min_contract_duration?: string;
  max_contract_duration?: string;
  min_stake?: string | number;
  max_stake?: string | number;
}

/**
 * Resolve dinamicamente os índices sintéticos da Deriv (R_10, R_25, R_50,
 * R_75, R_100) consultando a API. Não assume que qualquer símbolo/contrato
 * esteja disponível.
 */
export async function resolveSyntheticIndices(
  ws: WebSocketManager,
): Promise<SyntheticIndexInfo[]> {
  const out: SyntheticIndexInfo[] = [];
  for (const { symbol, label } of SYNTHETIC_INDICES) {
    let contractTypes: string[] = [];
    let minDuration: string | null = null;
    let maxDuration: string | null = null;
    let minStake: number | null = null;
    let maxStake: number | null = null;
    try {
      const msg = await ws.request({ contracts_for: symbol });
      const cf = (msg as WsMessage).contracts_for as
        | { available?: CallputEntry[] }
        | undefined;
      contractTypes = Array.from(
        new Set((cf?.available ?? []).map((a) => a.contract_category ?? "").filter(Boolean)),
      );
      const callput = (cf?.available ?? []).find(
        (a) => a.contract_category === REQUIRED_CONTRACT_TYPE,
      );
      if (callput) {
        minDuration = callput.min_contract_duration ?? null;
        maxDuration = callput.max_contract_duration ?? null;
        minStake = callput.min_stake != null ? Number(callput.min_stake) : null;
        maxStake = callput.max_stake != null ? Number(callput.max_stake) : null;
      }
    } catch (err) {
      logger.warn("Falha ao consultar índice sintético", {
        symbol,
        message: (err as Error).message,
      });
    }
    out.push({
      symbol,
      label,
      available: contractTypes.includes(REQUIRED_CONTRACT_TYPE),
      contractTypes,
      minDuration,
      maxDuration,
      minStake,
      maxStake,
    });
  }
  return out;
}

export async function discoverSyntheticIndices(): Promise<SyntheticIndexInfo[]> {
  const client = new DerivApiClient();
  const url = await client.getDemoWebSocketUrl();
  const ws = new WebSocketManager();
  await ws.connect(url);
  try {
    return await resolveSyntheticIndices(ws);
  } finally {
    await ws.close();
  }
}
