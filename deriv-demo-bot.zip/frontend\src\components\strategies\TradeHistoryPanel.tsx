import { useEffect, useMemo, useState } from "react";
import { getTrades, durationLabel, type PersistedTrade } from "../../api/client";

const STRATEGY_NAMES: Record<string, string> = {
  CONFLUENCIA: "Confluência Inteligente",
  SCALPING: "Scalping EMA + RSI",
  TENDENCIA: "Seguidor de Tendência",
  REVERSAO_MEDIA: "Reversão à Média",
  ROMPIMENTO: "Rompimento de Volatilidade",
  MACD_ADX: "MACD + ADX",
  ADAPTATIVA: "Adaptativa",
  PRECISAO_EXTREMA: "Precisão Extrema",
  RAPID: "Rápido (legado)",
};

const MARKET_NAMES: Record<string, string> = {
  frxEURUSD: "EUR/USD",
  frxGBPUSD: "GBP/USD",
  R_75: "Volatility 75",
  R_100: "Volatility 100",
  R_50: "Volatility 50",
  R_25: "Volatility 25",
  R_10: "Volatility 10",
};

const PERIOD_MS: Record<string, number> = {
  "24h": 24 * 3600 * 1000,
  "7d": 7 * 24 * 3600 * 1000,
  "30d": 30 * 24 * 3600 * 1000,
  TUDO: 0,
};

function fmtMoney(v: number | null | undefined): string {
  if (v === null || v === undefined) return "—";
  const sign = v > 0 ? "+" : "";
  return `${sign}${v.toLocaleString("pt-BR", {
    minimumFractionDigits: 2,
    maximumFractionDigits: 2,
  })}`;
}

function fmtTime(ts: number | null | undefined): string {
  if (!ts) return "—";
  return new Date(ts).toLocaleString("pt-BR");
}

function dirLabel(d: string): string {
  if (d === "CALL" || d === "BUY") return "ALTA";
  if (d === "PUT" || d === "SELL") return "BAIXA";
  return d;
}

function dirClass(d: string): string {
  if (d === "CALL" || d === "BUY") return "signal-call";
  if (d === "PUT" || d === "SELL") return "signal-put";
  return "signal-aguardar";
}

function resultClass(r: string): string {
  if (r === "WIN") return "pos";
  if (r === "LOSS") return "neg";
  if (r === "PENDING") return "";
  return "muted";
}

function marketLabel(symbol: string): string {
  return MARKET_NAMES[symbol] ?? symbol;
}

function strategyLabel(s: string): string {
  return STRATEGY_NAMES[s] ?? s;
}

export default function TradeHistoryPanel() {
  const [trades, setTrades] = useState<PersistedTrade[]>([]);
  const [error, setError] = useState<string | null>(null);
  const [strategyFilter, setStrategyFilter] = useState("TODOS");
  const [marketFilter, setMarketFilter] = useState("TODOS");
  const [period, setPeriod] = useState("TUDO");

  useEffect(() => {
    let alive = true;
    const refresh = async () => {
      try {
        const t = await getTrades();
        if (alive) {
          setTrades(t);
          setError(null);
        }
      } catch (e) {
        if (alive) setError(e instanceof Error ? e.message : String(e));
      }
    };
    void refresh();
    const id = setInterval(() => void refresh(), 3000);
    return () => {
      alive = false;
      clearInterval(id);
    };
  }, []);

  const markets = useMemo(() => {
    const set = new Set(trades.map((t) => t.symbol));
    return Array.from(set).sort();
  }, [trades]);

  const filtered = useMemo(() => {
    let out = trades;
    if (strategyFilter !== "TODOS") out = out.filter((t) => t.strategy === strategyFilter);
    if (marketFilter !== "TODOS") out = out.filter((t) => t.symbol === marketFilter);
    const cutoff = PERIOD_MS[period] ?? 0;
    if (cutoff > 0) out = out.filter((t) => t.timestamp >= Date.now() - cutoff);
    return out.slice().reverse();
  }, [trades, strategyFilter, marketFilter, period]);

  const settled = useMemo(
    () => filtered.filter((t) => t.result === "WIN" || t.result === "LOSS"),
    [filtered],
  );

  const stats = useMemo(() => {
    const total = settled.length;
    const wins = settled.filter((t) => t.result === "WIN").length;
    const netPnl = settled.reduce((a, t) => a + (t.profitLoss ?? 0), 0);
    const payoutSum = settled.reduce((a, t) => a + (t.payout ?? 0), 0);
    const avgPayout = total > 0 ? payoutSum / total : 0;

    const chrono = settled.slice().sort((a, b) => a.timestamp - b.timestamp);
    let peak = 0;
    let cum = 0;
    let maxDD = 0;
    for (const t of chrono) {
      cum += t.profitLoss ?? 0;
      if (cum > peak) peak = cum;
      if (peak - cum > maxDD) maxDD = peak - cum;
    }

    return {
      total,
      wins,
      winRate: total > 0 ? (wins / total) * 100 : 0,
      netPnl,
      avgPayout,
      maxDD,
    };
  }, [settled]);

  return (
    <section className="panel">
      <header className="panel-head">
        <h2>Histórico de operações (DEMO)</h2>
        <span className="muted">{filtered.length} registro(s) · atualização automática</span>
      </header>

      <div className="summary">
        <div className="stat">
          <div className="stat-label">Operações liquidadas</div>
          <div className="stat-value">{stats.total}</div>
        </div>
        <div className="stat">
          <div className="stat-label">Taxa de acerto</div>
          <div className="stat-value">{stats.total > 0 ? `${stats.winRate.toFixed(1)}%` : "—"}</div>
        </div>
        <div className="stat">
          <div className="stat-label">Lucro líquido</div>
          <div className={`stat-value ${stats.netPnl >= 0 ? "pos" : "neg"}`}>
            {fmtMoney(stats.netPnl)}
          </div>
        </div>
        <div className="stat">
          <div className="stat-label">Payout médio</div>
          <div className="stat-value">{stats.total > 0 ? `${stats.avgPayout.toFixed(2)}x` : "—"}</div>
        </div>
        <div className="stat">
          <div className="stat-label">Drawdown máximo</div>
          <div className="stat-value neg">{fmtMoney(stats.maxDD)}</div>
        </div>
      </div>

      <div className="risk-grid" style={{ marginBottom: 12 }}>
        <div className="conn-field">
          <label>Estratégia</label>
          <select value={strategyFilter} onChange={(e) => setStrategyFilter(e.target.value)}>
            <option value="TODOS">Todas</option>
            {Object.entries(STRATEGY_NAMES).map(([id, name]) => (
              <option key={id} value={id}>
                {name}
              </option>
            ))}
          </select>
        </div>
        <div className="conn-field">
          <label>Mercado</label>
          <select value={marketFilter} onChange={(e) => setMarketFilter(e.target.value)}>
            <option value="TODOS">Todos</option>
            {markets.map((m) => (
              <option key={m} value={m}>
                {marketLabel(m)} ({m})
              </option>
            ))}
          </select>
        </div>
        <div className="conn-field">
          <label>Período</label>
          <select value={period} onChange={(e) => setPeriod(e.target.value)}>
            <option value="24h">Últimas 24h</option>
            <option value="7d">Últimos 7 dias</option>
            <option value="30d">Últimos 30 dias</option>
            <option value="TUDO">Tudo</option>
          </select>
        </div>
      </div>

      {error && (
        <div className="error-box">
          <p>{error}</p>
        </div>
      )}

      <table className="table">
        <thead>
          <tr>
            <th>Estratégia</th>
            <th>Mercado</th>
            <th>Horário</th>
            <th>Direção</th>
            <th>Stake</th>
            <th>Duração</th>
            <th>Timeframe</th>
            <th>Payout</th>
            <th>Resultado</th>
            <th>P/L</th>
          </tr>
        </thead>
        <tbody>
          {filtered.length === 0 ? (
            <tr className="empty">
              <td colSpan={10}>Nenhuma operação registrada.</td>
            </tr>
          ) : (
            filtered.map((t) => (
              <tr key={t.id}>
                <td>{strategyLabel(t.strategy)}</td>
                <td>{marketLabel(t.symbol)}</td>
                <td>{fmtTime(t.timestamp)}</td>
                <td>
                  <span className={`signal-badge ${dirClass(t.direction)}`}>
                    {dirLabel(t.direction)}
                  </span>
                </td>
                <td>{fmtMoney(t.stake)}</td>
                <td>{durationLabel(t.duration, t.durationUnit)}</td>
                <td>{t.granularity ? `${t.granularity}s` : "—"}</td>
                <td>{t.payout != null ? `${t.payout.toFixed(2)}x` : "—"}</td>
                <td className={resultClass(t.result)}>
                  {t.result === "PENDING" ? "PENDENTE" : t.result}
                </td>
                <td className={(t.profitLoss ?? 0) >= 0 ? "pos" : "neg"}>
                  {t.profitLoss !== null ? fmtMoney(t.profitLoss) : "—"}
                </td>
              </tr>
            ))
          )}
        </tbody>
      </table>

      <p className="notice muted">
        Somente conta DEMO. Registros persistidos em disco e reconciliados após liquidação
        (contratos pendentes são re-assinados após reinício).
      </p>
    </section>
  );
}
