import { getEnv } from "../config/env.js";
import { logger } from "../logger/index.js";
import { DerivApiClient } from "./apiClient.js";
import { WebSocketManager } from "./wsManager.js";

export interface ConnectionCheck {
  step: string;
  ok: boolean;
  detail: string;
}

export interface ConnectionTestResult {
  ok: boolean;
  checks: ConnectionCheck[];
  balance?: { balance: number; currency: string; loginid: string };
  symbol?: string;
  tick?: { quote: number; epoch: number; symbol: string };
  error?: string;
}

function timeout(ms: number): Promise<never> {
  return new Promise((_, reject) => {
    setTimeout(() => reject(new Error(`timeout de ${ms}ms`)), ms);
  });
}

export async function runConnectionTest(): Promise<ConnectionTestResult> {
  const checks: ConnectionCheck[] = [];
  const client = new DerivApiClient();
  const env = getEnv();
  let ws: WebSocketManager | null = null;
  const add = (step: string, ok: boolean, detail: string) =>
    checks.push({ step, ok, detail });

  try {
    add("API REST", true, "consultando GET /trading/v1/options/accounts");
    const accounts = await client.listAccounts();
    add(
      "Conta DEMO encontrada",
      accounts.some((a) => a.account_type === "demo"),
      `contas: [${accounts.map((a) => `${a.account_id} (${a.account_type})`).join(", ") || "nenhuma"}]`,
    );

    const demo = await client.findDemoAccount();
    add("Conta DEMO selecionada", true, `${demo.account_id} (${demo.currency})`);

    const url = await client.getDemoWebSocketUrl();
    add("OTP + ambiente DEMO validado", true, "URL aponta para /ws/demo");

    ws = new WebSocketManager();
    await ws.connect(url);
    add("WebSocket conectado", true, "conexão aberta");

    await ws.request({ ping: 1 });
    add("Heartbeat (ping/pong)", true, "pong recebido");

    const balanceMsg = await ws.request({ balance: 1 });
    const balance = balanceMsg.balance as {
      balance: number;
      currency: string;
      loginid: string;
    };
    add("Saldo", true, `${balance.balance} ${balance.currency} (${balance.loginid})`);

    const symbol = env.DERIV_SYMBOL;
    let gotTick = false;
    let tick: { quote: number; epoch: number; symbol: string } | undefined;
    ws.onMessage((msg) => {
      if (msg.msg_type === "tick" && msg.tick?.symbol === symbol && !gotTick) {
        gotTick = true;
        tick = {
          quote: msg.tick.quote,
          epoch: msg.tick.epoch,
          symbol: msg.tick.symbol,
        };
      }
    });
    await ws.request({ ticks: symbol, subscribe: 1 });
    await Promise.race([timeout(8000), new Promise<void>((r) => setInterval(() => gotTick && r(), 50))]);
    add(
      "Dados de mercado (ticks)",
      gotTick,
      gotTick ? `tick ${symbol} = ${tick?.quote}` : "nenhum tick recebido em 8s",
    );

    const ok = checks.every((c) => c.ok);
    return {
      ok,
      checks,
      balance: balance
        ? { balance: balance.balance, currency: balance.currency, loginid: balance.loginid }
        : undefined,
      symbol,
      tick,
    };
  } catch (err) {
    const message = err instanceof Error ? err.message : String(err);
    logger.error("Teste de conexão falhou", { message });
    add("Erro", false, message);
    return { ok: false, checks, error: message };
  } finally {
    if (ws) {
      await ws.close();
    }
  }
}
