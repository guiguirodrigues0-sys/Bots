import fs from "node:fs";
import path from "node:path";
import { logger } from "../logger/index.js";

/**
 * Registro persistido de uma operação (somente conta DEMO). Não contém tokens
 * nem credenciais — apenas dados de mercado, stake e resultado.
 */
export interface PersistedTrade {
  /** ID do contrato (contract_id da Deriv). */
  id: string;
  /** Horário de entrada (epoch ms). */
  timestamp: number;
  /** Horário de liquidação (epoch ms), ou null se ainda aberta. */
  settlementTime: number | null;
  symbol: string;
  direction: "CALL" | "PUT";
  /** Identificador da estratégia ("RAPID" para o módulo rápido). */
  strategy: string;
  contractType: "callput";
  duration: number;
  durationUnit: string;
  /** Timeframe dos candles usados na análise (segundos). */
  granularity: number | null;
  /** Valor solicitado (amount da proposta). */
  stake: number;
  /** Valor efetivamente cobrado (buy_price), se conhecido. */
  buyPrice: number | null;
  /** Preço de entrada (ask_price). */
  entryPrice: number;
  payout: number | null;
  result: "WIN" | "LOSS" | "PENDING" | "UNKNOWN";
  profitLoss: number | null;
  balanceAfter: number | null;
  entryType: "INITIAL" | "ACTIVE" | null;
  /** Motivo/razão do sinal (truncado). */
  reason: string | null;
}

const MAX_RECORDS = 2000;

function historyPath(): string {
  const dbPath = process.env.DB_PATH || "./data/deriv-demo-bot.db";
  const dir = path.dirname(dbPath);
  if (!fs.existsSync(dir)) {
    fs.mkdirSync(dir, { recursive: true });
  }
  const base = path.basename(dbPath).replace(/\.db$/i, "");
  return path.join(dir, `${base}-trades.json`);
}

function isValidTrade(value: unknown): value is PersistedTrade {
  if (!value || typeof value !== "object") {
    return false;
  }
  const t = value as Record<string, unknown>;
  return typeof t.id === "string" && typeof t.timestamp === "number";
}

/**
 * Persistência simples (JSON) do histórico de operações. O histórico fica em
 * memória durante a execução e é gravado a cada liquidação, evitando perda de
 * registros entre reinícios.
 */
export class TradeHistoryStore {
  private path = historyPath();
  private records: PersistedTrade[] = [];

  constructor() {
    this.records = this.load();
  }

  private load(): PersistedTrade[] {
    try {
      if (!fs.existsSync(this.path)) {
        return [];
      }
      const raw = JSON.parse(fs.readFileSync(this.path, "utf8")) as unknown;
      if (!Array.isArray(raw)) {
        return [];
      }
      return raw.filter(isValidTrade).slice(-MAX_RECORDS);
    } catch (err) {
      logger.warn("Falha ao carregar histórico de operações", {
        message: err instanceof Error ? err.message : String(err),
      });
      return [];
    }
  }

  append(record: PersistedTrade): void {
    this.records.push(record);
    if (this.records.length > MAX_RECORDS) {
      this.records = this.records.slice(-MAX_RECORDS);
    }
    this.save();
  }

  /** Retorna um registro pelo id (ou undefined). */
  get(id: string): PersistedTrade | undefined {
    const found = this.records.find((r) => r.id === id);
    return found ? { ...found } : undefined;
  }

  /**
   * Insere um registro novo ou substitui um existente com o mesmo id.
   * Evita duplicação de contratos/registros ao persistir.
   */
  upsert(record: PersistedTrade): void {
    const idx = this.records.findIndex((r) => r.id === record.id);
    if (idx >= 0) {
      this.records[idx] = { ...this.records[idx]!, ...record };
    } else {
      this.records.push(record);
      if (this.records.length > MAX_RECORDS) {
        this.records = this.records.slice(-MAX_RECORDS);
      }
    }
    this.save();
  }

  /**
   * Atualiza um registro existente pelo id. Retorna true se encontrou, false
   * caso contrário (o chamador pode então usar append).
   */
  update(id: string, patch: Partial<PersistedTrade>): boolean {
    const idx = this.records.findIndex((r) => r.id === id);
    if (idx < 0) {
      return false;
    }
    this.records[idx] = { ...this.records[idx]!, ...patch };
    this.save();
    return true;
  }

  list(): PersistedTrade[] {
    return this.records.map((r) => ({ ...r }));
  }

  /** Contratos ainda pendentes de liquidação (para reconciliação pós-reinício). */
  listPending(): PersistedTrade[] {
    return this.records.filter((r) => r.result === "PENDING").map((r) => ({ ...r }));
  }

  private save(): void {
    try {
      fs.writeFileSync(this.path, JSON.stringify(this.records, null, 2), "utf8");
    } catch (err) {
      logger.warn("Falha ao persistir histórico de operações", {
        message: err instanceof Error ? err.message : String(err),
      });
    }
  }
}

export const tradeHistoryStore = new TradeHistoryStore();
