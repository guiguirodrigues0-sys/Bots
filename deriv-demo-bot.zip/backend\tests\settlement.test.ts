import { test, beforeEach, after } from "node:test";
import assert from "node:assert/strict";
import fs from "node:fs";
import os from "node:os";
import path from "node:path";
import type { StrategySignal } from "../src/strategies/types.js";

// Importante: definir DB_PATH ANTES de importar qualquer módulo que crie o
// singleton tradeHistoryStore (storage/tradeHistory.ts), para que os testes
// nunca gravem no arquivo de dados real do projeto.
process.env.LOG_LEVEL = "error";
process.env.DERIV_ENVIRONMENT = "demo";
process.env.ALLOW_REAL_ACCOUNT = "false";

const tmpDir = fs.mkdtempSync(path.join(os.tmpdir(), "deriv-settlement-"));
process.env.DB_PATH = path.join(tmpDir, "bot.db");

const { StrategyRuntime } = await import("../src/strategies/runtime.js");
const { StrategyManager } = await import("../src/strategies/manager.js");
const { StrategyStore } = await import("../src/strategies/store.js");
const { tradeHistoryStore } = await import("../src/storage/tradeHistory.js");
const { TradeMonitor } = await import("../src/services/tradeMonitor.js");
const { contractIdParam } = await import("../src/services/tradeExecutor.js");

after(() => {
  fs.rmSync(tmpDir, { recursive: true, force: true });
});

// O singleton tradeHistoryStore é compartilhado entre os testes deste arquivo.
// Isola cada teste zerando os registros em memória (sem gravar no disco real).
beforeEach(() => {
  (tradeHistoryStore as unknown as { records: unknown[] }).records = [];
});

function makeRuntime() {
  const manager = new StrategyManager();
  manager.select("SCALPING");
  const store = new StrategyStore();
  const runtime = new StrategyRuntime(manager, store);
  const r = runtime as unknown as Record<string, any>;
  r.balance = 10000;
  r.currency = "USD";
  return { manager, store, runtime, r };
}

function pendingRecord(overrides: Partial<Record<string, unknown>> = {}) {
  return {
    id: "9007199254740993",
    timestamp: Date.now() - 16 * 60 * 1000,
    settlementTime: null,
    symbol: "frxEURUSD",
    direction: "CALL",
    strategy: "SCALPING",
    contractType: "callput",
    duration: 15,
    durationUnit: "m",
    granularity: 60,
    stake: 44.06,
    buyPrice: 44.06,
    entryPrice: 1.2345,
    payout: 1.9,
    result: "PENDING",
    profitLoss: null,
    balanceAfter: null,
    entryType: null,
    reason: null,
    ...overrides,
  } as const;
}

function signal(): StrategySignal {
  return {
    strategyId: "SCALPING",
    direction: "BUY",
    reasonCode: null,
    reason: "teste",
    timestamp: Date.now(),
    price: 1.2345,
    conditions: [],
    indicators: {},
    regime: null,
  };
}

// ----------------------------------------------------------- contract_id

test("contractIdParam preserva inteiros seguros como número", () => {
  assert.equal(contractIdParam("1234567890"), 1234567890);
  assert.equal(contractIdParam("0"), 0);
});

test("contractIdParam preserva IDs grandes como string (sem perda de precisão)", () => {
  const big = "9007199254740993"; // 2^53 + 1
  assert.equal(contractIdParam(big), big);
  assert.equal(typeof contractIdParam(big), "string");
});

// -------------------------------------------------------------- TradeMonitor

test("monitor: contrato aberto não emite settlement", () => {
  const tm = new TradeMonitor();
  let called = false;
  tm.onSettled(() => {
    called = true;
  });
  tm.handleMessage({
    proposal_open_contract: {
      contract_id: 1,
      is_sold: 0,
      status: "open",
      profit: "2",
      buy_price: "10",
    },
  });
  assert.equal(called, false);
});

test("monitor: status won emite WIN com buyPrice e profit extraídos", () => {
  const tm = new TradeMonitor();
  let out: unknown = null;
  tm.onSettled((s) => {
    out = s;
  });
  tm.handleMessage({
    proposal_open_contract: {
      contract_id: 42,
      is_sold: 1,
      status: "won",
      profit: "9.5",
      sell_price: "19.5",
      buy_price: "10",
    },
  });
  const s = out as {
    result: string;
    profitLoss: number;
    sellPrice: number | null;
    buyPrice: number | null;
  };
  assert.equal(s.result, "WIN");
  assert.equal(s.profitLoss, 9.5);
  assert.equal(s.sellPrice, 19.5);
  assert.equal(s.buyPrice, 10);
});

test("monitor: status lost emite LOSS", () => {
  const tm = new TradeMonitor();
  let out: unknown = null;
  tm.onSettled((s) => {
    out = s;
  });
  tm.handleMessage({
    proposal_open_contract: {
      contract_id: 43,
      is_sold: 1,
      status: "lost",
      sell_price: "0",
      buy_price: "10",
    },
  });
  const s = out as { result: string; profitLoss: number };
  assert.equal(s.result, "LOSS");
  assert.equal(s.profitLoss, -10);
});

test("monitor: status cancelled emite UNKNOWN (não inventa resultado)", () => {
  const tm = new TradeMonitor();
  let out: unknown = null;
  tm.onSettled((s) => {
    out = s;
  });
  tm.handleMessage({
    proposal_open_contract: {
      contract_id: 44,
      is_sold: 1,
      status: "cancelled",
    },
  });
  const s = out as { result: string };
  assert.equal(s.result, "UNKNOWN");
});

// ------------------------------------------------------------ TradeHistory

test("tradeHistoryStore.upsert não duplica registros com o mesmo id", () => {
  const rec = pendingRecord({ id: "dup1" }) as unknown as {
    id: string;
    result: string;
  };
  tradeHistoryStore.upsert(rec as never);
  tradeHistoryStore.upsert({ ...rec, result: "WIN" } as never);
  const all = tradeHistoryStore.list().filter((x: { id: string }) => x.id === "dup1");
  assert.equal(all.length, 1);
  assert.equal(all[0]?.result, "WIN");
});

test("tradeHistoryStore.get retorna cópia do registro", () => {
  tradeHistoryStore.upsert(pendingRecord({ id: "get1" }) as never);
  const found = tradeHistoryStore.get("get1");
  assert.equal(found?.id, "get1");
});

// ------------------------------------------------------------ restorePending

test("restorePendingTrades restaura TODOS os PENDING como PENDING (não OPEN)", () => {
  const { r } = makeRuntime();
  tradeHistoryStore.upsert(pendingRecord({ id: "restore1" }) as never);
  r.restorePendingTrades();
  assert.equal(r.openTrades.length, 1);
  assert.equal(r.openTrades[0].contractId, "restore1");
  assert.equal(r.openTrades[0].status, "PENDING");
  assert.equal(r.openTrades[0].durationSeconds, 15 * 60);
});

test("restorePendingTrades restaura TODOS os símbolos, não apenas o ativo", () => {
  const { r } = makeRuntime();
  tradeHistoryStore.upsert(pendingRecord({ id: "other1", symbol: "frxGBPUSD" }) as never);
  r.restorePendingTrades();
  assert.equal(r.openTrades.length, 1);
  assert.equal(r.openTrades[0].contractId, "other1");
  assert.equal(r.openTrades[0].status, "PENDING");
});

test("restorePendingTrades não duplica contrato já em memória", () => {
  const { r } = makeRuntime();
  tradeHistoryStore.upsert(pendingRecord({ id: "restore2" }) as never);
  r.restorePendingTrades();
  r.restorePendingTrades();
  assert.equal(r.openTrades.length, 1);
});

// ---------------------------------------------------------------- settlement

test("handleSettled WIN atualiza stats e persiste sem duplicar", () => {
  const { r } = makeRuntime();
  r.openTrades.push({
    contractId: "win1",
    proposalId: "p1",
    symbol: "frxEURUSD",
    strategyId: "SCALPING",
    direction: "CALL",
    stake: 44.06,
    entryTime: Date.now(),
    duration: 15,
    durationSeconds: 900,
    durationUnit: "m",
    askPrice: 1.2345,
    buyPrice: 44.06,
    payout: 1.9,
    status: "OPEN",
    profit: null,
  });
  tradeHistoryStore.upsert(pendingRecord({ id: "win1" }) as never);

  r.handleSettled({
    contractId: "win1",
    result: "WIN",
    profitLoss: 39.65,
    sellPrice: 83.71,
    buyPrice: 44.06,
    status: "won",
  });

  assert.equal(r.stats.trades, 1);
  assert.equal(r.stats.wins, 1);
  assert.equal(r.stats.losses, 0);
  assert.equal(r.stats.pnl, 39.65);
  assert.equal(r.openTrades[0].status, "SETTLED");
  assert.equal(r.openTrades[0].profit, 39.65);

  const persisted = tradeHistoryStore.get("win1");
  assert.equal(persisted?.result, "WIN");
  assert.equal(persisted?.profitLoss, 39.65);
  assert.ok(persisted?.settlementTime !== null);

  // Dupla entrega (streaming + re-consulta) não deve contabilizar novamente.
  r.handleSettled({
    contractId: "win1",
    result: "WIN",
    profitLoss: 39.65,
    sellPrice: 83.71,
    buyPrice: 44.06,
    status: "won",
  });
  assert.equal(r.stats.trades, 1);
  assert.equal(r.stats.wins, 1);
});

test("handleSettled LOSS incrementa perdas consecutivas", () => {
  const { r } = makeRuntime();
  r.openTrades.push({
    contractId: "loss1",
    proposalId: "p1",
    symbol: "frxEURUSD",
    strategyId: "SCALPING",
    direction: "PUT",
    stake: 44.06,
    entryTime: Date.now(),
    duration: 15,
    durationSeconds: 900,
    durationUnit: "m",
    askPrice: 1.2345,
    buyPrice: 44.06,
    payout: 1.9,
    status: "OPEN",
    profit: null,
  });
  tradeHistoryStore.upsert(pendingRecord({ id: "loss1", direction: "PUT" }) as never);

  r.handleSettled({
    contractId: "loss1",
    result: "LOSS",
    profitLoss: -44.06,
    sellPrice: 0,
    buyPrice: 44.06,
    status: "lost",
  });

  assert.equal(r.stats.trades, 1);
  assert.equal(r.stats.losses, 1);
  assert.equal(r.stats.wins, 0);
  assert.equal(r.stats.consecutiveLosses, 1);
  assert.equal(r.stats.pnl, -44.06);
});

test("handleSettled UNKNOWN não inventa resultado (nem WIN nem LOSS)", () => {
  const { r } = makeRuntime();
  r.openTrades.push({
    contractId: "unk1",
    proposalId: "p1",
    symbol: "frxEURUSD",
    strategyId: "SCALPING",
    direction: "CALL",
    stake: 44.06,
    entryTime: Date.now(),
    duration: 15,
    durationSeconds: 900,
    durationUnit: "m",
    askPrice: 1.2345,
    buyPrice: 44.06,
    payout: 1.9,
    status: "OPEN",
    profit: null,
  });
  tradeHistoryStore.upsert(pendingRecord({ id: "unk1" }) as never);

  r.handleSettled({
    contractId: "unk1",
    result: "UNKNOWN",
    profitLoss: 0,
    sellPrice: null,
    buyPrice: null,
    status: null,
  });

  assert.equal(r.stats.trades, 0);
  assert.equal(r.stats.wins, 0);
  assert.equal(r.stats.losses, 0);
  assert.equal(r.stats.pnl, 0);
  // Registrado no histórico persistente como UNKNOWN, nunca como LOSS.
  assert.equal(tradeHistoryStore.get("unk1")?.result, "UNKNOWN");
});

test("handleSettled reconcilia contrato pendente pós-reinício (sem posição em memória)", () => {
  const { r } = makeRuntime();
  tradeHistoryStore.upsert(pendingRecord({ id: "recon1" }) as never);

  // Nenhuma posição em memória (reinício). A liquidação chega via assinatura.
  r.handleSettled({
    contractId: "recon1",
    result: "LOSS",
    profitLoss: -44.06,
    sellPrice: 0,
    buyPrice: 44.06,
    status: "lost",
  });

  const persisted = tradeHistoryStore.get("recon1");
  assert.equal(persisted?.result, "LOSS");
  assert.equal(persisted?.profitLoss, -44.06);
  assert.ok(persisted?.settlementTime !== null);
  // Sem posição em memória, não deve contabilizar estatísticas da sessão.
  assert.equal(r.stats.trades, 0);
});

// ------------------------------------------------------------------ compra

test("placeTrade persiste compra confirmada como PENDING imediatamente", async () => {
  const { r } = makeRuntime();
  r.ws = { request: async () => ({}) };
  r.setExecutorForTesting({
    execute: async () => ({
      contractId: "buy1",
      proposalId: "p1",
      direction: "CALL",
      stake: 44.06,
      buyPrice: 44.06,
      askPrice: 1.2345,
      payout: 1.9,
      balanceAfter: 9955.94,
    }),
  });

  await r.placeTrade("SCALPING", signal(), "CALL", 44.06);

  assert.equal(r.openTrades.length, 1);
  assert.equal(r.openTrades[0].contractId, "buy1");
  const persisted = tradeHistoryStore.get("buy1");
  assert.equal(persisted?.result, "PENDING");
  assert.equal(persisted?.buyPrice, 44.06);
  assert.equal(persisted?.stake, 44.06);
  // Saldo sincronizado com balance_after confirmado pela API.
  assert.equal(r.balance, 9955.94);
});

test("divergência entre stake configurada e buy_price gera aviso e usa buy_price", async () => {
  const { r } = makeRuntime();
  r.ws = { request: async () => ({}) };
  r.setExecutorForTesting({
    execute: async () => ({
      contractId: "buy2",
      proposalId: "p2",
      direction: "CALL",
      stake: 44.06,
      buyPrice: 1, // Deriv cobrou apenas 1.00 — divergência real.
      askPrice: 1.2345,
      payout: 1.9,
      balanceAfter: 9999,
    }),
  });

  await r.placeTrade("SCALPING", signal(), "CALL", 44.06);

  assert.ok(String(r.lastEvent).includes("AVISO"), `esperava aviso, recebeu: ${r.lastEvent}`);
  const persisted = tradeHistoryStore.get("buy2");
  assert.equal(persisted?.stake, 44.06);
  assert.equal(persisted?.buyPrice, 1);
  // Exposição usa o valor efetivamente cobrado (buy_price=1), não a configurada
  // (stake=44.06). Com saldo ~9999, 1/9999*100 ≈ 0.010% (e não ~0.44%).
  const exposure = r.currentExposurePct();
  assert.ok(exposure < 0.02, `exposição deveria usar buy_price, recebeu ${exposure}%`);
});

test("segunda compra é bloqueada enquanto existir contrato com estado desconhecido", async () => {
  const { r } = makeRuntime();
  // Contrato pendente (estado desconhecido) restaurado do histórico.
  tradeHistoryStore.upsert(pendingRecord({ id: "blocked1" }) as never);
  r.restorePendingTrades();

  // O gerenciamento de risco conta a posição desconhecida (PENDING) como aberta.
  assert.equal(r.openTrades.filter((t: { status: string }) => t.status === "OPEN" || t.status === "PENDING").length, 1);
  const openCount = r.openTrades.filter((t) => t.status === "OPEN" || t.status === "PENDING").length;
  assert.ok(openCount >= 1, "posição desconhecida deve bloquear novas entradas");
});

test("contador em 00:00 re-consulta a API e liquida (não usa contador local)", async () => {
  const { r } = makeRuntime();
  const contractId = "expired1";
  tradeHistoryStore.upsert(pendingRecord({ id: contractId }) as never);
  r.openTrades.push({
    contractId,
    proposalId: "p1",
    symbol: "frxEURUSD",
    strategyId: "SCALPING",
    direction: "CALL",
    stake: 44.06,
    entryTime: Date.now() - 20 * 60 * 1000, // expirado há 5 min
    duration: 15,
    durationSeconds: 900,
    durationUnit: "m",
    askPrice: 1.2345,
    buyPrice: 44.06,
    payout: 1.9,
    status: "OPEN",
    profit: null,
  });
  // A API é a fonte da verdade: responde que o contrato venceu (won).
  r.ws = {
    isConnected: true,
    request: async () => ({
      proposal_open_contract: {
        contract_id: contractId,
        is_sold: 1,
        status: "won",
        profit: "39.65",
        sell_price: "83.71",
        buy_price: "44.06",
      },
    }),
  };

  await r.checkExpiredContracts();

  assert.equal(r.openTrades[0].status, "SETTLED");
  assert.equal(r.stats.wins, 1);
  assert.equal(tradeHistoryStore.get(contractId)?.result, "WIN");
});

test("streaming de proposal_open_contract liquida via monitor (fim a fim)", () => {
  const { r } = makeRuntime();
  tradeHistoryStore.upsert(pendingRecord({ id: "stream1" }) as never);
  r.restorePendingTrades();

  // Mensagem de streaming (sem req_id) simulando a assinatura ativa.
  r.monitor.handleMessage({
    proposal_open_contract: {
      contract_id: "stream1",
      is_sold: 1,
      status: "lost",
      sell_price: "0",
      buy_price: "44.06",
    },
  });

  assert.equal(r.openTrades[0].status, "SETTLED");
  assert.equal(r.stats.losses, 1);
  assert.equal(tradeHistoryStore.get("stream1")?.result, "LOSS");
});

test("alterar duração/config NÃO modifica contrato já aberto", async () => {
  const { manager, r } = makeRuntime();
  r.ws = { request: async () => ({}) };
  r.executor = {
    execute: async () => ({
      contractId: "freeze1",
      proposalId: "p1",
      direction: "CALL",
      stake: 44.06,
      buyPrice: 44.06,
      askPrice: 1.2345,
      payout: 1.9,
      balanceAfter: 9955.94,
    }),
  };

  await r.placeTrade("SCALPING", signal(), "CALL", 44.06);
  assert.equal(r.openTrades[0].duration, 1);
  assert.equal(r.openTrades[0].durationUnit, "m");
  assert.equal(r.openTrades[0].granularity, 60);

  // Altera a configuração da estratégia (duração e timeframe).
  manager.setConfig("SCALPING", { duration: 5, durationUnit: "m", granularity: 300 });

  // O contrato aberto mantém os valores capturados na entrada.
  assert.equal(r.openTrades[0].duration, 1);
  assert.equal(r.openTrades[0].durationUnit, "m");
  assert.equal(r.openTrades[0].granularity, 60);
});

// ------------------------------------------------------------ Auditoria: reconexão, contagem de posições, ausência de sinais, recuperação 502

test("reconexão automática após erro HTTP 502 no OTP", async () => {
  const api = new (await import("../src/deriv/apiClient.js")).DerivApiClient();
  let attempt = 0;
  const originalGetOtp = (api as any).getOtp.bind(api);
  (api as any).getOtp = async (accountId: string) => {
    attempt++;
    if (attempt === 1) {
      const err = new Error("POST /otp falhou (502): Bad Gateway");
      (err as any).status = 502;
      throw err;
    }
    return originalGetOtp(accountId);
  };

  const url = await api.getDemoWebSocketUrl();
  assert.equal(attempt, 2);
  assert.ok(url.startsWith("wss://"));
});

test("contagem de posições abertas ignora contratos SETTLED e de outros símbolos", () => {
  const { r } = makeRuntime();
  
  // Adiciona 3 contratos: 1 OPEN (símbolo atual), 1 SETTLED, 1 OPEN (outro símbolo)
  r.openTrades.push(
    { contractId: "c1", status: "OPEN", symbol: "frxEURUSD", strategyId: "SCALPING", direction: "CALL", stake: 10, entryTime: Date.now(), duration: 15, durationSeconds: 900, durationUnit: "m", askPrice: 1.1, buyPrice: 10, payout: 1.9, granularity: 60, profit: null },
    { contractId: "c2", status: "SETTLED", symbol: "frxEURUSD", strategyId: "SCALPING", direction: "PUT", stake: 10, entryTime: Date.now() - 10000, duration: 15, durationSeconds: 900, durationUnit: "m", askPrice: 1.1, buyPrice: 10, payout: 1.9, granularity: 60, profit: 5 },
    { contractId: "c3", status: "OPEN", symbol: "R_100", strategyId: "SCALPING", direction: "CALL", stake: 10, entryTime: Date.now(), duration: 30, durationSeconds: 30, durationUnit: "s", askPrice: 100, buyPrice: 10, payout: 1.9, granularity: 60, profit: null },
  );

  // A contagem de risco considera TODOS os open trades (comportamento atual)
  const openCountAll = r.openTrades.filter((t) => t.status === "OPEN").length;
  assert.equal(openCountAll, 2, "deve contar 2 posições abertas no total (todas as symbols)");

  // A exposição usa TODAS as posições abertas (comportamento atual)
  r.balance = 1000;
  const exposure = r.currentExposurePct();
  // (10 + 10) / 1000 * 100 = 2%
  assert.ok(exposure > 1.9 && exposure < 2.1, `exposição deveria ser ~2%, recebeu ${exposure}%`);
});

test("ausência legítima de sinais NÃO é tratada como erro ou bloqueio", async () => {
  const { r } = makeRuntime();
  r.state = "RUNNING";
  r.balance = 10000;
  r.currency = "USD";
  r.ws = { request: async () => ({}) };
  r.executor = { execute: async () => { throw new Error("não deve ser chamado"); } };
  r.manager.getActiveId = () => "SCALPING";
  r.manager.getConfig = () => ({ 
    symbol: "frxEURUSD", 
    contractType: "callput", 
    granularity: 60, 
    duration: 15, 
    durationUnit: "m", 
    stakeMode: "PERCENT", 
    stakePercent: 0.5, 
    fixedStake: null, 
    maxTrades: 0, 
    cooldownSeconds: 0, 
    params: {} 
  });
  r.manager.getInstance = () => ({ 
    validateConfig: () => ({ ok: true, errors: [] }), 
    onCandle: () => {}, 
    evaluateSignal: () => ({ direction: "WAIT", score: 0, reason: "aguardando cruzamento", timestamp: Date.now(), conditions: [], indicators: {}, regime: null }) 
  });
  
  const waitSignal: StrategySignal = { 
    direction: "WAIT", 
    score: 0, 
    confirmations: 0, 
    confirmationsTotal: 5, 
    reason: "aguardando cruzamento", 
    timestamp: Date.now(),
    strategyId: "SCALPING",
    reasonCode: null,
    conditions: [],
    indicators: {},
    regime: null,
    price: null,
  };
  
  // Sinal WAIT não deve gerar operação nem bloqueio
  r.decisionBlockReason = null;
  await r.evaluateAndMaybeTrade(waitSignal);
  
  assert.equal(r.decisionBlockReason, null, "WAIT não deve definir decisionBlockReason");
  assert.ok(!r.tradeInFlight, "tradeInFlight não deve ficar true");
});

test("recuperação completa após erro 502 transiente no OTP", async () => {
  const api = new (await import("../src/deriv/apiClient.js")).DerivApiClient();
  let attempt = 0;
  const originalGetOtp = (api as any).getOtp.bind(api);
  (api as any).getOtp = async (accountId: string) => {
    attempt++;
    if (attempt <= 2) {
      const err = new Error(`POST /otp falhou (${attempt === 1 ? 502 : 503}): ${attempt === 1 ? "Bad Gateway" : "Service Unavailable"}`);
      (err as any).status = attempt === 1 ? 502 : 503;
      throw err;
    }
    return originalGetOtp(accountId);
  };

  const url = await api.getDemoWebSocketUrl();
  assert.equal(attempt, 3);
  assert.ok(url.startsWith("wss://"));
});

test("API sem resposta exibe erro de sincronização e NÃO marca como perda", async () => {
  const { r } = makeRuntime();
  r.openTrades.push({
    contractId: "syncfail1",
    proposalId: "p1",
    symbol: "frxEURUSD",
    strategyId: "SCALPING",
    direction: "CALL",
    stake: 44.06,
    entryTime: Date.now() - 20 * 60 * 1000,
    duration: 15,
    durationSeconds: 900,
    durationUnit: "m",
    askPrice: 1.2345,
    buyPrice: 44.06,
    payout: 1.9,
    status: "OPEN",
    profit: null,
  });
  r.ws = {
    isConnected: true,
    request: async () => {
      throw new Error("timeout");
    },
  };

  await r.checkExpiredContracts();

  assert.ok(String(r.lastError).includes("sincronização"), `esperava erro, recebeu: ${r.lastError}`);
  assert.ok(String(r.lastEvent).includes("SINCRONIZAÇÃO"), `esperava evento, recebeu: ${r.lastEvent}`);
  // A posição permanece aberta; resultado NÃO é inventado como perda.
  assert.equal(r.openTrades[0].status, "OPEN");
  assert.equal(r.stats.losses, 0);
});

