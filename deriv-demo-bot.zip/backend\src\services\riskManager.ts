import type { SessionStats } from "../types.js";

export interface RiskConfig {
  defaultRiskPct: number;
  maxRiskPct: number;
  dailyStopPct: number;
  dailyTargetPct: number;
  maxConsecutiveLosses: number;
}

export const DEFAULT_RISK_CONFIG: RiskConfig = {
  defaultRiskPct: 0.5,
  maxRiskPct: 1.0,
  dailyStopPct: 5,
  dailyTargetPct: 5,
  maxConsecutiveLosses: 3,
};

export interface RiskDecision {
  ok: boolean;
  reason: string;
}

export interface RapidRiskConfig {
  maxOpenTrades: number;
  maxTotalExposurePct: number;
  activeRiskPct: number;
  initialRiskPct: number;
  maxConsecutiveLosses: number;
  dailyStopPct: number;
  dailyTargetPct: number;
}

export const DEFAULT_RAPID_RISK_CONFIG: RapidRiskConfig = {
  maxOpenTrades: 3,
  maxTotalExposurePct: 1.5,
  activeRiskPct: 0.25,
  initialRiskPct: 0.5,
  maxConsecutiveLosses: 3,
  dailyStopPct: 5,
  dailyTargetPct: 5,
};

export class RiskManager {
  private readonly config: RiskConfig;

  constructor(config: RiskConfig = DEFAULT_RISK_CONFIG) {
    this.config = config;
  }

  calculateStake(balance: number): number {
    const pct = Math.min(this.config.defaultRiskPct, this.config.maxRiskPct);
    const stake = (balance * pct) / 100;
    return Math.max(0, stake);
  }

  calculateStakeAt(balance: number, riskPct: number): number {
    const stake = (balance * riskPct) / 100;
    return Math.max(0, stake);
  }

  canTrade(stats: SessionStats, hasOpenTrade: boolean): RiskDecision {
    if (hasOpenTrade) {
      return { ok: false, reason: "Já existe uma operação aberta." };
    }
    if (stats.consecutiveLosses >= this.config.maxConsecutiveLosses) {
      return {
        ok: false,
        reason: `Limite de ${this.config.maxConsecutiveLosses} perdas consecutivas atingido — BOT PARADO.`,
      };
    }
    const pnlPct =
      stats.initialBalance > 0
        ? (stats.sessionPnL / stats.initialBalance) * 100
        : 0;
    if (pnlPct <= -this.config.dailyStopPct) {
      return {
        ok: false,
        reason: `Stop diário atingido (${pnlPct.toFixed(2)}%).`,
      };
    }
    if (pnlPct >= this.config.dailyTargetPct) {
      return {
        ok: false,
        reason: `Meta diária atingida (${pnlPct.toFixed(2)}%).`,
      };
    }
    return { ok: true, reason: "OK" };
  }
}

export interface RapidRiskInput {
  openCount: number;
  exposurePct: number;
  consecutiveLosses: number;
  pnlPct: number;
}

export function evaluateRapidRisk(
  input: RapidRiskInput,
  config: RapidRiskConfig = DEFAULT_RAPID_RISK_CONFIG,
): RiskDecision {
  if (input.openCount >= config.maxOpenTrades) {
    return {
      ok: false,
      reason: `Limite de ${config.maxOpenTrades} posições simultâneas atingido.`,
    };
  }
  if (input.exposurePct >= config.maxTotalExposurePct) {
    return {
      ok: false,
      reason: `Exposição máxima atingida (${input.exposurePct.toFixed(2)}%).`,
    };
  }
  if (input.consecutiveLosses >= config.maxConsecutiveLosses) {
    return {
      ok: false,
      reason: `Limite de ${config.maxConsecutiveLosses} perdas consecutivas atingido — BOT PARADO.`,
    };
  }
  if (input.pnlPct <= -config.dailyStopPct) {
    return {
      ok: false,
      reason: `Stop diário atingido (${input.pnlPct.toFixed(2)}%).`,
    };
  }
  if (input.pnlPct >= config.dailyTargetPct) {
    return {
      ok: false,
      reason: `Meta diária atingida (${input.pnlPct.toFixed(2)}%).`,
    };
  }
  return { ok: true, reason: "OK" };
}

const CURRENCY_DECIMALS: Record<string, number> = {
  USD: 2,
  EUR: 2,
  GBP: 2,
  AUD: 2,
  JPY: 0,
};

export function currencyDecimals(currency: string): number {
  return CURRENCY_DECIMALS[currency.toUpperCase()] ?? 2;
}

export function normalizeStake(amount: number, currency: string): number {
  const decimals = currencyDecimals(currency);
  const factor = 10 ** decimals;
  return Math.floor(amount * factor + 1e-8) / factor;
}

/**
 * Configuração de gerenciamento de risco global — compartilhada por TODAS as
 * estratégias. Nenhuma estratégia pode desativar ou ignorar estes limites.
 */
export interface StrategyRiskConfig {
  /** Modo da stake: percentual do saldo ou valor fixo. */
  stakeMode: "PERCENT" | "FIXED";
  /** Percentual do saldo (quando PERCENT). */
  stakePercent: number;
  /** Valor fixo (quando FIXED). */
  fixedStake: number;
  /** Limite máximo de perda diária (% do saldo inicial). */
  dailyStopPct: number;
  /** Meta diária opcional (% do saldo inicial). null = desativada. */
  dailyTargetPct: number | null;
  /** Limite máximo de exposição (% do saldo em posições abertas). */
  maxExposurePct: number;
  /** Limite de operações simultâneas. */
  maxOpenTrades: number;
  /** Cooldown (segundos) entre operações. */
  cooldownSeconds: number;
  /** Limite opcional de perdas consecutivas. null = desativado. */
  maxConsecutiveLosses: number | null;
}

export const DEFAULT_STRATEGY_RISK_CONFIG: StrategyRiskConfig = {
  stakeMode: "PERCENT",
  stakePercent: 0.5,
  fixedStake: 1,
  dailyStopPct: 5,
  dailyTargetPct: 5,
  maxExposurePct: 5,
  maxOpenTrades: 3,
  cooldownSeconds: 0,
  maxConsecutiveLosses: 3,
};

export interface StrategyRiskInput {
  openCount: number;
  exposurePct: number;
  consecutiveLosses: number;
  pnlPct: number;
  lastEntryAt: number | null;
  now: number;
}

export function evaluateStrategyRisk(
  input: StrategyRiskInput,
  config: StrategyRiskConfig = DEFAULT_STRATEGY_RISK_CONFIG,
): RiskDecision {
  if (input.openCount >= config.maxOpenTrades) {
    return {
      ok: false,
      reason: `Limite de ${config.maxOpenTrades} operações simultâneas atingido.`,
    };
  }
  if (input.exposurePct >= config.maxExposurePct) {
    return {
      ok: false,
      reason: `Exposição máxima atingida (${input.exposurePct.toFixed(2)}%).`,
    };
  }
  if (
    config.maxConsecutiveLosses !== null &&
    input.consecutiveLosses >= config.maxConsecutiveLosses
  ) {
    return {
      ok: false,
      reason: `Limite de ${config.maxConsecutiveLosses} perdas consecutivas atingido.`,
    };
  }
  if (input.pnlPct <= -config.dailyStopPct) {
    return {
      ok: false,
      reason: `Stop diário atingido (${input.pnlPct.toFixed(2)}%).`,
    };
  }
  if (
    config.dailyTargetPct !== null &&
    input.pnlPct >= config.dailyTargetPct
  ) {
    return {
      ok: false,
      reason: `Meta diária atingida (${input.pnlPct.toFixed(2)}%).`,
    };
  }
  if (
    config.cooldownSeconds > 0 &&
    input.lastEntryAt !== null &&
    input.now - input.lastEntryAt < config.cooldownSeconds * 1000
  ) {
    const remaining = Math.ceil(
      (config.cooldownSeconds * 1000 - (input.now - input.lastEntryAt)) / 1000,
    );
    return { ok: false, reason: `Cooldown (próxima entrada em ${remaining}s).` };
  }
  return { ok: true, reason: "OK" };
}

/**
 * Calcula a stake NORMALIZADA para uma estratégia. Nunca aumenta a stake
 * automaticamente para recuperar perdas (sem Martingale): a stake depende
 * apenas do saldo atual e da configuração.
 */
export function computeStrategyStake(
  balance: number,
  config: StrategyRiskConfig,
  currency: string,
): number {
  const raw =
    config.stakeMode === "FIXED"
      ? config.fixedStake
      : (balance * config.stakePercent) / 100;
  if (!Number.isFinite(raw) || raw <= 0) {
    return 0;
  }
  return normalizeStake(raw, currency);
}

/**
 * Resolve a stake EFETIVA de uma estratégia combinando a configuração
 * individual (fonte primária) com o teto GLOBAL de risco. O teto global
 * prevalece quando for mais restritivo — uma estratégia nunca pode operar
 * com stake acima do permitido globalmente.
 */
export function computeEffectiveStrategyStake(
  balance: number,
  strategyConfig: {
    stakeMode: "PERCENT" | "FIXED";
    stakePercent: number | null;
    fixedStake: number | null;
  },
  globalConfig: StrategyRiskConfig,
  currency: string,
): number {
  const strategyRaw =
    strategyConfig.stakeMode === "FIXED"
      ? (strategyConfig.fixedStake ?? 0)
      : (balance * (strategyConfig.stakePercent ?? 0)) / 100;
  const globalRaw =
    globalConfig.stakeMode === "FIXED"
      ? globalConfig.fixedStake
      : (balance * globalConfig.stakePercent) / 100;
  const raw = Math.min(strategyRaw, globalRaw);
  if (!Number.isFinite(raw) || raw <= 0) {
    return 0;
  }
  return normalizeStake(raw, currency);
}

/**
 * Cooldown efetivo: o mais restritivo (maior) entre a configuração global e a
 * individual da estratégia.
 */
export function effectiveCooldownSeconds(
  globalConfig: StrategyRiskConfig,
  strategyCooldownSeconds: number,
): number {
  return Math.max(globalConfig.cooldownSeconds, strategyCooldownSeconds);
}
