import { test, afterEach } from "node:test";
import assert from "node:assert/strict";
import {
  TradeExecutor,
  ContractUnavailableError,
} from "../src/services/tradeExecutor.js";
import type { WebSocketManager } from "../src/deriv/wsManager.js";

process.env.LOG_LEVEL = "error";

const originalFetch = globalThis.fetch;

afterEach(() => {
  (globalThis as unknown as { fetch: unknown }).fetch = originalFetch;
});

function mockDemoAccount() {
  (globalThis as unknown as { fetch: unknown }).fetch = async () => ({
    ok: true,
    status: 200,
    json: async () => ({
      data: [{ account_id: "D1", account_type: "demo", currency: "USD", balance: "10000" }],
    }),
    text: async () =>
      JSON.stringify({
        data: [{ account_id: "D1", account_type: "demo", currency: "USD", balance: "10000" }],
      }),
    headers: { get: () => null },
  });
}

const CONTRACTS_30S = {
  available: [
    { contract_category: "callput", min_contract_duration: "15s", max_contract_duration: "1d" },
    { contract_category: "callput", min_contract_duration: "1t", max_contract_duration: "10t" },
  ],
};

function scriptedWs(script: { contracts?: unknown; buy?: unknown }) {
  const calls: Array<Record<string, unknown>> = [];
  const ws = {
    request: async (payload: Record<string, unknown>) => {
      calls.push(payload);
      if (payload.contracts_for !== undefined) {
        return { contracts_for: script.contracts ?? { available: [] } };
      }
      if (payload.buy !== undefined) {
        return script.buy ?? {};
      }
      throw new Error("requisição inesperada no mock");
    },
  };
  return { calls, ws: ws as unknown as WebSocketManager };
}

async function run(
  ws: WebSocketManager,
  symbol: string,
  direction: "CALL" | "PUT",
  duration: number,
  unit: "s" | "m",
  stake = 2,
) {
  const executor = new TradeExecutor();
  return executor.execute(ws, symbol, direction, stake, duration, unit, "USD");
}

test("buy usa buy=1 e parameters com contract_type/duration/symbol", async () => {
  mockDemoAccount();
  const { calls, ws } = scriptedWs({
    contracts: CONTRACTS_30S,
    buy: { buy: { contract_id: 987654, buy_price: 2, payout: "1.90", balance_after: 9998 } },
  });

  const trade = await run(ws, "R_100", "CALL", 30, "s", 2);

  const buyCall = calls.find((c) => c.buy !== undefined);
  assert.equal(buyCall?.buy, "1");
  assert.equal(buyCall?.price, 2);
  const params = buyCall?.parameters as Record<string, unknown>;
  assert.equal(params?.contract_type, "CALL");
  assert.equal(params?.underlying_symbol, "R_100");
  assert.equal(params?.duration, 30);
  assert.equal(params?.duration_unit, "s");
  assert.equal(params?.basis, "stake");
  assert.equal(params?.amount, 2);

  assert.equal(trade.contractId, "987654");
  assert.equal(trade.buyPrice, 2);
});

test("PUT gera parameters.contract_type PUT", async () => {
  mockDemoAccount();
  const { calls, ws } = scriptedWs({
    contracts: CONTRACTS_30S,
    buy: { buy: { contract_id: 111, buy_price: 1 } },
  });

  await run(ws, "R_100", "PUT", 30, "s");
  const buyCall = calls.find((c) => c.buy !== undefined);
  const params = buyCall?.parameters as Record<string, unknown>;
  assert.equal(params?.contract_type, "PUT");
  assert.equal(params?.underlying_symbol, "R_100");
  assert.equal(params?.duration_unit, "s");
});

test("R_100 CALL 30s gera parameters.duration_unit s", async () => {
  mockDemoAccount();
  const { calls, ws } = scriptedWs({
    contracts: CONTRACTS_30S,
    buy: { buy: { contract_id: 222, buy_price: 1 } },
  });

  await run(ws, "R_100", "CALL", 30, "s");
  const buyCall = calls.find((c) => c.buy !== undefined);
  const params = buyCall?.parameters as Record<string, unknown>;
  assert.equal(params?.contract_type, "CALL");
  assert.equal(params?.underlying_symbol, "R_100");
  assert.equal(params?.duration, 30);
  assert.equal(params?.duration_unit, "s");
});

test("contrato indisponível não gera buy", async () => {
  mockDemoAccount();
  const { calls, ws } = scriptedWs({
    contracts: { available: [] },
    buy: {},
  });

  await assert.rejects(
    () => run(ws, "frxEURUSD", "CALL", 15, "m"),
    ContractUnavailableError,
  );
  assert.equal(calls.some((c) => c.buy !== undefined), false);
});

test("buy recusada (sem contract_id) lança erro", async () => {
  mockDemoAccount();
  const { calls, ws } = scriptedWs({
    contracts: CONTRACTS_30S,
    buy: { buy: {} },
  });

  await assert.rejects(() => run(ws, "R_100", "CALL", 30, "s"));
  assert.equal(calls.some((c) => c.buy !== undefined), true);
});
