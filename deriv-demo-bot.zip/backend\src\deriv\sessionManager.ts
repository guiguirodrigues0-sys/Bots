import {
  DerivApiClient,
  AuthExpiredError,
  AUTH_EXPIRED_MESSAGE,
  type DerivAccount,
} from "./apiClient.js";
import { WebSocketManager } from "./wsManager.js";
import { resolveRapidAsset } from "./symbols.js";
import { setActiveCredentials } from "./credentials.js";
import { getEnv } from "../config/env.js";
import { logger } from "../logger/index.js";

export type SessionStatus = "DISCONNECTED" | "CONNECTING" | "CONNECTED" | "ERROR";

export interface PublicSession {
  status: SessionStatus;
  connected: boolean;
  accountId: string | null;
  accountType: string | null;
  currency: string | null;
  virtualBalance: number | null;
  appId: string | null;
  tokenMasked: string | null;
  error: string | null;
}

export class ConnectionError extends Error {
  constructor(message: string) {
    super(message);
    this.name = "ConnectionError";
  }
}

interface SessionDeps {
  createClient: (appId: string, token: string) => DerivApiClient;
  createWs: () => WebSocketManager;
}

const DEFAULT_DEPS: SessionDeps = {
  createClient: (appId, token) => new DerivApiClient({ appId, token }),
  createWs: () => new WebSocketManager(),
};

const TOKEN_MASK = "••••••••••••••••";

export function sanitizeSecrets(message: string, secrets: string[]): string {
  let out = message;
  for (const s of secrets) {
    if (s && s.length > 0) {
      out = out.split(s).join("[REDACTED]");
    }
  }
  return out;
}

export class DerivSessionManager {
  private readonly deps: SessionDeps;
  private status: SessionStatus = "DISCONNECTED";
  private error: string | null = null;
  private appId: string | null = null;
  private apiToken: string | null = null;
  private accountId: string | null = null;
  private accountType: string | null = null;
  private currency: string | null = null;
  private virtualBalance: number | null = null;

  constructor(deps?: Partial<SessionDeps>) {
    this.deps = { ...DEFAULT_DEPS, ...deps };
  }

  get isConnected(): boolean {
    return this.status === "CONNECTED";
  }

  getPublic(): PublicSession {
    return {
      status: this.status,
      connected: this.status === "CONNECTED",
      accountId: this.accountId,
      accountType: this.accountType,
      currency: this.currency,
      virtualBalance: this.virtualBalance,
      appId: this.appId,
      tokenMasked: this.apiToken ? TOKEN_MASK : null,
      error: this.error,
    };
  }

  hasCredentials(): boolean {
    if (this.isConnected) {
      return true;
    }
    return Boolean(process.env.DERIV_APP_ID && process.env.DERIV_API_TOKEN);
  }

  canConnect(botState: string): { ok: boolean; reason?: string } {
    if (botState !== "STOPPED") {
      return { ok: false, reason: "Pare o bot antes de trocar as credenciais." };
    }
    return { ok: true };
  }

  async disconnectIfSafe(
    hasOpenTrade: boolean,
  ): Promise<{ ok: boolean; reason?: string }> {
    if (hasOpenTrade) {
      return {
        ok: false,
        reason:
          "Existe uma operação DEMO em andamento. Aguarde a finalização da operação antes de desconectar.",
      };
    }
    await this.disconnect();
    return { ok: true };
  }

  async connect(
    appId: string | undefined,
    token: string | undefined,
  ): Promise<PublicSession> {
    const app = (appId ?? "").trim();
    const tok = (token ?? "").trim();
    if (!app) {
      throw new ConnectionError("App ID inválido.");
    }
    if (!tok) {
      throw new ConnectionError("Token inválido.");
    }
    if (this.status === "CONNECTING") {
      throw new ConnectionError("Conexão já em andamento.");
    }

    this.status = "CONNECTING";
    this.error = null;

    let ws: WebSocketManager | null = null;
    try {
      const client = this.deps.createClient(app, tok);

      let accounts: DerivAccount[];
      try {
        accounts = await client.listAccounts();
      } catch (e) {
        const msg = e instanceof Error ? e.message : String(e);
        if (
          e instanceof AuthExpiredError ||
          msg.includes("401") ||
          msg.includes("403")
        ) {
          throw new ConnectionError(AUTH_EXPIRED_MESSAGE);
        }
        throw new ConnectionError("Não foi possível autenticar.");
      }

      const demo = accounts.find((a) => a.account_type === "demo");
      const hasReal = accounts.some((a) => a.account_type === "real");
      if (!demo) {
        if (hasReal) {
          throw new ConnectionError(
            "CONEXÃO BLOQUEADA — este protótipo funciona exclusivamente com contas DEMO.",
          );
        }
        throw new ConnectionError("Não foi possível confirmar conta DEMO.");
      }

      const url = await client.getDemoWebSocketUrl();

      ws = this.deps.createWs();
      await ws.connect(url);

      const balanceMsg = await ws.request({ balance: 1 });
      const balance = balanceMsg.balance as
        | { balance: number; currency: string }
        | undefined;
      if (!balance) {
        throw new ConnectionError("Não foi possível obter o saldo virtual.");
      }

      const resolved = await resolveRapidAsset(ws, getEnv().RAPID_SYMBOL);
      if (!resolved.available) {
        throw new ConnectionError(
          `${getEnv().RAPID_SYMBOL} indisponível para esta conta (sem contrato Rise/Fall).`,
        );
      }

      this.appId = app;
      this.apiToken = tok;
      this.accountId = demo.account_id;
      this.accountType = "demo";
      this.currency = balance.currency;
      this.virtualBalance = balance.balance;
      this.status = "CONNECTED";
      this.error = null;
      setActiveCredentials({ appId: app, token: tok });
      logger.info("Sessão Deriv DEMO conectada", {
        accountId: demo.account_id,
        currency: balance.currency,
      });
      return this.getPublic();
    } catch (e) {
      const raw = e instanceof Error ? e.message : String(e);
      const msg = sanitizeSecrets(raw, [tok]);
      this.status = "ERROR";
      this.error = msg;
      setActiveCredentials(null);
      throw new ConnectionError(msg);
    } finally {
      if (ws) {
        await ws.close();
      }
    }
  }

  async disconnect(): Promise<void> {
    setActiveCredentials(null);
    this.appId = null;
    this.apiToken = null;
    this.accountId = null;
    this.accountType = null;
    this.currency = null;
    this.virtualBalance = null;
    this.error = null;
    this.status = "DISCONNECTED";
    logger.info("Sessão Deriv desconectada");
  }
}

export const derivSession = new DerivSessionManager();
