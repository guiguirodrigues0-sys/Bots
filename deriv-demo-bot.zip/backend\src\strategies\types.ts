import type { Candle } from "../types.js";

export type StrategyId =
  | "CONFLUENCIA"
  | "SCALPING"
  | "TENDENCIA"
  | "REVERSAO_MEDIA"
  | "ROMPIMENTO"
  | "MACD_ADX"
  | "ADAPTATIVA"
  | "PRECISAO_EXTREMA";

export type StrategyProfile = "CONSERVADOR" | "MODERADO" | "AGRESSIVO";

export type SignalFrequency = "BAIXA" | "MEDIA" | "ALTA";

export type StrategyDirection = "BUY" | "SELL" | "WAIT";

/**
 * Motivos padronizados do fluxo de sinal/execução.
 *
 * Códigos usados na avaliação da estratégia (motivo de NÃO gerar sinal):
 * - INSUFFICIENT_CANDLES: histórico insuficiente para calcular indicadores.
 * - INVALID_INDICATOR: indicador calculado resultou em null/NaN/Infinity.
 * - NO_SIGNAL: estratégia avaliada normalmente, porém critérios não atendidos.
 *
 * Códigos usados quando um sinal é bloqueado ou rejeitado no runtime:
 * - WAITING_CANDLE_CLOSE, MARKET_CLOSED, CONTRACT_UNAVAILABLE, INVALID_DURATION,
 *   INVALID_STAKE, RISK_BLOCKED, COOLDOWN_ACTIVE, POSITION_ALREADY_OPEN,
 *   DERIV_API_ERROR, CONNECTION_EXPIRED, PROPOSAL_REJECTED.
 */
export type StrategyReasonCode =
  | "INSUFFICIENT_CANDLES"
  | "INVALID_INDICATOR"
  | "NO_SIGNAL"
  | "WAITING_CANDLE_CLOSE"
  | "MARKET_CLOSED"
  | "CONTRACT_UNAVAILABLE"
  | "INVALID_DURATION"
  | "INVALID_STAKE"
  | "RISK_BLOCKED"
  | "COOLDOWN_ACTIVE"
  | "POSITION_ALREADY_OPEN"
  | "DERIV_API_ERROR"
  | "CONNECTION_EXPIRED"
  | "PROPOSAL_REJECTED";

export type MarketRegime = "TENDENCIA" | "LATERAL" | "INDEFINIDO";

export type DurationUnit = "s" | "m" | "h" | "t";

export interface StrategyCondition {
  label: string;
  passed: boolean;
}

/**
 * Sinal estruturado devolvido por qualquer estratégia.
 * Inclui motivo, timestamp, id da estratégia, dados utilizados
 * (indicadores) e as condições atendidas.
 */
export interface StrategySignal {
  strategyId: StrategyId;
  direction: StrategyDirection;
  /** Motivo padronizado (motivo de NÃO gerar sinal, ou null quando há sinal). */
  reasonCode: StrategyReasonCode | null;
  reason: string;
  timestamp: number;
  price: number | null;
  conditions: StrategyCondition[];
  indicators: Record<string, number | null>;
  regime: MarketRegime | null;
}

export interface StrategyConfig {
  /** Símbolo subjacente (ex.: "frxEURUSD", "frxGBPUSD", "R_100"). */
  symbol: string;
  /** Categoria de contrato compatível (Rise/Fall). */
  contractType: "callput";
  /** Timeframe dos candles em segundos (granularidade). */
  granularity: number;
  /** Duração do contrato. */
  duration: number;
  durationUnit: DurationUnit;
  /** Stake fixa (quando stakeMode = FIXED). */
  fixedStake: number | null;
  /** Stake percentual do saldo (quando stakeMode = PERCENT). */
  stakePercent: number | null;
  /** Modo da stake: percentual ou fixa. */
  stakeMode: "PERCENT" | "FIXED";
  /** Número máximo de operações por ativação. 0 = ilimitado. */
  maxTrades: number;
  /** Cooldown (segundos) entre sinais. */
  cooldownSeconds: number;
  /** Parâmetros específicos de cada estratégia. */
  params: Record<string, number | boolean | string>;
}

export interface StrategyStatus {
  active: boolean;
  candleCount: number;
  lastDirection: StrategyDirection;
  lastSignalAt: number | null;
  reason: string | null;
  error: string | null;
}

export interface StrategyMetadata {
  id: StrategyId;
  name: string;
  description: string;
  indicators: string[];
  profile: StrategyProfile;
  frequency: SignalFrequency;
  markets: string[];
  /** Taxa de acerto histórica (somente quando houver dados reais). */
  winRate: number | null;
  /** Resultado líquido histórico (somente quando houver dados reais). */
  netResult: number | null;
}

/**
 * Interface padronizada de estratégia. Nenhuma estratégia envia ordens
 * diretamente — apenas gera sinais para o StrategyManager/Runtime.
 */
export interface Strategy {
  readonly id: StrategyId;
  initialize(): void;
  validateConfig(config: StrategyConfig): { ok: boolean; errors: string[] };
  onCandle(candle: Candle): void;
  evaluateSignal(candles: Candle[], config: StrategyConfig): StrategySignal;
  getStatus(): StrategyStatus;
  reset(): void;
  dispose(): void;
}

export interface StrategySwitchRecord {
  timestamp: number;
  from: StrategyId | null;
  to: StrategyId;
  reason: string;
}

export interface RegimeSwitchRecord {
  timestamp: number;
  from: MarketRegime;
  to: MarketRegime;
}

export interface RejectedSignalRecord {
  timestamp: number;
  strategyId: StrategyId;
  direction: StrategyDirection;
  reason: string;
  reasonCode: StrategyReasonCode;
}
