export interface ActiveCredentials {
  appId: string;
  token: string;
}

let active: ActiveCredentials | null = null;

export function setActiveCredentials(creds: ActiveCredentials | null): void {
  active = creds;
}

export function getActiveCredentials(): ActiveCredentials | null {
  return active;
}
