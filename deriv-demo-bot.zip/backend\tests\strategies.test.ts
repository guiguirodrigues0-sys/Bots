import { test } from "node:test";
import assert from "node:assert/strict";
import type { Candle } from "../src/types.js";
import {
  macdSeries,
  crossedAbove,
  crossedBelow,
  emaSparse,
  highestHigh,
  lowestLow,
  aggregateHigherTimeframe,
} from "../src/strategies/indicators.js";
import { createStrategy } from "../src/strategies/registry.js";
import { defaultConfig, STRATEGY_IDS } from "../src/strategies/definitions.js";
import type { StrategyId } from "../src/strategies/types.js";

process.env.LOG_LEVEL = "error";

function uptrend(n: number, start = 100, step = 0.02): Candle[] {
  const out: Candle[] = [];
  let close = start;
  for (let i = 0; i < n; i++) {
    const open = close;
    close = open + step + (i % 4) * 0.005;
    const high = close + step;
    const low = open - step;
    out.push({ time: i * 60, open, high, low, close });
  }
  return out;
}

function downtrend(n: number, start = 100, step = 0.02): Candle[] {
  const out: Candle[] = [];
  let close = start;
  for (let i = 0; i < n; i++) {
    const open = close;
    close = open - step - (i % 4) * 0.005;
    const high = open + step;
    const low = close - step;
    out.push({ time: i * 60, open, high, low, close });
  }
  return out;
}

// ---- Indicadores ----

test("emaSparse ignora null e mantém o índice", () => {
  const series: (number | null)[] = [null, null, 1, 2, 3, 4, 5];
  const out = emaSparse(series, 3);
  assert.equal(out[0], null);
  assert.notEqual(out[4], null);
});

test("macdSeries produz macd, signal e histogram com comprimento correto", () => {
  const closes = uptrend(80, 100, 0.01).map((c) => c.close);
  const m = macdSeries(closes, 12, 26, 9);
  assert.equal(m.macd.length, closes.length);
  assert.equal(m.signal.length, closes.length);
  assert.equal(m.histogram.length, closes.length);
  assert.notEqual(m.macd.at(-1), null);
  assert.notEqual(m.signal.at(-1), null);
});

test("crossedAbove/Below detectam cruzamento", () => {
  assert.equal(crossedAbove([1, 2, 3], [2, 2, 2], 2), true);
  assert.equal(crossedBelow([3, 2, 1], [2, 2, 2], 2), true);
  assert.equal(crossedAbove([3, 2, 1], [2, 2, 2], 2), false);
});

test("highestHigh/lowestLow usam apenas candles anteriores", () => {
  const candles = uptrend(10, 100, 1);
  const hi = highestHigh(candles, 5, 9);
  const lo = lowestLow(candles, 5, 9);
  assert.equal(hi, candles[8]?.high);
  assert.equal(lo, candles[4]?.low);
});

test("aggregateHigherTimeframe agrupa candles em timeframe superior", () => {
  const candles = uptrend(12, 100, 1);
  const htf = aggregateHigherTimeframe(candles, 4);
  assert.equal(htf.length, 3);
  assert.equal(htf[0]?.time, candles[0]?.time);
  assert.equal(htf[0]?.open, candles[0]?.open);
  // Close do bucket = close do último candle do grupo.
  assert.equal(htf[0]?.close, candles[3]?.close);
});

// ---- Estratégias: dados insuficientes + forma do sinal ----

const DIRECTIONAL: StrategyId[] = [
  "CONFLUENCIA",
  "SCALPING",
  "TENDENCIA",
  "MACD_ADX",
  "ROMPIMENTO",
  "PRECISAO_EXTREMA",
];

for (const id of STRATEGY_IDS) {
  test(`${id}: candles vazios retornam WAIT`, () => {
    const strategy = createStrategy(id);
    const signal = strategy.evaluateSignal([], defaultConfig(id));
    assert.equal(signal.direction, "WAIT");
    assert.equal(signal.strategyId, id);
    assert.ok(signal.reason.length > 0);
    assert.equal(typeof signal.timestamp, "number");
  });

  test(`${id}: sinal possui campos obrigatórios`, () => {
    const strategy = createStrategy(id);
    const signal = strategy.evaluateSignal(uptrend(300), defaultConfig(id));
    assert.ok(["BUY", "SELL", "WAIT"].includes(signal.direction));
    assert.ok(signal.strategyId === id);
    assert.ok(Array.isArray(signal.conditions));
    assert.ok(typeof signal.indicators === "object");
    assert.ok(signal.timestamp > 0);
  });
}

for (const id of DIRECTIONAL) {
  test(`${id}: tendência de alta nunca gera SELL`, () => {
    const strategy = createStrategy(id);
    const signal = strategy.evaluateSignal(uptrend(300), defaultConfig(id));
    assert.notEqual(signal.direction, "SELL");
  });

  test(`${id}: tendência de baixa nunca gera BUY`, () => {
    const strategy = createStrategy(id);
    const signal = strategy.evaluateSignal(downtrend(300), defaultConfig(id));
    assert.notEqual(signal.direction, "BUY");
  });
}

// ---- Estratégias específicas ----

test("CONFLUENCIA: expõe EMA 9/21/200, RSI e ADX", () => {
  const strategy = createStrategy("CONFLUENCIA");
  const signal = strategy.evaluateSignal(uptrend(300), defaultConfig("CONFLUENCIA"));
  assert.ok("ema9" in signal.indicators);
  assert.ok("ema21" in signal.indicators);
  assert.ok("ema200" in signal.indicators);
  assert.ok("rsi" in signal.indicators);
  assert.ok("adx" in signal.indicators);
});

test("SCALPING: dados curtos retornam WAIT sem cruzar", () => {
  const strategy = createStrategy("SCALPING");
  const signal = strategy.evaluateSignal(uptrend(10), defaultConfig("SCALPING"));
  assert.equal(signal.direction, "WAIT");
});

test("ROMPIMENTO: sem histórico suficiente retorna WAIT", () => {
  const strategy = createStrategy("ROMPIMENTO");
  const signal = strategy.evaluateSignal(uptrend(10), defaultConfig("ROMPIMENTO"));
  assert.equal(signal.direction, "WAIT");
});

test("ADAPTATIVA: expõe regime e não gera SELL em alta forte", () => {
  const strategy = createStrategy("ADAPTATIVA");
  const signal = strategy.evaluateSignal(uptrend(300), defaultConfig("ADAPTATIVA"));
  assert.notEqual(signal.direction, "SELL");
  assert.ok(signal.regime !== null);
});

test("PRECISAO_EXTREMA: expõe exatamente 9 confirmações", () => {
  const strategy = createStrategy("PRECISAO_EXTREMA");
  const signal = strategy.evaluateSignal(uptrend(400), defaultConfig("PRECISAO_EXTREMA"));
  assert.equal(signal.conditions.length, 9);
  assert.ok(["BUY", "SELL", "WAIT"].includes(signal.direction));
});

// ---- Validação de config ----

test("config com duração zero é inválida", () => {
  const strategy = createStrategy("CONFLUENCIA");
  const config = defaultConfig("CONFLUENCIA");
  config.duration = 0;
  const result = strategy.validateConfig(config);
  assert.equal(result.ok, false);
  assert.ok(result.errors.length > 0);
});

test("config padrão é válida para todas as estratégias", () => {
  for (const id of STRATEGY_IDS) {
    const strategy = createStrategy(id);
    const result = strategy.validateConfig(defaultConfig(id));
    assert.equal(result.ok, true, `${id} deveria ser válida`);
  }
});
