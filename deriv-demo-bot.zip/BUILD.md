# Deriv Auto Trader — Build & Distribuição

Guia do **desenvolvedor** para rodar, empacotar e distribuir o aplicativo desktop
(Windows). O aplicativo opera **exclusivamente em conta DEMO** (dinheiro virtual).

## Requisitos

- Node.js >= 22.5
- npm
- Windows (para gerar o instalador `.exe`)

## Desenvolvimento (web, rápido)

Roda backend + frontend separados (Vite com proxy):

```bash
npm install
npm run dev:backend     # terminal 1 — backend em 127.0.0.1:3001
npm run dev:frontend    # terminal 2 — Vite em 5173
```

## Desenvolvimento (desktop, Electron)

Empacota o backend (esbuild) + frontend e abre a janela do Electron:

```bash
npm run dev:electron
```

## Gerar o instalador Windows

```bash
npm run dist:win
```

O que acontece:

1. Gera o ícone (`build/icon.png`).
2. Empacota o backend em um único arquivo (`electron/backend.mjs`) via esbuild.
3. Compila o frontend (`frontend/dist`).
4. Usa `electron-builder` (NSIS) para produzir o instalador.

Saída:

```
release/Deriv Auto Trader-Setup-0.1.0.exe
```

Basta enviar esse `.exe` ao cliente.

Para gerar apenas a pasta desempacotada (sem instalador, útil para testes):

```bash
npm run pack:win
```

## Testes

```bash
npm run typecheck
npm test
npm run build
```

## Onde ficam os dados locais

No aplicativo instalado, os dados ficam no diretório de dados do usuário
(`app.getPath("userData")`):

```
%APPDATA%/Deriv Auto Trader/deriv-demo-bot.db
```

O instalador **não** apaga esse diretório em atualizações normais.

## Credenciais

- O App ID e o Token **não** são embutidos no executável.
- O cliente informa App ID + Token DEMO pelo painel do aplicativo.
- O Token permanece **somente em memória** durante a execução e é descartado ao fechar.
- Nenhum `.env`, token ou credencial é incluído no pacote.

## Atualizar a versão

Edite o campo `version` em `package.json` (ex.: `0.1.0` → `0.2.0`) e rode novamente:

```bash
npm run dist:win
```

O nome do instalador inclui a versão automaticamente.
