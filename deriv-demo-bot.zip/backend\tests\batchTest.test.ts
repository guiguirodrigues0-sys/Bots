import { test } from "node:test";
import assert from "node:assert/strict";
import { runBatchTestOnCandles } from "../src/strategies/batchTest.js";
import { resolveSyntheticIndices } from "../src/deriv/symbols.js";
import type { WebSocketManager } from "../src/deriv/wsManager.js";
import type { Candle } from "../src/types.js";

process.env.LOG_LEVEL = "error";

function candles(n: number, step = 0.02): Candle[] {
  const out: Candle[] = [];
  let close = 100;
  for (let i = 0; i < n; i++) {
    const open = close;
    close = open + step + (i % 5) * 0.003;
    out.push({ time: i * 60, open, high: close + 0.01, low: open - 0.01, close });
  }
  return out;
}

function flat(n: number): Candle[] {
  const out: Candle[] = [];
  for (let i = 0; i < n; i++) {
    out.push({ time: i * 60, open: 100, high: 100, low: 100, close: 100 });
  }
  return out;
}

test("runBatchTestOnCandles retorna as oito estratégias", () => {
  const r = runBatchTestOnCandles(candles(300), "R_100", 1, 30, "s", 1.9, true, "OK");
  assert.equal(r.results.length, 8);
  for (const res of r.results) {
    assert.equal(typeof res.signals.buy, "number");
    assert.equal(typeof res.signals.sell, "number");
    assert.equal(typeof res.metrics.winRate, "number");
  }
});

test("runBatchTestOnCandles identifica estratégias sem sinais", () => {
  const r = runBatchTestOnCandles(flat(300), "R_100", 1, 30, "s", 1.9, true, "OK");
  assert.ok(r.results.every((x) => x.noSignals));
  assert.equal(r.results.every((x) => x.signals.buy + x.signals.sell === 0), true);
});

test("runBatchTestOnCandles propaga incompatibilidade de contrato", () => {
  const r = runBatchTestOnCandles(
    candles(300),
    "R_100",
    1,
    30,
    "s",
    1.9,
    false,
    "Duração indisponível",
  );
  assert.equal(r.contractAvailable, false);
  assert.equal(r.contractReason, "Duração indisponível");
});

function mockWs() {
  return {
    request: async (payload: Record<string, unknown>) => {
      if (payload.contracts_for !== undefined) {
        return {
          contracts_for: {
            available: [
              {
                contract_category: "callput",
                min_contract_duration: "1t",
                max_contract_duration: "10t",
                min_stake: "0.35",
                max_stake: "50000",
              },
            ],
          },
        };
      }
      return {};
    },
  } as unknown as WebSocketManager;
}

test("resolveSyntheticIndices consulta a API dinamicamente", async () => {
  const list = await resolveSyntheticIndices(mockWs());
  assert.equal(list.length, 5);
  const r100 = list.find((x) => x.symbol === "R_100");
  assert.ok(r100);
  assert.equal(r100.available, true);
  assert.equal(r100.minDuration, "1t");
  assert.equal(r100.minStake, 0.35);
});
