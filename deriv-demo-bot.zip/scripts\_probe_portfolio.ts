import { DerivApiClient } from "../backend/src/deriv/apiClient.js";
import { WebSocketManager } from "../backend/src/deriv/wsManager.js";

process.env.LOG_LEVEL = "error";

async function main() {
  const client = new DerivApiClient();
  const url = await client.getDemoWebSocketUrl();
  const ws = new WebSocketManager();
  await ws.connect(url);

  // Consulta o portfólio de contratos (abertos + liquidados).
  try {
    const msg = await ws.request({ portfolio: 1 });
    const contracts = (msg as { portfolio?: { contracts?: Array<Record<string, unknown>> } }).portfolio?.contracts ?? [];
    console.log(`=== Portfolio (${contracts.length} contratos) ===`);
    for (const c of contracts) {
      console.log(
        `contract_id=${c.contract_id} symbol=${c.underlying_symbol} type=${c.contract_type} status=${c.status} is_sold=${c.is_sold} buy_price=${c.buy_price} sell_price=${c.sell_price} profit=${c.profit} payout=${c.payout} expiry=${c.expiry_time}`,
      );
    }
  } catch (e) {
    console.log("portfolio ERRO:", e instanceof Error ? e.message : String(e));
  }

  await ws.close();
}

main().catch((e) => {
  console.error("FALHA:", e instanceof Error ? e.message : String(e));
  process.exit(1);
});
