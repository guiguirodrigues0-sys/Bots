import { test } from "node:test";
import assert from "node:assert/strict";
import { StrategyManager } from "../src/strategies/manager.js";
import { defaultConfig } from "../src/strategies/definitions.js";
import type { Candle } from "../src/types.js";

process.env.LOG_LEVEL = "error";

function candles(n: number): Candle[] {
  const out: Candle[] = [];
  let close = 100;
  for (let i = 0; i < n; i++) {
    const open = close;
    close = open + 0.02;
    out.push({ time: i * 60, open, high: close + 0.01, low: open - 0.01, close });
  }
  return out;
}

test("inicia sem estratégia ativa", () => {
  const m = new StrategyManager();
  assert.equal(m.getActiveId(), null);
});

test("seleciona apenas uma estratégia ativa", () => {
  const m = new StrategyManager();
  m.select("CONFLUENCIA");
  m.select("SCALPING");
  assert.equal(m.getActiveId(), "SCALPING");
  const active = m.list().filter((s) => s.status.active);
  // `status.active` reflete o estado do manager, não o da instância.
  assert.equal(m.getActiveId(), "SCALPING");
});

test("troca de estratégia é registrada no histórico", () => {
  const m = new StrategyManager();
  m.select("CONFLUENCIA");
  m.select("MACD_ADX", "teste");
  const snap = m.getSnapshot();
  assert.equal(snap.switchLog.length, 2);
  assert.equal(snap.switchLog[1]?.from, "CONFLUENCIA");
  assert.equal(snap.switchLog[1]?.to, "MACD_ADX");
});

test("setConfig mescla e valida; config inválida é rejeitada", () => {
  const m = new StrategyManager();
  const ok = m.setConfig("CONFLUENCIA", { duration: 30 });
  assert.equal(ok.ok, true);
  assert.equal(m.getConfig("CONFLUENCIA").duration, 30);

  const bad = m.setConfig("CONFLUENCIA", { duration: 0 });
  assert.equal(bad.ok, false);
  assert.equal(m.getConfig("CONFLUENCIA").duration, 30);
});

test("resetConfig restaura os padrões", () => {
  const m = new StrategyManager();
  m.setConfig("SCALPING", { duration: 5, durationUnit: "s" });
  m.resetConfig("SCALPING");
  const cfg = m.getConfig("SCALPING");
  assert.deepEqual(cfg, defaultConfig("SCALPING"));
});

test("onCandle alimenta buffer e retorna sinal da estratégia ativa", () => {
  const m = new StrategyManager();
  m.select("SCALPING");
  const data = candles(60);
  for (const c of data) {
    const signal = m.onCandle(c);
    if (signal) {
      assert.equal(signal.strategyId, "SCALPING");
    }
  }
  assert.equal(m.getSnapshot().candleCount, 60);
});

test("onCandle sem estratégia ativa retorna null", () => {
  const m = new StrategyManager();
  assert.equal(m.onCandle(candles(1)[0]!), null);
});

test("select valida a config e retorna ok para config válida", () => {
  const m = new StrategyManager();
  const result = m.select("TENDENCIA");
  assert.equal(result.ok, true);
  assert.equal(m.getActiveId(), "TENDENCIA");
});

test("config inválida é rejeitada pelo setConfig e não é aplicada", () => {
  const m = new StrategyManager();
  const bad = m.setConfig("TENDENCIA", { duration: -1 });
  assert.equal(bad.ok, false);
  assert.equal(m.getConfig("TENDENCIA").duration, defaultConfig("TENDENCIA").duration);
});

test("recordRejected guarda motivos de rejeição", () => {
  const m = new StrategyManager();
  m.select("CONFLUENCIA");
  m.recordRejected({
    timestamp: Date.now(),
    strategyId: "CONFLUENCIA",
    direction: "BUY",
    reason: "stop diário",
    reasonCode: "RISK_BLOCKED",
  });
  assert.equal(m.getSnapshot().rejectedSignals.length, 1);
});

test("construtor sanitiza granularity inválido vindo de configs persistidas", () => {
  const m = new StrategyManager({
    SCALPING: { ...defaultConfig("SCALPING"), granularity: 1 },
    MACD_ADX: { ...defaultConfig("MACD_ADX"), granularity: 45 },
  });
  assert.equal(m.getConfig("SCALPING").granularity, 60);
  assert.equal(m.getConfig("MACD_ADX").granularity, 60);
});
