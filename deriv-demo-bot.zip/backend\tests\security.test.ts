import { test, afterEach } from "node:test";
import assert from "node:assert/strict";
import { DerivApiClient, DemoAccountBlockedError, AuthExpiredError } from "../src/deriv/apiClient.js";
import { loadEnv } from "../src/config/env.js";

const originalFetch = globalThis.fetch;

afterEach(() => {
  (globalThis as unknown as { fetch: unknown }).fetch = originalFetch;
  process.env.ALLOW_REAL_ACCOUNT = "false";
});

function mockFetch(responses: Array<() => unknown>) {
  let i = 0;
  (globalThis as unknown as { fetch: unknown }).fetch = async () => {
    const r = responses[Math.min(i, responses.length - 1)];
    i += 1;
    return r();
  };
}

function json(data: unknown) {
  return {
    ok: true,
    status: 200,
    json: async () => data,
    text: async () => JSON.stringify(data),
    headers: { get: () => null },
  };
}

test("conta REAL é rejeitada", async () => {
  mockFetch([
    () =>
      json({
        data: [{ account_id: "R1", account_type: "real", currency: "USD", balance: "100" }],
      }),
  ]);
  const client = new DerivApiClient();
  await assert.rejects(() => client.findDemoAccount(), DemoAccountBlockedError);
});

test("endpoint /ws/real é rejeitado", async () => {
  mockFetch([
    () => json({ data: [{ account_id: "D1", account_type: "demo", currency: "USD" }] }),
    () => json({ data: { url: "wss://example/ws/real?token=abc" } }),
  ]);
  const client = new DerivApiClient();
  await assert.rejects(() => client.getDemoWebSocketUrl(), DemoAccountBlockedError);
});

test("conta DEMO é selecionada quando disponível", async () => {
  mockFetch([
    () => json({ data: [{ account_id: "D1", account_type: "demo", currency: "USD" }] }),
  ]);
  const client = new DerivApiClient();
  const account = await client.findDemoAccount();
  assert.equal(account.account_type, "demo");
});

test("ALLOW_REAL_ACCOUNT=true impede inicialização", () => {
  process.env.ALLOW_REAL_ACCOUNT = "true";
  assert.throws(() => loadEnv(), /ALLOW_REAL_ACCOUNT/);
  process.env.ALLOW_REAL_ACCOUNT = "false";
  loadEnv();
});

test("listAccounts com 401 lança AuthExpiredError", async () => {
  mockFetch([
    () => ({
      ok: false,
      status: 401,
      json: async () => ({ errors: [{ code: "Unauthorized", message: "Invalid or expired token" }] }),
    }),
  ]);
  const client = new DerivApiClient();
  await assert.rejects(() => client.listAccounts(), AuthExpiredError);
});
