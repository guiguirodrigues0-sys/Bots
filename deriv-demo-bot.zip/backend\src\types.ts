export interface Candle {
  time: number;
  open: number;
  high: number;
  low: number;
  close: number;
}

export interface IndicatorSnapshot {
  ema20: number | null;
  ema50: number | null;
  ema200: number | null;
  rsi14: number | null;
  adx: number | null;
  atr: number | null;
  bollingerUpper: number | null;
  bollingerMiddle: number | null;
  bollingerLower: number | null;
}

export type MarketCondition =
  | "TENDENCIA_ALTA"
  | "TENDENCIA_BAIXA"
  | "LATERAL"
  | "ALTA_VOLATILIDADE"
  | "INDEFINIDO";

export type StrategyType = "TENDENCIA" | "REVERSAO_MEDIA" | "NENHUMA";

export type Signal = "ALTA" | "BAIXA" | "AGUARDAR";

export type Decision = "ENTRAR" | "AGUARDAR" | "NAO_OPERAR";

export type Direction = "CALL" | "PUT";

export type AssetId = "EURUSD" | "GBPUSD" | "R_10" | "R_25" | "R_50" | "R_75" | "R_100";

export type AssetSelection = "EURUSD" | "GBPUSD" | "R_10" | "R_25" | "R_50" | "R_75" | "R_100" | "AUTO";

export interface ConfirmationDetail {
  label: string;
  passed: boolean;
}

export interface StrategyResult {
  marketCondition: MarketCondition;
  strategy: StrategyType;
  signal: Signal;
  decision: Decision;
  score: number;
  confirmations: number;
  confirmationsTotal: number;
  details: ConfirmationDetail[];
  reason: string;
  indicators: IndicatorSnapshot;
  price: number | null;
  timestamp: number;
}

export interface AssetInfo {
  assetId: AssetId;
  label: string;
  symbol: string;
  available: boolean;
  contractTypes: string[];
  minDuration: string | null;
  maxDuration: string | null;
  minStake: number | null;
  maxStake: number | null;
}

export interface MarketView {
  assetId: AssetId;
  label: string;
  symbol: string;
  price: number | null;
  signal: StrategyResult | null;
}

export interface TradeRecord {
  id: string;
  timestamp: number;
  symbol: string;
  direction: Direction;
  stake: number;
  entryPrice: number;
  score: number;
  marketCondition: MarketCondition;
  strategy: StrategyType;
  result: "WIN" | "LOSS" | "PENDING" | "UNKNOWN";
  profitLoss: number | null;
  balanceAfter: number | null;
  entryType: EntryType;
}

export interface SessionStats {
  initialBalance: number;
  currentBalance: number;
  sessionPnL: number;
  totalTrades: number;
  wins: number;
  losses: number;
  winRate: number;
  consecutiveLosses: number;
  maxConsecutiveLosses: number;
}

export type EntryType = "INITIAL" | "ACTIVE";

export type OpenTradeStatus = "OPEN" | "SETTLED";

export interface OpenTrade {
  contractId: string;
  proposalId: string;
  symbol: string;
  direction: Direction;
  stake: number;
  entryTime: number;
  durationSeconds: number;
  durationUnit: string;
  askPrice: number;
  payout: number | null;
  entryType: EntryType;
  status: OpenTradeStatus;
  profit: number | null;
  settlementTime: number | null;
}

export type RapidPhase = "WAITING_SETUP" | "ACTIVE_MODE";

export interface RapidStats {
  trades: number;
  wins: number;
  losses: number;
  pnl: number;
  winRate: number;
}

export interface SplitStats {
  initial: RapidStats;
  active: RapidStats;
  total: RapidStats;
  consecutiveLosses: number;
  maxConsecutiveLosses: number;
  initialBalance: number;
  currentBalance: number;
  sessionPnL: number;
}
