import { getEnv } from "../config/env.js";
import { logger } from "../logger/index.js";
import { DerivApiClient } from "./apiClient.js";
import { WebSocketManager } from "./wsManager.js";
import { CandleAggregator, fetchCandles } from "../services/marketDataService.js";
import { computeIndicators } from "../services/indicatorService.js";
import type { Candle, IndicatorSnapshot } from "../types.js";

export interface MarketPreviewResult {
  symbol: string;
  granularity: number;
  historyCount: number;
  lastCandles: Candle[];
  indicators: IndicatorSnapshot;
  lastTick: { quote: number; epoch: number } | null;
  currentCandle: Candle | null;
}

export async function runMarketPreview(
  granularity = 900,
  historyCount = 500,
  waitMs = 5000,
): Promise<MarketPreviewResult> {
  const env = getEnv();
  const client = new DerivApiClient();
  const url = await client.getDemoWebSocketUrl();
  const ws = new WebSocketManager();
  await ws.connect(url);

  let lastTick: { quote: number; epoch: number } | null = null;
  const aggregator = new CandleAggregator(granularity);
  const symbol = env.DERIV_SYMBOL;

  try {
    const candles = await fetchCandles(ws, symbol, granularity, historyCount);

    ws.onMessage((msg) => {
      if (msg.msg_type === "tick" && msg.tick?.symbol === symbol) {
        const t = msg.tick as { quote: number; epoch: number };
        lastTick = { quote: t.quote, epoch: t.epoch };
        aggregator.onTick(t.epoch, t.quote);
      }
    });

    await ws.request({ ticks: symbol, subscribe: 1 });
    await new Promise((r) => setTimeout(r, waitMs));

    const currentCandle = aggregator.currentCandle;
    const allCandles = currentCandle ? [...candles, currentCandle] : candles;
    const indicators = computeIndicators(allCandles);

    return {
      symbol,
      granularity,
      historyCount: candles.length,
      lastCandles: allCandles.slice(-10),
      indicators,
      lastTick,
      currentCandle,
    };
  } finally {
    await ws.close();
  }
}
