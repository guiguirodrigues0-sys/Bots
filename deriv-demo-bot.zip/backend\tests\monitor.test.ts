import { test } from "node:test";
import assert from "node:assert/strict";
import { TradeMonitor, type SettledTrade } from "../src/services/tradeMonitor.js";

process.env.LOG_LEVEL = "error";

test("settlement WIN emite WIN", () => {
  const tm = new TradeMonitor();
  let out: SettledTrade | null = null;
  tm.onSettled((s) => {
    out = s;
  });
  tm.handleMessage({
    proposal_open_contract: {
      contract_id: 123,
      is_sold: 1,
      status: "won",
      profit: "1.46",
      sell_price: "3.46",
    },
  });
  assert.equal(out?.result, "WIN");
  assert.equal(out?.profitLoss, 1.46);
  assert.equal(out?.sellPrice, 3.46);
  assert.equal(out?.contractId, "123");
});

test("settlement LOSS emite LOSS", () => {
  const tm = new TradeMonitor();
  let out: SettledTrade | null = null;
  tm.onSettled((s) => {
    out = s;
  });
  tm.handleMessage({
    proposal_open_contract: {
      contract_id: 456,
      is_sold: 1,
      status: "lost",
      profit: "-2",
      sell_price: "0",
    },
  });
  assert.equal(out?.result, "LOSS");
  assert.equal(out?.profitLoss, -2);
  assert.equal(out?.contractId, "456");
});

test("profit/sell_price string são convertidos corretamente", () => {
  const tm = new TradeMonitor();
  let out: SettledTrade | null = null;
  tm.onSettled((s) => {
    out = s;
  });
  tm.handleMessage({
    proposal_open_contract: {
      contract_id: 789,
      status: "won",
      profit: "3.40",
      sell_price: "5.40",
    },
  });
  assert.equal(out?.profitLoss, 3.4);
  assert.equal(out?.sellPrice, 5.4);
  assert.equal(out?.contractId, "789");
});

test("contrato ainda aberto não emite settlement", () => {
  const tm = new TradeMonitor();
  let called = false;
  tm.onSettled(() => {
    called = true;
  });
  tm.handleMessage({
    proposal_open_contract: {
      contract_id: 123,
      is_sold: 0,
      status: "open",
      profit: "0",
    },
  });
  assert.equal(called, false);
});
