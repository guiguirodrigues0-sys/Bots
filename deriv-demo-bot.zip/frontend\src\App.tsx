import { useEffect, useState } from "react";
import {
  getState,
  getSession,
  connectDeriv,
  disconnectDeriv,
  startBot,
  stopBot,
  pauseBot,
  resumeBot,
  STRATEGY_OPTIONS,
  type BotSnapshot,
  type PublicSession,
  type HistoryRecord,
  type RapidStats,
  type StrategyId,
} from "./api/client";
import DerivConnectionPanel from "./components/DerivConnectionPanel";
import StrategiesView from "./components/strategies/StrategiesView";
import StrategyLiveView from "./components/strategies/StrategyLiveView";

function currencySymbol(cur: string | null): string {
  if (!cur) return "";
  if (cur === "USD") return "$";
  return `${cur} `;
}

function fmtMoney(v: number | null | undefined, cur: string | null): string {
  if (v === null || v === undefined) return "—";
  return `${currencySymbol(cur)}${v.toLocaleString("pt-BR", {
    minimumFractionDigits: 2,
    maximumFractionDigits: 2,
  })}`;
}

function fmtSignedMoney(v: number | null | undefined, cur: string | null): string {
  if (v === null || v === undefined) return "—";
  const sign = v > 0 ? "+" : v < 0 ? "-" : "";
  const abs = Math.abs(v);
  return `${sign}${currencySymbol(cur)}${abs.toLocaleString("pt-BR", {
    minimumFractionDigits: 2,
    maximumFractionDigits: 2,
  })}`;
}

function fmtPrice(v: number | null | undefined): string {
  if (v === null || v === undefined) return "—";
  return v.toFixed(5);
}

function fmtNum(v: number | null | undefined, digits = 2): string {
  if (v === null || v === undefined) return "—";
  return v.toFixed(digits);
}

function fmtPct(v: number | null | undefined, digits = 2): string {
  if (v === null || v === undefined) return "—";
  return `${v.toFixed(digits)}%`;
}

function fmtTime(epochMs: number | null | undefined): string {
  if (epochMs === null || epochMs === undefined) return "—";
  return new Date(epochMs).toLocaleTimeString("pt-BR");
}

function fmtRemaining(entryTime: number, durationSeconds: number): string {
  const ms = entryTime + durationSeconds * 1000 - Date.now();
  if (ms <= 0) return "00:00";
  const s = Math.max(0, Math.round(ms / 1000));
  const m = Math.floor(s / 60);
  const ss = s % 60;
  return `${String(m).padStart(2, "0")}:${String(ss).padStart(2, "0")}`;
}

function directionClass(d: string | undefined): string {
  if (d === "CALL") return "signal-call";
  if (d === "PUT") return "signal-put";
  return "signal-aguardar";
}

function StatsCard({ title, s, currency }: { title: string; s: RapidStats; currency: string | null }) {
  return (
    <div className="stat">
      <div className="stat-label">{title}</div>
      <div className="stat-value">{s.trades}</div>
      <div className="stat-sub">
        {s.wins}W / {s.losses}L · {fmtSignedMoney(s.pnl, currency)}
      </div>
      <div className="stat-sub muted">acerto {s.winRate.toFixed(1)}%</div>
    </div>
  );
}

const EMPTY: BotSnapshot = {
  state: "STOPPED",
  mode: "SIGNAL_ONLY",
  symbol: "R_100",
  label: "VOLATILITY 100",
  contract: "RISE/FALL — 30 SEGUNDOS",
  phase: "WAITING_SETUP",
  price: null,
  direction: "WAIT",
  score: 0,
  confirmations: null,
  confirmationsTotal: null,
  momentum: null,
  rsi: null,
  fastEma: null,
  slowEma: null,
  volatilityPct: null,
  signalReason: null,
  openTrades: [],
  exposurePct: 0,
  lastEntryTime: null,
  nextEntryAllowedAt: null,
  balance: null,
  currency: null,
  lastEvent: null,
  lastError: null,
  decisionBlockReason: null,
  stats: {
    initial: { trades: 0, wins: 0, losses: 0, pnl: 0, winRate: 0 },
    active: { trades: 0, wins: 0, losses: 0, pnl: 0, winRate: 0 },
    total: { trades: 0, wins: 0, losses: 0, pnl: 0, winRate: 0 },
    consecutiveLosses: 0,
    maxConsecutiveLosses: 0,
    initialBalance: 0,
    currentBalance: 0,
    sessionPnL: 0,
  },
  history: [],
};

export default function App() {
  const [snap, setSnap] = useState<BotSnapshot>(EMPTY);
  const [session, setSession] = useState<PublicSession | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);
  const [view, setView] = useState<"bot" | "strategies">("bot");
  const [mode, setMode] = useState<"RAPID" | StrategyId>("RAPID");

  useEffect(() => {
    let alive = true;
    const tick = async () => {
      try {
        const s = await getState();
        if (alive) setSnap(s);
      } catch {
        if (alive) setError("Não foi possível conectar ao backend.");
      }
    };
    void tick();
    const id = setInterval(tick, 1000);
    return () => {
      alive = false;
      clearInterval(id);
    };
  }, []);

  useEffect(() => {
    let alive = true;
    const loadSession = async () => {
      try {
        const s = await getSession();
        if (alive) setSession(s);
      } catch {
        if (alive) setSession(null);
      }
    };
    void loadSession();
    const id = setInterval(loadSession, 1500);
    return () => {
      alive = false;
      clearInterval(id);
    };
  }, []);

  const running = snap.state === "RUNNING";
  const paused = snap.state === "PAUSED";
  const botStopped = snap.state === "STOPPED";
  const connected = session?.connected === true;

  const stats = snap.stats;
  const currency = snap.currency ?? session?.currency ?? null;
  const balance = snap.balance ?? session?.virtualBalance ?? null;
  const pnl = stats.sessionPnL;
  const pnlClass = pnl > 0 ? "pos" : pnl < 0 ? "neg" : "";

  const openTrades = snap.openTrades.filter((t) => t.status === "OPEN");
  const phaseLabel =
    snap.phase === "ACTIVE_MODE" ? "MODO ATIVO" : "AGUARDANDO SETUP";
  const confLabel =
    snap.confirmations !== null && snap.confirmationsTotal !== null
      ? `${snap.confirmations}/${snap.confirmationsTotal} CONFIRMAÇÕES`
      : null;

  const run = async (fn: () => Promise<void>) => {
    setBusy(true);
    setError(null);
    try {
      await fn();
    } catch (e) {
      setError(e instanceof Error ? e.message : String(e));
    } finally {
      setBusy(false);
    }
  };

  const onConnect = async (appId: string, token: string) => {
    setError(null);
    const s = await connectDeriv(appId, token);
    setSession(s);
  };

  const onDisconnect = async () => {
    setError(null);
    await disconnectDeriv();
    setSession(null);
  };

  return (
    <div className="app">
      <header className="topbar">
        <div className="brand">
          <div className="brand-name">Deriv Auto Trader</div>
          <div className="brand-sub">Rapid Mode — Volatility 100</div>
        </div>
        <div className="topbar-meta">
          <span className="mode-badge">DEMO</span>
          <span className={`status-dot ${connected ? "is-on" : ""}`} />
          <span className="conn-label">{connected ? "Conectado" : "Desconectado"}</span>
        </div>
      </header>

      <nav className="tabs">
        <button className={`tab ${view === "bot" ? "is-active" : ""}`} onClick={() => setView("bot")}>
          Módulo Rápido
        </button>
        <button className={`tab ${view === "strategies" ? "is-active" : ""}`} onClick={() => setView("strategies")}>
          Central de Estratégias
        </button>
      </nav>

      {view === "strategies" ? (
        <StrategiesView />
      ) : (
        <>
          <section className="panel">
            <div className="bot-body">
              <div className="bot-asset">
                <label htmlFor="strat-mode" style={{ marginRight: 8 }}>
                  Estratégia (conta DEMO)
                </label>
                <select
                  id="strat-mode"
                  value={mode}
                  onChange={(e) => setMode(e.target.value as "RAPID" | StrategyId)}
                >
                  <option value="RAPID">Rapid — Volatility 100 (legado)</option>
                  {STRATEGY_OPTIONS.map((o) => (
                    <option key={o.id} value={o.id}>
                      {o.name}
                    </option>
                  ))}
                </select>
              </div>
            </div>
          </section>

          <DerivConnectionPanel
        session={session}
        botRunning={running}
        openTrades={snap.openTrades}
        onConnect={onConnect}
        onDisconnect={onDisconnect}
      />

      {mode === "RAPID" ? (
        <>
      <section className="summary">
        <div className="stat">
          <div className="stat-label">Saldo</div>
          <div className="stat-value">{fmtMoney(balance, currency)}</div>
        </div>
        <div className="stat">
          <div className="stat-label">Resultado da sessão</div>
          <div className={`stat-value ${pnlClass}`}>{fmtSignedMoney(pnl, currency)}</div>
        </div>
        <div className="stat">
          <div className="stat-label">Operações</div>
          <div className="stat-value">{stats.total.trades}</div>
        </div>
        <div className="stat">
          <div className="stat-label">Exposição</div>
          <div className="stat-value">{fmtPct(snap.exposurePct)}</div>
        </div>
      </section>

      {error && (
        <div className="error-box">
          <p>{error}</p>
        </div>
      )}

      <div className="main">
        <div className="col-left">
          <section className="panel">
            <header className="panel-head">
              <h2>Bot</h2>
              <span className={`bot-status ${running ? "is-running" : paused ? "is-paused" : "is-stopped"}`}>
                <span className="status-dot" />
                {running ? "Ativo" : paused ? "Pausado" : "Parado"}
              </span>
            </header>
            <div className="bot-body">
              <div className="bot-actions">
                <button
                  className="btn btn-primary"
                  onClick={() => run(startBot)}
                  disabled={busy || !botStopped || !connected}
                >
                  Iniciar
                </button>
                {paused ? (
                  <button className="btn" onClick={() => run(resumeBot)} disabled={busy}>
                    Retomar
                  </button>
                ) : (
                  <button className="btn" onClick={() => run(pauseBot)} disabled={busy || !running}>
                    Pausar
                  </button>
                )}
                <button className="btn btn-danger" onClick={() => run(stopBot)} disabled={busy || botStopped}>
                  Parar
                </button>
              </div>
              {snap.lastEvent && (
                <p className={`notice ${/CONEXÃO EXPIRADA|BLOQUEADA|ERRO/.test(snap.lastEvent) ? "neg" : ""}`}>
                  {snap.lastEvent}
                </p>
              )}
              {snap.lastError && (
                <div className="error-box">
                  <p>{snap.lastError.length > 300 ? `${snap.lastError.slice(0, 300)}…` : snap.lastError}</p>
                </div>
              )}
            </div>
          </section>

          <section className="panel">
            <header className="panel-head">
              <h2>Mercado</h2>
            </header>
            <div className="market">
              <div className="market-head">
                <span className="market-name">{snap.label}</span>
                <span className="market-price">{fmtPrice(snap.price)}</span>
              </div>
              <div className="market-primary">
                <div className="mp-item">
                  <span className="mp-label">Ativo</span>
                  <span className="mp-value">{snap.symbol}</span>
                </div>
                <div className="mp-item">
                  <span className="mp-label">Contrato</span>
                  <span className="mp-value">{snap.contract}</span>
                </div>
                <div className="mp-item">
                  <span className="mp-label">Estado</span>
                  <span className={`mp-value ${snap.phase === "ACTIVE_MODE" ? "pos" : ""}`}>{phaseLabel}</span>
                </div>
                <div className="mp-item">
                  <span className="mp-label">Direção</span>
                  <span className={`signal-badge ${directionClass(snap.direction)}`}>{snap.direction}</span>
                </div>
                <div className="mp-item">
                  <span className="mp-label">Score</span>
                  <span className="mp-value score">{snap.score}/100</span>
                </div>
              </div>
              {confLabel && (
                <div className={`entry-status ${snap.decisionBlockReason ? "is-blocked" : "is-released"}`}>
                  <strong>{confLabel}</strong>
                  {snap.decisionBlockReason ? " — ENTRADA BLOQUEADA" : " — ENTRADA LIBERADA"}
                  {snap.decisionBlockReason && (
                    <span className="muted"> · Motivo: {snap.decisionBlockReason}</span>
                  )}
                </div>
              )}
              <div className="market-indicators">
                <span className="ind">Momentum <b>{fmtPct(snap.momentum, 3)}</b></span>
                <span className="ind">RSI <b>{fmtNum(snap.rsi, 1)}</b></span>
                <span className="ind">EMA rápida <b>{fmtNum(snap.fastEma, 4)}</b></span>
                <span className="ind">EMA lenta <b>{fmtNum(snap.slowEma, 4)}</b></span>
                <span className="ind">Vol <b>{fmtPct(snap.volatilityPct, 3)}</b></span>
              </div>
              {snap.signalReason && <p className="muted">{snap.signalReason}</p>}
              <dl className="op-grid">
                <dt>Última entrada</dt>
                <dd>{fmtTime(snap.lastEntryTime)}</dd>
                <dt>Próxima entrada</dt>
                <dd>{fmtTime(snap.nextEntryAllowedAt)}</dd>
              </dl>
            </div>
          </section>

          <section className="panel">
            <header className="panel-head">
              <h2>Estatísticas</h2>
            </header>
            <div className="summary">
              <StatsCard title="INITIAL" s={stats.initial} currency={currency} />
              <StatsCard title="ACTIVE" s={stats.active} currency={currency} />
              <StatsCard title="TOTAL" s={stats.total} currency={currency} />
            </div>
          </section>
        </div>

        <div className="col-right">
          <section className="panel">
            <header className="panel-head">
              <h2>Posições abertas</h2>
            </header>
            {openTrades.length === 0 ? (
              <div className="muted">Nenhuma posição em andamento.</div>
            ) : (
              <table className="table">
                <thead>
                  <tr>
                    <th>Direção</th>
                    <th>Stake</th>
                    <th>Entrada</th>
                    <th>Restante</th>
                    <th>Tipo</th>
                  </tr>
                </thead>
                <tbody>
                  {openTrades.map((t) => (
                    <tr key={t.contractId}>
                      <td>
                        <span className={`signal-badge ${directionClass(t.direction)}`}>{t.direction}</span>
                      </td>
                      <td>{fmtMoney(t.stake, currency)}</td>
                      <td>{fmtTime(t.entryTime)}</td>
                      <td>{fmtRemaining(t.entryTime, t.durationSeconds)}</td>
                      <td>{t.entryType}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            )}
          </section>

          <section className="panel">
            <header className="panel-head">
              <h2>Histórico</h2>
            </header>
            <table className="table">
              <thead>
                <tr>
                  <th>Horário</th>
                  <th>Direção</th>
                  <th>Tipo</th>
                  <th>Resultado</th>
                  <th>P/L</th>
                </tr>
              </thead>
              <tbody>
                {snap.history.length === 0 ? (
                  <tr className="empty">
                    <td colSpan={5}>Nenhuma operação nesta sessão.</td>
                  </tr>
                ) : (
                  snap.history
                    .slice()
                    .reverse()
                    .map((r: HistoryRecord) => (
                      <tr key={r.id}>
                        <td>{fmtTime(r.timestamp)}</td>
                        <td>
                          <span className={`signal-badge ${directionClass(r.direction)}`}>{r.direction}</span>
                        </td>
                        <td>{r.entryType}</td>
                        <td className={r.result === "WIN" ? "pos" : r.result === "LOSS" ? "neg" : ""}>
                          {r.result}
                        </td>
                        <td className={(r.profitLoss ?? 0) >= 0 ? "pos" : "neg"}>
                          {fmtSignedMoney(r.profitLoss, currency)}
                        </td>
                      </tr>
                    ))
                )}
              </tbody>
            </table>
          </section>
        </div>
      </div>
        </>
      ) : (
        <StrategyLiveView
          strategyId={mode}
          strategyName={STRATEGY_OPTIONS.find((o) => o.id === mode)?.name ?? mode}
          connected={connected}
        />
      )}
        </>
      )}
    </div>
  );
}
