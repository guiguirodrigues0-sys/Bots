/**
 * Validação real das 8 estratégias usando dados históricos da Deriv.
 * SOMENTE LEITURA: carrega candles e avalia sinais — não envia ordens.
 *
 * Uso: node --import tsx scripts/live-diagnose.ts [symbol] [granularity] [count]
 * Ex.:  node --import tsx scripts/live-diagnose.ts R_100 60 600
 *
 * Sem argumentos, percorre os mercados padrão (R_75, R_100, R_50,
 * frxEURUSD, frxGBPUSD) em timeframes de 60s e 300s.
 */
import { DerivApiClient } from "../backend/src/deriv/apiClient.js";
import { WebSocketManager } from "../backend/src/deriv/wsManager.js";
import { fetchCandles } from "../backend/src/services/marketDataService.js";
import { diagnoseStrategiesOnCandles } from "../backend/src/strategies/diagnostics.js";

process.env.LOG_LEVEL = "error";

const DEFAULT_MARKETS = [
  { label: "Volatility 75", symbol: "R_75" },
  { label: "Volatility 100", symbol: "R_100" },
  { label: "Volatility 50", symbol: "R_50" },
  { label: "EUR/USD", symbol: "frxEURUSD" },
  { label: "GBP/USD", symbol: "frxGBPUSD" },
];

const args = process.argv.slice(2);
const singleSymbol = args[0];
const singleGranularity = args[1] ? Number(args[1]) : null;
const singleCount = args[2] ? Number(args[2]) : 600;

async function runOne(ws: WebSocketManager, label: string, symbol: string, granularity: number, count: number): Promise<void> {
  const candles = await fetchCandles(ws, symbol, granularity, count);
  const first = candles[0]?.time;
  const last = candles[candles.length - 1]?.time;
  const span =
    first && last
      ? `${new Date(first * 1000).toISOString()} .. ${new Date(last * 1000).toISOString()}`
      : "n/d";
  console.log(`\n=== ${label} (${symbol}) | tf=${granularity}s | candles=${candles.length} | ${span} ===`);
  const diag = diagnoseStrategiesOnCandles(candles, symbol, granularity);
  for (const r of diag.results) {
    const top = Object.entries(r.conditionFailures)
      .sort((a, b) => b[1] - a[1])
      .slice(0, 3)
      .map(([k, v]) => `${k}=${v}`)
      .join(" | ");
    console.log(
      `  ${r.strategyId.padEnd(16)} ev=${String(r.evaluations).padStart(3)} buy=${String(r.buy).padStart(3)} sell=${String(r.sell).padStart(3)} insuf=${String(r.insufficient).padStart(3)} noSignal=${String(r.noSignal).padStart(3)} err=${r.errors} [${r.status}]${top ? " | TOP: " + top : ""}`,
    );
  }
}

async function main(): Promise<void> {
  const client = new DerivApiClient();
  const url = await client.getDemoWebSocketUrl();
  console.log("OK: URL demo obtida.");
  const ws = new WebSocketManager();
  await ws.connect(url);
  console.log("OK: WebSocket conectado.");

  try {
    if (singleSymbol) {
      const label = DEFAULT_MARKETS.find((m) => m.symbol === singleSymbol)?.label ?? singleSymbol;
      const granularity = singleGranularity ?? 60;
      await runOne(ws, label, singleSymbol, granularity, singleCount);
    } else {
      for (const m of DEFAULT_MARKETS) {
        for (const granularity of [60, 300]) {
          try {
            await runOne(ws, m.label, m.symbol, granularity, 600);
          } catch (e) {
            console.log(
              `=== ${m.label} (${m.symbol}) | tf=${granularity}s | ERRO: ${e instanceof Error ? e.message : String(e)} ===`,
            );
          }
        }
      }
    }
  } finally {
    await ws.close();
  }
  console.log("\nOK: concluído.");
}

main().catch((e) => {
  console.error("FALHA GERAL:", e instanceof Error ? e.message : String(e));
  process.exit(1);
});
