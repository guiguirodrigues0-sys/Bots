import type { Candle } from "../../types.js";
import { BaseStrategy, makeSignal, insufficientSignal } from "../base.js";
import type {
  StrategyConfig,
  StrategyId,
  StrategySignal,
  MarketRegime,
  RegimeSwitchRecord,
} from "../types.js";
import { adxSeries, last, num, bool } from "../indicators.js";
import { TendenciaStrategy } from "./tendencia.js";
import { ReversaoMediaStrategy } from "./reversaoMedia.js";

/**
 * Estratégia 7 — Adaptativa.
 * Seleciona automaticamente uma estratégia compatível com o regime de mercado
 * (ADX > 25 → Seguidor de Tendência; ADX < 20 → Reversão à Média; entre 20 e 25
 * → regime indefinido, sem novas operações).
 */
export class AdaptativaStrategy extends BaseStrategy {
  readonly id: StrategyId = "ADAPTATIVA";

  private tendencia = new TendenciaStrategy();
  private reversao = new ReversaoMediaStrategy();

  private currentRegime: MarketRegime = "INDEFINIDO";
  private pendingRegime: MarketRegime = "INDEFINIDO";
  private pendingCount = 0;
  private lastSwitchAt: number | null = null;
  private switchLog: RegimeSwitchRecord[] = [];

  override reset(): void {
    super.reset();
    this.currentRegime = "INDEFINIDO";
    this.pendingRegime = "INDEFINIDO";
    this.pendingCount = 0;
    this.lastSwitchAt = null;
    this.switchLog = [];
    this.tendencia.reset();
    this.reversao.reset();
  }

  override dispose(): void {
    this.tendencia.dispose();
    this.reversao.dispose();
    this.reset();
  }

  getCurrentRegime(): MarketRegime {
    return this.currentRegime;
  }

  getSwitchLog(): RegimeSwitchRecord[] {
    return this.switchLog.map((r) => ({ ...r }));
  }

  evaluateSignal(candles: Candle[], config: StrategyConfig): StrategySignal {
    const closes = candles.map((c) => c.close);
    const price = closes.at(-1) ?? null;
    const adx = last(adxSeries(candles, num(config.params, "adxPeriod", 14)));

    const autoAdapt = bool(config.params, "autoAdapt", true);
    const fixedRegime = String(config.params.fixedRegime ?? "INDEFINIDO") as MarketRegime;

    // Sem histórico suficiente para classificar o regime automaticamente:
    // reporta dados insuficientes (não "sem sinal").
    if (autoAdapt && adx === null) {
      return insufficientSignal(this.id, price);
    }

    let regime: MarketRegime;
    if (!autoAdapt) {
      regime = fixedRegime === "TENDENCIA" || fixedRegime === "LATERAL"
        ? fixedRegime
        : "INDEFINIDO";
    } else {
      regime = this.classifyRegime(adx as number, config);
      this.updateRegime(regime, config);
      regime = this.currentRegime;
    }

    if (regime === "TENDENCIA") {
      const base = this.tendencia.evaluateSignal(candles, config);
      return this.rewrap(base, "TENDENCIA");
    }
    if (regime === "LATERAL") {
      const base = this.reversao.evaluateSignal(candles, config);
      return this.rewrap(base, "LATERAL");
    }

    return makeSignal(
      this.id,
      "WAIT",
      price,
      [],
      { adx },
      `AGUARDAR — regime indefinido (ADX ${adx === null ? "n/d" : adx.toFixed(1)}). Nenhuma operação até identificar um regime válido.`,
      "INDEFINIDO",
      "NO_SIGNAL",
    );
  }

  private classifyRegime(adx: number, config: StrategyConfig): MarketRegime {
    const trendMin = num(config.params, "adxTrendMin", 25);
    const rangeMax = num(config.params, "adxRangeMax", 20);
    if (adx > trendMin) {
      return "TENDENCIA";
    }
    if (adx < rangeMax) {
      return "LATERAL";
    }
    return "INDEFINIDO";
  }

  private updateRegime(target: MarketRegime, config: StrategyConfig): void {
    if (target === this.currentRegime) {
      this.pendingRegime = this.currentRegime;
      this.pendingCount = 0;
      return;
    }

    if (target !== this.pendingRegime) {
      this.pendingRegime = target;
      this.pendingCount = 1;
      return;
    }

    this.pendingCount += 1;
    const confirmCandles = num(config.params, "confirmCandles", 3);
    const minSwitchMs = num(config.params, "minSwitchIntervalMs", 300000);
    const now = Date.now();

    if (this.pendingCount < confirmCandles) {
      return;
    }
    if (this.lastSwitchAt !== null && now - this.lastSwitchAt < minSwitchMs) {
      return;
    }

    const from = this.currentRegime;
    this.switchLog.push({ timestamp: now, from, to: target });
    if (this.switchLog.length > 100) {
      this.switchLog = this.switchLog.slice(-100);
    }
    this.currentRegime = target;
    this.pendingRegime = target;
    this.pendingCount = 0;
    this.lastSwitchAt = now;
    this.tendencia.reset();
    this.reversao.reset();
  }

  private rewrap(base: StrategySignal, regime: MarketRegime): StrategySignal {
    return {
      ...base,
      strategyId: this.id,
      regime,
      reason: `[Adaptativa · ${regime}] ${base.reason}`,
    };
  }
}
