import type { Candle } from "../types.js";
import type {
  MarketRegime,
  RegimeSwitchRecord,
  RejectedSignalRecord,
  Strategy,
  StrategyConfig,
  StrategyId,
  StrategySignal,
  StrategySwitchRecord,
} from "./types.js";
import { STRATEGY_IDS, STRATEGY_METADATA, defaultConfig } from "./definitions.js";
import { createStrategy, AdaptativaStrategy } from "./registry.js";
import { isValidGranularity } from "../services/marketDataService.js";
import { logger } from "../logger/index.js";

const MAX_BUFFER = 600;
const MAX_SIGNAL_HISTORY = 200;
const MAX_REJECTED = 200;
const MAX_SWITCH_LOG = 100;

export interface StrategyMetaView {
  metadata: typeof STRATEGY_METADATA[StrategyId];
  config: StrategyConfig;
  status: ReturnType<Strategy["getStatus"]>;
}

export interface StrategyManagerSnapshot {
  activeId: StrategyId | null;
  strategies: StrategyMetaView[];
  signalHistory: StrategySignal[];
  rejectedSignals: RejectedSignalRecord[];
  switchLog: StrategySwitchRecord[];
  regime: MarketRegime | null;
  regimeSwitchLog: RegimeSwitchRecord[];
  candleCount: number;
  lastCandleTime: number | null;
}

export class StrategyManager {
  private instances = new Map<StrategyId, Strategy>();
  private configs: Record<StrategyId, StrategyConfig>;
  private activeId: StrategyId | null = null;
  private buffer: Candle[] = [];
  private signalHistory: StrategySignal[] = [];
  private rejectedSignals: RejectedSignalRecord[] = [];
  private switchLog: StrategySwitchRecord[] = [];
  private lastSignal: StrategySignal | null = null;

  constructor(initialConfigs?: Partial<Record<StrategyId, StrategyConfig>>) {
    this.configs = {} as Record<StrategyId, StrategyConfig>;
    for (const id of STRATEGY_IDS) {
      this.configs[id] = defaultConfig(id);
      if (initialConfigs?.[id]) {
        this.configs[id] = { ...this.configs[id], ...initialConfigs[id] };
      }
      // Defesa extra: garante que nunca fique um granularity inválido em memória.
      if (!isValidGranularity(this.configs[id].granularity)) {
        logger.warn("Granularity inválido em memória; restaurando padrão", {
          strategyId: id,
          granularity: this.configs[id].granularity,
          padrao: defaultConfig(id).granularity,
        });
        this.configs[id].granularity = defaultConfig(id).granularity;
      }
    }
  }

  getActiveId(): StrategyId | null {
    return this.activeId;
  }

  getActiveConfig(): StrategyConfig | null {
    return this.activeId ? this.configs[this.activeId] : null;
  }

  getConfig(id: StrategyId): StrategyConfig {
    return { ...this.configs[id] };
  }

  getAllConfigs(): Record<StrategyId, StrategyConfig> {
    const out = {} as Record<StrategyId, StrategyConfig>;
    for (const id of STRATEGY_IDS) {
      out[id] = this.getConfig(id);
    }
    return out;
  }

  getLastSignal(): StrategySignal | null {
    return this.lastSignal;
  }

  list(): StrategyMetaView[] {
    return STRATEGY_IDS.map((id) => ({
      metadata: STRATEGY_METADATA[id],
      config: this.getConfig(id),
      status: this.getInstance(id).getStatus(),
    }));
  }

  getInstance(id: StrategyId): Strategy {
    let instance = this.instances.get(id);
    if (!instance) {
      instance = createStrategy(id);
      instance.initialize();
      this.instances.set(id, instance);
    }
    return instance;
  }

  getActiveInstance(): Strategy | null {
    return this.activeId ? this.getInstance(this.activeId) : null;
  }

  setConfig(id: StrategyId, partial: Partial<StrategyConfig>): { ok: boolean; errors: string[] } {
    const merged: StrategyConfig = {
      ...this.configs[id],
      ...partial,
      params: { ...this.configs[id].params, ...(partial.params ?? {}) },
    };
    const validation = this.getInstance(id).validateConfig(merged);
    if (!validation.ok) {
      return validation;
    }
    this.configs[id] = merged;
    return validation;
  }

  resetConfig(id: StrategyId): void {
    this.configs[id] = defaultConfig(id);
  }

  /**
   * Seleciona a estratégia ativa (apenas uma por instância). A troca segura
   * (verificação de contratos abertos e suspensão de entradas) é responsabilidade
   * do runtime, que chama este método somente quando seguro.
   */
  select(id: StrategyId, reason = "seleção manual"): { ok: boolean; error?: string } {
    const instance = this.getInstance(id);
    const config = this.configs[id];
    const validation = instance.validateConfig(config);
    if (!validation.ok) {
      return { ok: false, error: validation.errors.join(" ") };
    }
    if (this.activeId === id) {
      return { ok: true };
    }
    const from = this.activeId;
    this.activeId = id;
    for (const s of this.instances.values()) {
      s.reset();
    }
    instance.initialize();
    this.pushSwitchLog({ timestamp: Date.now(), from, to: id, reason });
    logger.info("Estratégia ativa alterada", { from, to: id, reason });
    return { ok: true };
  }

  /**
   * Alimenta um candle fechado e avalia o sinal da estratégia ativa.
   * Retorna o sinal (ou null se não houver estratégia ativa).
   */
  onCandle(candle: Candle): StrategySignal | null {
    const last = this.buffer[this.buffer.length - 1];
    if (last && last.time === candle.time) {
      // Mesma janela de tempo (candle em andamento reemitido ao fechar):
      // substitui em vez de duplicar.
      this.buffer[this.buffer.length - 1] = candle;
    } else {
      this.buffer.push(candle);
      if (this.buffer.length > MAX_BUFFER) {
        this.buffer = this.buffer.slice(-MAX_BUFFER);
      }
    }
    if (!this.activeId) {
      return null;
    }
    const strategy = this.getInstance(this.activeId);
    const config = this.configs[this.activeId];
    strategy.onCandle(candle);
    let signal: StrategySignal;
    try {
      signal = strategy.evaluateSignal(this.buffer, config);
    } catch (err) {
      logger.error("Erro ao avaliar estratégia", {
        strategyId: this.activeId,
        message: err instanceof Error ? err.message : String(err),
      });
      return null;
    }
    this.lastSignal = signal;
    this.signalHistory.push(signal);
    if (this.signalHistory.length > MAX_SIGNAL_HISTORY) {
      this.signalHistory = this.signalHistory.slice(-MAX_SIGNAL_HISTORY);
    }
    return signal;
  }

  recordRejected(record: RejectedSignalRecord): void {
    this.rejectedSignals.push(record);
    if (this.rejectedSignals.length > MAX_REJECTED) {
      this.rejectedSignals = this.rejectedSignals.slice(-MAX_REJECTED);
    }
  }

  resetBuffers(): void {
    this.buffer = [];
    this.lastSignal = null;
    for (const s of this.instances.values()) {
      s.reset();
    }
    if (this.activeId) {
      this.getInstance(this.activeId).initialize();
    }
  }

  getRegime(): MarketRegime | null {
    const active = this.activeId ? this.getInstance(this.activeId) : null;
    if (active instanceof AdaptativaStrategy) {
      return active.getCurrentRegime();
    }
    return this.lastSignal?.regime ?? null;
  }

  getRegimeSwitchLog(): RegimeSwitchRecord[] {
    const active = this.activeId ? this.getInstance(this.activeId) : null;
    if (active instanceof AdaptativaStrategy) {
      return active.getSwitchLog();
    }
    return [];
  }

  getSnapshot(): StrategyManagerSnapshot {
    return {
      activeId: this.activeId,
      strategies: this.list(),
      signalHistory: this.signalHistory.map((s) => ({ ...s })),
      rejectedSignals: this.rejectedSignals.map((r) => ({ ...r })),
      switchLog: this.switchLog.map((r) => ({ ...r })),
      regime: this.getRegime(),
      regimeSwitchLog: this.getRegimeSwitchLog(),
      candleCount: this.buffer.length,
      lastCandleTime: this.buffer[this.buffer.length - 1]?.time ?? null,
    };
  }

  dispose(): void {
    for (const s of this.instances.values()) {
      s.dispose();
    }
    this.instances.clear();
    this.buffer = [];
    this.signalHistory = [];
    this.rejectedSignals = [];
    this.switchLog = [];
    this.lastSignal = null;
  }

  private pushSwitchLog(record: StrategySwitchRecord): void {
    this.switchLog.push(record);
    if (this.switchLog.length > MAX_SWITCH_LOG) {
      this.switchLog = this.switchLog.slice(-MAX_SWITCH_LOG);
    }
  }
}
