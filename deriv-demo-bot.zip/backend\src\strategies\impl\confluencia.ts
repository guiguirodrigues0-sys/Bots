import type { Candle } from "../../types.js";
import { BaseStrategy, makeSignal, insufficientSignal } from "../base.js";
import type {
  StrategyConfig,
  StrategyId,
  StrategySignal,
  StrategyCondition,
} from "../types.js";
import {
  emaSeries,
  rsiSeries,
  adxSeries,
  last,
  num,
} from "../indicators.js";

/**
 * Estratégia 1 — Confluência Inteligente.
 * Entradas seletivas com múltiplas confirmações (EMA 9/21/200, RSI 14, ADX 14).
 */
export class ConfluenciaStrategy extends BaseStrategy {
  readonly id: StrategyId = "CONFLUENCIA";

  evaluateSignal(candles: Candle[], config: StrategyConfig): StrategySignal {
    const closes = candles.map((c) => c.close);
    const price = closes.at(-1) ?? null;
    if (price === null) {
      return insufficientSignal(this.id, price);
    }

    const ema9 = last(emaSeries(closes, num(config.params, "emaFastPeriod", 9)));
    const ema21 = last(emaSeries(closes, num(config.params, "emaSlowPeriod", 21)));
    const ema200 = last(emaSeries(closes, num(config.params, "emaTrendPeriod", 200)));
    const rsi = last(rsiSeries(closes, num(config.params, "rsiPeriod", 14)));
    const adx = last(adxSeries(candles, num(config.params, "adxPeriod", 14)));

    if (
      ema9 === null ||
      ema21 === null ||
      ema200 === null ||
      rsi === null ||
      adx === null
    ) {
      return insufficientSignal(this.id, price);
    }

    const rsiBuyMin = num(config.params, "rsiBuyMin", 52);
    const rsiBuyMax = num(config.params, "rsiBuyMax", 68);
    const rsiSellMin = num(config.params, "rsiSellMin", 32);
    const rsiSellMax = num(config.params, "rsiSellMax", 48);
    const adxMin = num(config.params, "adxMin", 25);

    const lastCandle = candles.at(-1);
    const candleBullish = lastCandle ? lastCandle.close > lastCandle.open : false;
    const candleBearish = lastCandle ? lastCandle.close < lastCandle.open : false;

    const buyConditions: StrategyCondition[] = [
      { label: "Preço acima da EMA 200", passed: price > ema200 },
      { label: "EMA 9 acima da EMA 21", passed: ema9 > ema21 },
      {
        label: `RSI entre ${rsiBuyMin} e ${rsiBuyMax}`,
        passed: rsi >= rsiBuyMin && rsi <= rsiBuyMax,
      },
      { label: `ADX acima de ${adxMin}`, passed: adx > adxMin },
      { label: "Candle fechado confirma alta", passed: candleBullish },
    ];

    const sellConditions: StrategyCondition[] = [
      { label: "Preço abaixo da EMA 200", passed: price < ema200 },
      { label: "EMA 9 abaixo da EMA 21", passed: ema9 < ema21 },
      {
        label: `RSI entre ${rsiSellMin} e ${rsiSellMax}`,
        passed: rsi >= rsiSellMin && rsi <= rsiSellMax,
      },
      { label: `ADX acima de ${adxMin}`, passed: adx > adxMin },
      { label: "Candle fechado confirma baixa", passed: candleBearish },
    ];

    const indicators = {
      ema9,
      ema21,
      ema200,
      rsi,
      adx,
    };

    const buy = buyConditions.every((c) => c.passed);
    const sell = sellConditions.every((c) => c.passed);

    if (buy) {
      return makeSignal(
        this.id,
        "BUY",
        price,
        buyConditions,
        indicators,
        `SINAL BUY — confluência de alta confirmada (EMA9 ${ema9.toFixed(5)} > EMA21 ${ema21.toFixed(5)}, RSI ${rsi.toFixed(1)}, ADX ${adx.toFixed(1)}).`,
      );
    }
    if (sell) {
      return makeSignal(
        this.id,
        "SELL",
        price,
        sellConditions,
        indicators,
        `SINAL SELL — confluência de baixa confirmada (EMA9 ${ema9.toFixed(5)} < EMA21 ${ema21.toFixed(5)}, RSI ${rsi.toFixed(1)}, ADX ${adx.toFixed(1)}).`,
      );
    }

    const buyPassed = buyConditions.filter((c) => c.passed).length;
    const sellPassed = sellConditions.filter((c) => c.passed).length;
    const shown = buyPassed >= sellPassed ? buyConditions : sellConditions;
    return makeSignal(
      this.id,
      "WAIT",
      price,
      shown,
      indicators,
      `AGUARDAR — critérios de confluência não atendidos (RSI ${rsi.toFixed(1)}, ADX ${adx.toFixed(1)}).`,
      null,
      "NO_SIGNAL",
    );
  }
}
