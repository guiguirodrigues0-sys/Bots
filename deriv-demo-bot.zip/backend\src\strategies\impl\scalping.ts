import type { Candle } from "../../types.js";
import { BaseStrategy, makeSignal, insufficientSignal } from "../base.js";
import type {
  StrategyConfig,
  StrategyId,
  StrategySignal,
  StrategyCondition,
} from "../types.js";
import {
  emaSeries,
  rsiSeries,
  crossedAbove,
  crossedBelow,
  last,
  num,
} from "../indicators.js";

/**
 * Estratégia 2 — Scalping EMA + RSI.
 * Oportunidades de curto prazo com maior frequência potencial de sinais.
 */
export class ScalpingStrategy extends BaseStrategy {
  readonly id: StrategyId = "SCALPING";

  evaluateSignal(candles: Candle[], config: StrategyConfig): StrategySignal {
    const closes = candles.map((c) => c.close);
    const price = closes.at(-1) ?? null;
    if (price === null || closes.length < 3) {
      return insufficientSignal(this.id, price);
    }

    const fast = emaSeries(closes, num(config.params, "emaFastPeriod", 5));
    const slow = emaSeries(closes, num(config.params, "emaSlowPeriod", 13));
    const rsi = last(rsiSeries(closes, num(config.params, "rsiPeriod", 7)));

    const i = closes.length - 1;
    if (rsi === null || fast[i] == null || slow[i] == null) {
      return insufficientSignal(this.id, price);
    }

    const rsiBuyMin = num(config.params, "rsiBuyMin", 50);
    const rsiBuyMax = num(config.params, "rsiBuyMax", 75);
    const rsiSellMin = num(config.params, "rsiSellMin", 25);
    const rsiSellMax = num(config.params, "rsiSellMax", 50);

    const lastCandle = candles.at(-1);
    const candleUp = lastCandle ? lastCandle.close > lastCandle.open : false;
    const candleDown = lastCandle ? lastCandle.close < lastCandle.open : false;

    const buyConditions: StrategyCondition[] = [
      {
        label: "EMA 5 cruza acima da EMA 13",
        passed: crossedAbove(fast, slow, i),
      },
      {
        label: `RSI entre ${rsiBuyMin} e ${rsiBuyMax}`,
        passed: rsi > rsiBuyMin && rsi < rsiBuyMax,
      },
      { label: "Candle de confirmação fecha em alta", passed: candleUp },
    ];

    const sellConditions: StrategyCondition[] = [
      {
        label: "EMA 5 cruza abaixo da EMA 13",
        passed: crossedBelow(fast, slow, i),
      },
      {
        label: `RSI entre ${rsiSellMin} e ${rsiSellMax}`,
        passed: rsi > rsiSellMin && rsi < rsiSellMax,
      },
      { label: "Candle de confirmação fecha em baixa", passed: candleDown },
    ];

    const indicators = { emaFast: fast[i] ?? null, emaSlow: slow[i] ?? null, rsi };

    if (buyConditions.every((c) => c.passed)) {
      return makeSignal(
        this.id,
        "BUY",
        price,
        buyConditions,
        indicators,
        `SINAL BUY — cruzamento de alta EMA 5/13 com RSI ${rsi.toFixed(1)}.`,
      );
    }
    if (sellConditions.every((c) => c.passed)) {
      return makeSignal(
        this.id,
        "SELL",
        price,
        sellConditions,
        indicators,
        `SINAL SELL — cruzamento de baixa EMA 5/13 com RSI ${rsi.toFixed(1)}.`,
      );
    }

    const shown = crossedAbove(fast, slow, i) ? buyConditions : sellConditions;
    return makeSignal(
      this.id,
      "WAIT",
      price,
      shown,
      indicators,
      `AGUARDAR — sem cruzamento válido (RSI ${rsi.toFixed(1)}).`,
      null,
      "NO_SIGNAL",
    );
  }
}
