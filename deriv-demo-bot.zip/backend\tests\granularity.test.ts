import { test } from "node:test";
import assert from "node:assert/strict";
import {
  ALLOWED_GRANULARITIES,
  isValidGranularity,
  assertGranularity,
  minutesToSeconds,
  fetchCandles,
  GranularityValidationError,
} from "../src/services/marketDataService.js";
import type { WebSocketManager } from "../src/deriv/wsManager.js";

process.env.LOG_LEVEL = "error";

test("ALLOWED_GRANULARITIES contém os 12 valores aceitos pela Deriv", () => {
  assert.deepEqual(ALLOWED_GRANULARITIES, [
    60, 120, 180, 300, 600, 900, 1800, 3600, 7200, 14400, 28800, 86400,
  ]);
});

test("isValidGranularity aceita todos os timeframes suportados", () => {
  for (const g of ALLOWED_GRANULARITIES) {
    assert.equal(isValidGranularity(g), true, `granularity ${g} deveria ser válido`);
  }
});

test("isValidGranularity rejeita valores não permitidos", () => {
  for (const g of [1, 5, 15, 30, 45, 90, 61, 119, 0, -60, 1.5, Number.NaN]) {
    assert.equal(isValidGranularity(g), false, `granularity ${g} deveria ser inválido`);
  }
});

test("assertGranularity lança GranularityValidationError para valor inválido", () => {
  assert.throws(() => assertGranularity(15), GranularityValidationError);
  assert.throws(() => assertGranularity(1), GranularityValidationError);
  assert.doesNotThrow(() => assertGranularity(900));
});

test("minutesToSeconds converte minutos em segundos (sem conversão duplicada)", () => {
  assert.equal(minutesToSeconds(1), 60);
  assert.equal(minutesToSeconds(15), 900);
  assert.equal(minutesToSeconds(60), 3600);
});

test("fetchCandles envia granularity em segundos exatamente como informado", async () => {
  let sent: Record<string, unknown> | null = null;
  const ws = {
    request: async (payload: Record<string, unknown>) => {
      sent = payload;
      return { candles: [] };
    },
  } as unknown as WebSocketManager;

  await fetchCandles(ws, "frxEURUSD", 900, 100);
  assert.equal(sent?.granularity, 900);
  assert.equal(sent?.ticks_history, "frxEURUSD");
  assert.equal(sent?.style, "candles");
});

test("fetchCandles rejeita granularity inválido ANTES de chamar a API", async () => {
  let called = false;
  const ws = {
    request: async () => {
      called = true;
      return {};
    },
  } as unknown as WebSocketManager;

  await assert.rejects(() => fetchCandles(ws, "frxEURUSD", 15, 100), GranularityValidationError);
  assert.equal(called, false);
});
